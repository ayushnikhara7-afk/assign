import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { BookingService, Booking } from '../../services/booking.service';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-my-bookings',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, NavbarComponent],
  templateUrl: './my-bookings.component.html',
  styleUrl: './my-bookings.component.scss'
})
export class MyBookingsComponent implements OnInit {
  private fb = inject(FormBuilder);
  private bookingService = inject(BookingService);
  private toastService = inject(ToastService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);

  bookings: Booking[] = [];
  loading = false;
  error = '';
  selectedBooking: Booking | null = null;

  showPaymentModal = false;
  processingPayment = false;
  paymentError = '';
  paymentSuccess = '';

  stripe: any = null;
  cardElement: any = null;
  stripeElements: any = null;
  clientSecret = '';
  stripePublishableKey = 'pk_test_51SNpKi99iYo6gebaSjrAJlUPC8LFyY4JpXycn60paZEDeMJrp4qGl1SV5nvwc9PIstlKgjGMmv5I22vPVXSO5kqW00PsBsyxuw';

  ngOnInit(): void {
    this.initializeStripe();

    // Check for query params to auto-open payment modal
    this.route.queryParams.subscribe(params => {
      if (params['ref'] && params['pay'] === 'true') {
        // Load bookings first, then open payment for the specified booking
        this.loadBookingsAndOpenPayment(params['ref']);
      } else {
        this.loadBookings();
      }
    });
  }

  loadBookingsAndOpenPayment(referenceNumber: string): void {
    this.loading = true;
    this.error = '';

    this.bookingService.getMyBookings().subscribe({
      next: (bookings: Booking[]) => {
        this.bookings = bookings;
        this.loading = false;

        // Find the booking and open payment modal
        const booking = bookings.find(b => b.referenceNumber === referenceNumber);
        if (booking) {
          setTimeout(() => {
            this.toastService.info('Please complete payment for your booking');
            this.openPaymentModal(booking);
          }, 500);
        }

        // Clear query params
        this.router.navigate([], {
          queryParams: {},
          replaceUrl: true
        });
      },
      error: (err: any) => {
        this.loading = false;
        this.error = err?.error?.message || 'Failed to load bookings';
        this.toastService.error(this.error);
      }
    });
  }

  initializeStripe(): void {
    if ((window as any).Stripe) {
      this.stripe = (window as any).Stripe(this.stripePublishableKey);
    } else {
      console.error('Stripe.js not loaded');
    }
  }

  loadBookings(): void {
    this.loading = true;
    this.error = '';

    this.bookingService.getMyBookings().subscribe({
      next: (bookings: Booking[]) => {
        this.bookings = bookings;
        this.loading = false;
        if (bookings.length === 0) {
          this.toastService.info('You have no bookings yet');
        }
      },
      error: (err: any) => {
        this.loading = false;
        this.error = err?.error?.message || 'Failed to load bookings';

        // Check if it's an authentication error
        if (err?.status === 401 || this.error.toLowerCase().includes('not authenticated')) {
          this.error = 'Your session has expired or needs to be refreshed. Please logout and login again.';
          this.toastService.error('Please logout and login again to refresh your session', 5000);

          // Auto-redirect to login after 3 seconds
          setTimeout(() => {
            localStorage.removeItem('auth_token');
            this.router.navigate(['/login']);
          }, 3000);
        } else {
          this.toastService.error(this.error);
        }
      }
    });
  }

  openPaymentModal(booking: Booking): void {
    this.selectedBooking = booking;
    this.paymentError = '';
    this.paymentSuccess = '';
    this.processingPayment = true;

    // Create payment intent
    this.bookingService.createPaymentIntent(booking.referenceNumber).subscribe({
      next: (response) => {
        this.clientSecret = response.clientSecret;
        this.showPaymentModal = true;
        this.processingPayment = false;

        // Initialize Stripe Elements after modal is shown
        setTimeout(() => this.mountStripeElements(), 100);
      },
      error: (err) => {
        this.processingPayment = false;
        this.paymentError = err?.error?.message || 'Failed to initialize payment';
        this.toastService.error(this.paymentError);
      }
    });
  }

  mountStripeElements(): void {
    if (!this.stripe || !this.clientSecret) return;

    this.stripeElements = this.stripe.elements({
      clientSecret: this.clientSecret
    });

    const style = {
      base: {
        fontSize: '16px',
        color: '#1e293b',
        '::placeholder': {
          color: '#94a3b8'
        }
      },
      invalid: {
        color: '#ef4444'
      }
    };

    this.cardElement = this.stripeElements.create('payment', {
      layout: 'tabs',
      style: style
    });

    const cardElementContainer = document.getElementById('stripe-card-element');
    if (cardElementContainer) {
      this.cardElement.mount('#stripe-card-element');
    }
  }

  closePaymentModal(): void {
    this.showPaymentModal = false;
    this.selectedBooking = null;
    this.paymentError = '';
    this.paymentSuccess = '';
    this.clientSecret = '';
    if (this.cardElement) {
      this.cardElement.unmount();
      this.cardElement = null;
    }
    this.stripeElements = null;
  }

  async processPayment(): Promise<void> {
    if (!this.stripe || !this.stripeElements || !this.selectedBooking) {
      this.toastService.error('Payment system not initialized');
      return;
    }

    this.processingPayment = true;
    this.paymentError = '';
    this.paymentSuccess = '';

    try {
      const { error, paymentIntent } = await this.stripe.confirmPayment({
        elements: this.stripeElements,
        confirmParams: {
          return_url: window.location.origin + '/my-bookings',
        },
        redirect: 'if_required'
      });

      if (error) {
        this.processingPayment = false;
        this.paymentError = error.message || 'Payment failed';
        this.toastService.error(this.paymentError);
      } else if (paymentIntent && paymentIntent.status === 'succeeded') {
        // Confirm payment with backend
        this.bookingService.confirmPayment(
          this.selectedBooking.referenceNumber,
          paymentIntent.id
        ).subscribe({
          next: (response) => {
            this.processingPayment = false;
            this.paymentSuccess = 'Payment successful!';
            this.toastService.success('Payment processed successfully!');

            setTimeout(() => {
              this.closePaymentModal();
              this.loadBookings();
            }, 2000);
          },
          error: (err) => {
            this.processingPayment = false;
            this.paymentError = err?.error?.message || 'Payment confirmation failed';
            this.toastService.error(this.paymentError);
          }
        });
      }
    } catch (err: any) {
      this.processingPayment = false;
      this.paymentError = err.message || 'Payment processing failed';
      this.toastService.error(this.paymentError);
    }
  }

  cancelBooking(booking: Booking): void {
    if (!confirm(`Are you sure you want to cancel booking ${booking.referenceNumber}?`)) {
      return;
    }

    this.bookingService.cancelBooking(booking.referenceNumber).subscribe({
      next: () => {
        this.toastService.success('Booking cancelled successfully');
        this.loadBookings(); // Reload the bookings list
      },
      error: (err: any) => {
        const errorMsg = err?.error?.message || 'Failed to cancel booking';
        this.toastService.error(errorMsg);
      }
    });
  }

  goToCheckin(booking: Booking): void {
    this.router.navigate(['/checkin'], {
      queryParams: { ref: booking.referenceNumber }
    });
  }
}
