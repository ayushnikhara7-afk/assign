import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Flight } from './flight.service';

export interface User {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
}

export interface CreateFlightRequest {
  flightNumber: string;
  from: string;
  to: string;
  date: string;
  fare: number;
}

export interface UpdateFlightRequest {
  id: number;
  flightNumber: string;
  from: string;
  to: string;
  date: string;
  fare: number;
}

export interface UpdateUserRequest {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
}

export interface MessageResponse {
  message: string;
}

export interface FlightResponse {
  flight: Flight;
  message: string;
}

export interface UserResponse {
  user: User;
  message: string;
}

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private http = inject(HttpClient);
  private readonly basePath = '/api/Admin';

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('admin_token');
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  // Flight Management
  createFlight(request: CreateFlightRequest): Observable<FlightResponse> {
    return this.http.post<FlightResponse>(`${this.basePath}/flights`, request, {
      headers: this.getAuthHeaders()
    });
  }

  updateFlight(request: UpdateFlightRequest): Observable<FlightResponse> {
    return this.http.put<FlightResponse>(`${this.basePath}/flights`, request, {
      headers: this.getAuthHeaders()
    });
  }

  deleteFlight(id: number): Observable<MessageResponse> {
    return this.http.delete<MessageResponse>(`${this.basePath}/flights/${id}`, {
      headers: this.getAuthHeaders()
    });
  }

  getAllFlights(): Observable<Flight[]> {
    return this.http.get<Flight[]>(`${this.basePath}/flights`, {
      headers: this.getAuthHeaders()
    });
  }

  // User Management
  getAllUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.basePath}/users`, {
      headers: this.getAuthHeaders()
    });
  }

  updateUser(request: UpdateUserRequest): Observable<UserResponse> {
    return this.http.put<UserResponse>(`${this.basePath}/users`, request, {
      headers: this.getAuthHeaders()
    });
  }

  deleteUser(id: number): Observable<MessageResponse> {
    return this.http.delete<MessageResponse>(`${this.basePath}/users/${id}`, {
      headers: this.getAuthHeaders()
    });
  }
}

