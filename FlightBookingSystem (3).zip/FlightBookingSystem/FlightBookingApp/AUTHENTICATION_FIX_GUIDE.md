# 🔧 Authentication Fix Guide

## ⚠️ Issue: "User not authenticated" in My Bookings

This error occurs because your current JWT token doesn't include the user ID. The token was created before we updated the authentication system.

---

## ✅ Quick Fix (3 Steps)

### Step 1: Update Database
Run these commands to add the new fields:

```powershell
cd backend
dotnet ef database drop --force
dotnet ef database update
```

This adds:
- `UserId` to Bookings table
- `IsPaid`, `PaymentDate`, `PaymentIntentId` to Bookings table

### Step 2: Restart Backend
```powershell
cd backend
dotnet run
```

### Step 3: Logout and Login Again
1. Open your application: http://localhost:4200
2. Click on "Account" dropdown (top right)
3. Click "Logout"
4. Login again with your credentials
5. Go to "My Bookings"
6. ✅ Should work now!

---

## 🔍 Why This Happens

### Old JWT Token (Before Fix):
```json
{
  "sub": "username",
  "jti": "guid",
  "role": "User"
}
```
❌ Missing user ID!

### New JWT Token (After Fix):
```json
{
  "sub": "username",
  "nameid": "123",        ← User ID added!
  "jti": "guid",
  "role": "User",
  "email": "user@example.com"
}
```
✅ Includes user ID!

---

## 🎯 What's Been Fixed

### Backend Changes:
1. ✅ `AuthApiController.cs` - JWT now includes user ID
2. ✅ `BookingApiController.cs` - Better error message
3. ✅ `IAuthService.cs` - Added GetUserByUsername method
4. ✅ `AuthService.cs` - Implemented GetUserByUsername

### Frontend Changes:
1. ✅ Error handling - Auto-redirect to login if auth fails
2. ✅ Better error message - Tells user to logout/login
3. ✅ Toast notification - 5-second warning message

---

## 🚨 Auto-Redirect Feature

If you see the "User not authenticated" error:
- ⏰ Error message appears
- 📢 Toast notification: "Please logout and login again..."
- ⏳ After 3 seconds: Auto-redirect to login page
- 🔄 Login again to get new token

---

## 🧪 Testing After Fix

### 1. Test Authentication:
```
1. Logout
2. Login with: username / password
3. Go to "My Bookings"
4. ✅ Should load bookings (or show "No bookings yet")
```

### 2. Test Complete Flow:
```
1. Login
2. Search flights (Mumbai → Delhi)
3. Book a flight
4. Auto-redirect to My Bookings
5. Payment modal opens
6. Pay with: 4242 4242 4242 4242
7. ✅ Booking shown as "Paid"
```

---

## 💡 Pro Tip

**Clear your browser's Local Storage** to force a fresh login:
1. Open DevTools (F12)
2. Go to "Application" tab
3. Click "Local Storage" → http://localhost:4200
4. Right-click "auth_token" → Delete
5. Refresh page
6. Login again

---

## ✅ Checklist

Before testing:
- [ ] Database migrated (drop + update)
- [ ] Backend running (dotnet run)
- [ ] Frontend running (npm start)
- [ ] Logged out of application
- [ ] Logged in again with credentials
- [ ] Tested My Bookings page

---

## 🎉 After Fix You'll Have:

- ✅ My Bookings page working
- ✅ All your bookings displayed
- ✅ Payment status visible
- ✅ Check-in button (for paid bookings)
- ✅ Cancel button working
- ✅ Full-width layout

---

**Just logout and login again - that's all you need! 🚀**

