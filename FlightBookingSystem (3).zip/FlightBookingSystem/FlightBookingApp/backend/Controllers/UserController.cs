using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Services.Interfaces;
using System.Linq;

namespace FlightBookingApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class UserController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly ILogger<UserController> _logger;

        public UserController(IAuthService authService, ILogger<UserController> logger)
        {
            _authService = authService;
            _logger = logger;
        }

        [HttpGet("profile")]
        public IActionResult GetProfile()
        {
            // Find the NameIdentifier claim that contains a numeric user ID
            var userIdClaim = User.Claims
                .Where(c => c.Type == ClaimTypes.NameIdentifier)
                .Select(c => c.Value)
                .FirstOrDefault(v => int.TryParse(v, out _));
            
            _logger.LogInformation("Found user ID claim: {UserIdClaim}", userIdClaim ?? "null");
            
            if (string.IsNullOrEmpty(userIdClaim) || !int.TryParse(userIdClaim, out int userId))
            {
                _logger.LogWarning("Failed to extract user ID from token");
                return Unauthorized(new { message = "User not found" });
            }

            _logger.LogInformation("Getting profile for user ID: {UserId}", userId);
            var user = _authService.GetUserById(userId);
            if (user == null)
            {
                _logger.LogWarning("User not found in database: {UserId}", userId);
                return NotFound(new { message = "User not found" });
            }

            return Ok(new
            {
                id = user.Id,
                username = user.Username,
                email = user.Email,
                firstName = user.FirstName,
                lastName = user.LastName
            });
        }

        [HttpPut("profile")]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileRequest request)
        {
            // Find the NameIdentifier claim that contains a numeric user ID
            var userIdClaim = User.Claims
                .Where(c => c.Type == ClaimTypes.NameIdentifier)
                .Select(c => c.Value)
                .FirstOrDefault(v => int.TryParse(v, out _));
            
            if (string.IsNullOrEmpty(userIdClaim) || !int.TryParse(userIdClaim, out int userId))
            {
                _logger.LogWarning("Failed to extract user ID from token for profile update");
                return Unauthorized(new { message = "User not found" });
            }

            try
            {
                _logger.LogInformation("Updating profile for user ID: {UserId}", userId);
                var updatedUser = await _authService.UpdateUserProfileAsync(
                    userId,
                    request.Email,
                    request.Username,
                    request.FirstName,
                    request.LastName
                );

                _logger.LogInformation("User {UserId} updated their profile successfully", userId);

                return Ok(new
                {
                    message = "Profile updated successfully",
                    user = new
                    {
                        id = updatedUser.Id,
                        username = updatedUser.Username,
                        email = updatedUser.Email,
                        firstName = updatedUser.FirstName,
                        lastName = updatedUser.LastName
                    }
                });
            }
            catch (ArgumentException ex)
            {
                _logger.LogError("Profile update failed for user {UserId}: {Error}", userId, ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}

