using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Repository.Interfaces;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Services.Implementations
{
    public class BookingService : IBookingService
    {
        private readonly IBookingRepository _bookingRepo;
        private readonly IFlightRepository _flightRepo;
        private readonly IEmailService _emailService;
        private readonly IStripeService _stripeService;
        private readonly IUserRepository _userRepo;
        private readonly ILogger<BookingService> _logger;
        
        public BookingService(
            IBookingRepository bookingRepo, 
            IFlightRepository flightRepo,
            IEmailService emailService,
            IStripeService stripeService,
            IUserRepository userRepo,
            ILogger<BookingService> logger)
        {
            _bookingRepo = bookingRepo;
            _flightRepo = flightRepo;
            _emailService = emailService;
            _stripeService = stripeService;
            _userRepo = userRepo;
            _logger = logger;
        }

        public Booking CreateBooking(BookingRequest request, int? userId = null)
        {
            var flight = _flightRepo.GetById(request.FlightId);
            if (flight == null)
            {
                throw new ArgumentException("Flight not found");
            }

            // Validate flight date - check if flight date has already passed
            var currentDate = DateTime.UtcNow.Date;
            if (flight.Date.Date < currentDate)
            {
                throw new ArgumentException($"Cannot book flight {flight.FlightNumber} as the flight date ({flight.Date:yyyy-MM-dd}) has already passed. Flight date must be today or in the future.");
            }

            var referenceNumber = Guid.NewGuid().ToString().Substring(0, 8).ToUpper();

            var booking = new Booking
            {
                ReferenceNumber = referenceNumber,
                FlightId = request.FlightId,
                UserId = userId,
                FirstName = request.FirstName,
                LastName = request.LastName,
                Gender = request.Gender,
                BookingDate = DateTime.UtcNow
            };

            var createdBooking = _bookingRepo.Add(booking);
            
            // Send booking confirmation email asynchronously
            try
            {
                if (createdBooking.UserId.HasValue)
                {
                    var user = _userRepo.GetById(createdBooking.UserId.Value);
                    if (user != null && !string.IsNullOrEmpty(user.Email))
                    {
                        var passengerName = $"{request.FirstName} {request.LastName}";
                        _ = _emailService.SendBookingConfirmationAsync(
                            user.Email,
                            passengerName,
                            referenceNumber,
                            flight.FlightNumber,
                            flight.From,
                            flight.To,
                            flight.Date
                        );
                        _logger.LogInformation($"Booking confirmation email sent to {user.Email} for booking {referenceNumber}");
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to send booking confirmation email: {ex.Message}");
            }

            return createdBooking;
        }

        public Booking? GetBookingByReference(string referenceNumber)
        {
            return _bookingRepo.GetByReferenceNumber(referenceNumber);
        }

        public List<Booking> GetUserBookings(int userId)
        {
            return _bookingRepo.GetUserBookings(userId);
        }

        public bool CancelBooking(string referenceNumber)
        {
            return _bookingRepo.CancelBooking(referenceNumber);
        }

        public async Task<string> CreatePaymentIntentAsync(string referenceNumber)
        {
            var booking = _bookingRepo.GetBookingWithFlight(referenceNumber);
            if (booking == null || booking.Flight == null)
            {
                throw new ArgumentException("Booking not found");
            }

            var amount = booking.Flight.Fare;
            var description = $"Flight Booking - {booking.ReferenceNumber}";
            var metadata = new Dictionary<string, string>
            {
                { "booking_reference", booking.ReferenceNumber ?? string.Empty },
                { "flight_number", booking.Flight.FlightNumber },
                { "passenger_name", $"{booking.FirstName} {booking.LastName}" }
            };

            var clientSecret = await _stripeService.CreatePaymentIntentAsync(
                amount, 
                "usd", 
                description, 
                metadata
            );

            return clientSecret;
        }

        public async Task<bool> ConfirmPaymentAsync(string referenceNumber, string paymentIntentId)
        {
            var booking = _bookingRepo.GetBookingWithFlight(referenceNumber);
            if (booking == null)
            {
                return false;
            }

            var paymentConfirmed = await _stripeService.ConfirmPaymentAsync(paymentIntentId);
            
            if (paymentConfirmed)
            {
                booking.IsPaid = true;
                booking.PaymentDate = DateTime.UtcNow;
                booking.PaymentIntentId = paymentIntentId;
                _bookingRepo.Update(booking);
                
                _logger.LogInformation($"Payment confirmed for booking {referenceNumber}");

                // Send payment success email
                try
                {
                    if (booking.UserId.HasValue)
                    {
                        var user = _userRepo.GetById(booking.UserId.Value);
                        if (user != null && !string.IsNullOrEmpty(user.Email))
                        {
                            var passengerName = $"{booking.FirstName} {booking.LastName}";
                            var amount = booking.Flight?.Fare ?? 0;
                            _ = _emailService.SendPaymentSuccessAsync(
                                user.Email,
                                passengerName,
                                referenceNumber,
                                booking.Flight?.FlightNumber ?? "",
                                amount,
                                booking.PaymentDate.Value
                            );
                            _logger.LogInformation($"Payment success email sent to {user.Email} for booking {referenceNumber}");
                        }
                    }
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Failed to send payment success email: {ex.Message}");
                }
            }

            return paymentConfirmed;
        }
    }
}

