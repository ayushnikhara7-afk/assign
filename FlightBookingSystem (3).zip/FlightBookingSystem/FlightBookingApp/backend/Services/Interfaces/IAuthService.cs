using FlightBookingApp.Models.Domain;

namespace FlightBookingApp.Services.Interfaces
{
    public interface IAuthService
    {
        bool ValidateUser(string username, string password);
        bool UserExists(string username);
        bool EmailExists(string email);
        void RegisterUser(User user);
        bool ResetPassword(string email, string newPassword);
        User? GetUserByEmail(string email);
        User? GetUserByUsername(string username);
        User? GetUserById(int id);
        Task SendPasswordResetInstructionsAsync(string email, string userName, string resetToken);
        Task<User> UpdateUserProfileAsync(int userId, string email, string username, string firstName, string lastName);
    }
}

