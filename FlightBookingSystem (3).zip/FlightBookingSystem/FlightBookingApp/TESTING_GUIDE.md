# Testing Guide - New Features

## Quick Start

### Prerequisites
1. Backend server running on `http://localhost:5000`
2. Frontend server running on `http://localhost:4200`
3. SMTP configured in `appsettings.json`
4. Valid email address for testing

---

## Feature Testing

### 1. Profile Management

#### Test Profile View
1. **Login** to the application with a valid user account
2. Click on **"Account"** button in the navbar (top right)
3. Click on **"My Profile"** in the dropdown
4. **Expected Result**: Profile page loads with current user information pre-filled

#### Test Profile Update
1. Navigate to Profile page (as above)
2. Modify any of the fields:
   - First Name
   - Last Name
   - Username
   - Email
3. Click **"Update Profile"** button
4. **Expected Results**:
   - Success message appears
   - Toast notification shows "Profile updated successfully!"
   - Email sent to the updated email address
   - Profile information is updated in the system

#### Test Validation
1. Navigate to Profile page
2. Try to update with invalid data:
   - Empty first name or last name
   - Invalid email format
   - Username less than 3 characters
3. **Expected Results**:
   - Form shows validation errors
   - "Update Profile" button is disabled
   - Cannot submit form with invalid data

#### Test Duplicate Email/Username
1. Navigate to Profile page
2. Try to change email to an email already used by another user
3. Click **"Update Profile"**
4. **Expected Results**:
   - Error message: "Email already exists"
   - Profile is not updated

---

### 2. Booking Email Notifications

#### Test Booking Confirmation Email
1. **Login** to the application
2. Go to **Home** page
3. Search for a flight:
   - Select departure location
   - Select destination
   - Choose a future date
4. Click **"Search"**
5. Select a flight from results
6. Click **"Book Now"**
7. Fill in passenger details and submit
8. **Expected Results**:
   - Booking is created successfully
   - Booking reference number is generated
   - Email sent to user's email address with:
     - Booking confirmation
     - Flight details
     - Passenger information
     - Booking reference number

#### What to Check in Email
- ✅ Subject: "Booking Confirmation - [REFERENCE_NUMBER]"
- ✅ Contains booking reference in large, bold text
- ✅ Shows flight number, route, and date
- ✅ Shows passenger name
- ✅ Includes next steps (check-in reminder)
- ✅ Professional styling with gradient header

---

### 3. Payment Email Notifications

#### Test Payment Success Email
1. **Complete a booking** (as above)
2. Navigate to **"My Bookings"**
3. Find your booking and click **"Pay"**
4. Complete payment using Stripe test card:
   - Card Number: `4242 4242 4242 4242`
   - Expiry: Any future date (e.g., 12/25)
   - CVC: Any 3 digits (e.g., 123)
5. Submit payment
6. **Expected Results**:
   - Payment processed successfully
   - Booking marked as paid
   - Email sent to user's email address with:
     - Payment confirmation
     - Amount paid
     - Payment date and time
     - Booking reference

#### What to Check in Email
- ✅ Subject: "Payment Successful - [REFERENCE_NUMBER]"
- ✅ Shows large checkmark icon
- ✅ Displays payment amount prominently
- ✅ Shows payment date and time
- ✅ Contains flight and booking information
- ✅ Status marked as "PAID"
- ✅ Green color theme for success

---

### 4. Check-in Email Notifications

#### Test Check-in Confirmation Email
1. **Complete a booking and payment** (as above)
2. Navigate to **"Check-in"** page
3. Enter your booking reference number
4. Click **"Search Booking"**
5. Review booking details
6. Click **"Check In"**
7. **Expected Results**:
   - Check-in successful
   - Seat number assigned
   - Email sent to user's email address with:
     - Check-in confirmation
     - Assigned seat number (prominently displayed)
     - Flight details
     - Boarding reminders

#### What to Check in Email
- ✅ Subject: "Check-in Confirmation - [REFERENCE_NUMBER]"
- ✅ Shows large seat number in dashed border box
- ✅ Contains flight details
- ✅ Shows booking reference
- ✅ Includes important reminders (arrive 2 hours early, bring ID, etc.)
- ✅ Professional boarding pass style

---

### 5. Profile Update Email Notifications

#### Test Profile Update Email
1. Navigate to **Profile** page
2. Update any profile information (name, email, username)
3. Click **"Update Profile"**
4. **Expected Results**:
   - Profile updated successfully
   - Email sent to the NEW email address (if email was changed)
   - Email sent to current email address (if email wasn't changed)

#### What to Check in Email
- ✅ Subject: "Profile Updated Successfully"
- ✅ Confirmation message about profile update
- ✅ Security notice about unauthorized changes
- ✅ Support contact information
- ✅ Professional styling

---

## API Testing (Using Postman or curl)

### Get User Profile
```bash
GET http://localhost:5000/api/User/profile
Headers:
  Authorization: Bearer <your-jwt-token>
```

**Expected Response:**
```json
{
  "id": 1,
  "username": "john_doe",
  "email": "john@example.com",
  "firstName": "John",
  "lastName": "Doe"
}
```

### Update User Profile
```bash
PUT http://localhost:5000/api/User/profile
Headers:
  Authorization: Bearer <your-jwt-token>
  Content-Type: application/json

Body:
{
  "username": "john_doe_updated",
  "email": "john.updated@example.com",
  "firstName": "John",
  "lastName": "Doe"
}
```

**Expected Response:**
```json
{
  "message": "Profile updated successfully",
  "user": {
    "id": 1,
    "username": "john_doe_updated",
    "email": "john.updated@example.com",
    "firstName": "John",
    "lastName": "Doe"
  }
}
```

---

## Email Testing Tips

### Check Email Delivery
1. **Check Spam Folder**: Emails might land in spam initially
2. **Verify SMTP Settings**: Ensure credentials are correct in `appsettings.json`
3. **Check Logs**: Review backend console for email sending logs
4. **Gmail Users**: Enable "Less secure app access" or use App Passwords

### Test Email Rendering
1. **Desktop Email Clients**: Test in Outlook, Apple Mail, Thunderbird
2. **Web Email Clients**: Test in Gmail, Outlook.com, Yahoo Mail
3. **Mobile Email Clients**: Test on iPhone Mail, Android Gmail
4. **Dark Mode**: Check if emails render correctly in dark mode

---

## Common Test Scenarios

### Scenario 1: Complete User Journey
1. Sign up for a new account → **Receive welcome email**
2. Search and book a flight → **Receive booking confirmation email**
3. Pay for the booking → **Receive payment success email**
4. Check in for the flight → **Receive check-in confirmation email**
5. Update profile information → **Receive profile update email**

### Scenario 2: Profile Management
1. Login as existing user
2. Navigate to Profile page
3. Update email to a new email
4. Check both old and new email for notifications
5. Verify you can login with new credentials

### Scenario 3: Error Handling
1. Try to update profile with existing username
2. Try to update profile with existing email
3. Try to access profile without authentication
4. Verify appropriate error messages are displayed

---

## Verification Checklist

### Backend
- [ ] UserController is accessible at `/api/User`
- [ ] Profile endpoint requires authentication
- [ ] Email service sends all types of emails
- [ ] Emails are sent asynchronously (don't block operations)
- [ ] Error handling works correctly
- [ ] Validation prevents duplicate email/username
- [ ] JWT token is correctly validated

### Frontend
- [ ] Profile page is accessible at `/profile`
- [ ] Profile route requires authentication
- [ ] "My Profile" link appears in navbar dropdown
- [ ] Profile form loads with current user data
- [ ] Form validation works correctly
- [ ] Success/error messages display properly
- [ ] Toast notifications appear
- [ ] Responsive design works on mobile

### Emails
- [ ] Booking confirmation emails are sent
- [ ] Payment success emails are sent
- [ ] Check-in confirmation emails are sent
- [ ] Profile update emails are sent
- [ ] All emails have professional HTML templates
- [ ] Emails contain correct information
- [ ] Emails render correctly across different clients
- [ ] Email links (if any) work correctly

---

## Troubleshooting

### Emails Not Arriving
1. Check backend console logs for errors
2. Verify SMTP credentials in `appsettings.json`
3. Check spam/junk folder
4. For Gmail:
   - Enable 2-Step Verification
   - Generate and use App Password
   - Enable "Less secure app access" (if not using App Password)
5. Test with a different email provider

### Profile Page Not Loading
1. Check if user is logged in (auth token exists)
2. Open browser console for errors
3. Verify backend API is running
4. Check network tab for API call failures
5. Verify proxy configuration in `proxy.conf.json`

### API Errors
1. Check JWT token is valid (not expired)
2. Verify user ID in token matches database user
3. Check database connection
4. Review backend logs for exceptions
5. Ensure all dependencies are installed

---

## Performance Testing

### Load Testing Email Service
1. Create multiple bookings rapidly
2. Verify emails are sent for all bookings
3. Check for any delays or failures
4. Monitor backend logs for performance issues

### Stress Testing Profile Updates
1. Update profile multiple times in quick succession
2. Verify all updates are processed correctly
3. Check for race conditions
4. Verify emails are sent for each update

---

## Security Testing

### Authentication Tests
1. Try accessing `/api/User/profile` without token → Should return 401
2. Try accessing with invalid token → Should return 401
3. Try accessing with expired token → Should return 401
4. Try accessing `/profile` without login → Should redirect to login

### Authorization Tests
1. Try to update another user's profile → Should fail
2. Verify JWT token contains correct user ID
3. Check that password is never exposed in API responses

### Validation Tests
1. Try SQL injection in profile fields → Should be sanitized
2. Try XSS attacks in profile fields → Should be sanitized
3. Verify email format is validated
4. Verify username length is validated

---

## Success Criteria

✅ All features work as expected
✅ No console errors in browser
✅ No exceptions in backend logs
✅ All emails are delivered successfully
✅ Email templates render correctly
✅ Form validations work properly
✅ Error messages are clear and helpful
✅ UI is responsive and user-friendly
✅ Security measures are in place
✅ Performance is acceptable

---

## Need Help?

If you encounter any issues during testing:
1. Check the logs in the backend console
2. Check the browser console for frontend errors
3. Review the `FEATURE_IMPLEMENTATION_SUMMARY.md` for detailed implementation info
4. Verify all dependencies are installed and up to date
5. Ensure database is running and accessible
6. Check that all configuration settings are correct

Happy Testing! 🚀

