# Low Level Design - Flight Booking System

## 1. System Overview

**Purpose:** RESTful API for flight search, booking, check-in, and admin management

**Key Features:**
- JWT-based Authentication & Authorization
- Flight Search & Booking
- Online Check-in with Seat Assignment
- Admin Flight Management
- Global Exception Handling
- Swagger Documentation

---

## 2. Technology Stack

| Component | Technology | Version |
|-----------|-----------|---------|
| Framework | ASP.NET Core | 9.0 |
| Language | C# | 13.0 |
| ORM | Entity Framework Core | 9.0.9 |
| Database | SQL Server | Latest |
| Authentication | JWT Bearer | 9.0 |
| Testing | NUnit + Moq | - |
| Documentation | Swagger | - |

**Architecture:** 3-Tier Layered (Controllers → Services → Repositories → Database)  
**Design Patterns:** Repository, Dependency Injection, DTO, Middleware Pipeline

---

## 3. Project Structure

**Controllers/** - HTTP Endpoints
- AuthApiController, BookingApiController, AdminController, CheckinController

**Services/** - Business Logic
- Interfaces: IAuthService, IBookingService, IAdminService, ICheckinService, IFlightService
- Implementations: AuthService, BookingService, AdminService, CheckinService, FlightService

**Repository/** - Data Access
- Interfaces: IUserRepository, IFlightRepository, IBookingRepository
- Implementations: UserRepository, FlightRepository, BookingRepository

**Models/** - Domain & DTOs
- Domain: User, Flight, Booking
- DTOs: Request/Response objects

**Data/** - FlightDbContext.cs

**Middleware/** - GlobalExceptionMiddleware.cs

---

## 4. Database Design

### Users Table
| Column | Type | Constraints |
|--------|------|-------------|
| Id | INT | PRIMARY KEY, IDENTITY |
| Username | NVARCHAR(100) | NOT NULL |
| Password | NVARCHAR(100) | NOT NULL |

### Flights Table
| Column | Type | Constraints |
|--------|------|-------------|
| Id | INT | PRIMARY KEY, IDENTITY |
| FlightNumber | NVARCHAR(10) | NOT NULL |
| From | NVARCHAR(20) | NOT NULL |
| To | NVARCHAR(20) | NOT NULL |
| Date | DATETIME2 | NOT NULL |
| Fare | DECIMAL(10,2) | NOT NULL |

### Bookings Table
| Column | Type | Constraints |
|--------|------|-------------|
| Id | INT | PRIMARY KEY, IDENTITY |
| ReferenceNumber | NVARCHAR(50) | NOT NULL, UNIQUE |
| FlightId | INT | FOREIGN KEY → Flights(Id) |
| FirstName | NVARCHAR(100) | NOT NULL |
| LastName | NVARCHAR(100) | NOT NULL |
| Gender | NVARCHAR(10) | NOT NULL |
| BookingDate | DATETIME2 | NOT NULL, DEFAULT UtcNow |
| IsCheckedIn | BIT | DEFAULT 0 |
| SeatNumber | NVARCHAR(10) | NULL |
| CheckinDate | DATETIME2 | NULL |

**Relationships:** Flights (1) → Bookings (Many)

**Indexes:** Unique on ReferenceNumber, Index on FlightId

---

## 5. Domain Models

### User
Id (int), Username (string, max 100), Password (string, max 100)

### Flight
Id (int), FlightNumber (string, max 10), From (string, max 20), To (string, max 20), Date (DateTime), Fare (decimal)

### Booking
Id (int), ReferenceNumber (string), FlightId (int, FK), FirstName (string), LastName (string), Gender (string), BookingDate (DateTime), IsCheckedIn (bool), SeatNumber (string?), CheckinDate (DateTime?), Flight (navigation property)

---

## 6. Repository Layer

### IUserRepository
- GetByUsername(username) → User?
- GetById(id) → User?
- Add(user) → User
- Update(user) → User

### IFlightRepository
- SearchFlights(from, to, date) → List\<Flight\>
- GetById(id) → Flight?
- Add(flight) → Flight
- Update(flight) → Flight
- Delete(id) → bool

### IBookingRepository
- Add(booking) → Booking
- GetByReferenceNumber(refNum) → Booking?
- GetBookingWithFlight(refNum) → Booking? (includes Flight navigation)
- Update(booking) → Booking

---

## 7. Service Layer

### IAuthService
- **ValidateUser**(username, password) → bool: Query user, compare password
- **UserExists**(username) → bool: Check if username exists
- **RegisterUser**(user) → void: Add user to database

### IBookingService
- **CreateBooking**(request) → Booking: Validate flight exists, generate GUID reference, create booking
- **GetBookingByReference**(refNum) → Booking?: Retrieve booking

### IAdminService
- **ValidateAdmin**(username, password) → bool: Hardcoded check (admin/admin123)
- **CreateFlight**(request) → Flight: Map and add flight
- **UpdateFlight**(request) → Flight: Get by ID, update properties, save
- **DeleteFlight**(id) → bool: Delete flight
- **UpdateUser**(request) → User: Get by ID, check username availability, update

### ICheckinService
- **SearchBooking**(bookingRef) → BookingSearchResponse?: Get booking with flight, map to DTO
- **PerformCheckin**(bookingRef) → CheckinResponse: Validate (exists, not checked in, future flight), generate seat (1-39 + A-F), update booking

### IFlightService
- **SearchFlights**(from, to, date) → List\<Flight\>: Query matching flights

---

## 8. Controller Endpoints

### AuthApiController
| Route | Method | Auth | Action |
|-------|--------|------|--------|
| /api/AuthApi/signup | POST | None | Check username exists → Create user → Return success |
| /api/AuthApi/signin | POST | None | Validate credentials → Generate JWT (1hr) → Return token |

### BookingApiController
| Route | Method | Auth | Action |
|-------|--------|------|--------|
| /api/BookingApi/search | POST | None | Search flights → Return list |
| /api/BookingApi/create | POST | JWT | Validate token → Create booking → Return booking |

### AdminController
| Route | Method | Auth | Action |
|-------|--------|------|--------|
| /api/Admin/login | POST | None | Validate admin → Generate JWT with role (2hr) → Return token |
| /api/Admin/flights | POST | JWT | Create flight → Return flight |
| /api/Admin/flights | PUT | JWT | Update flight → Return updated flight |
| /api/Admin/flights/{id} | DELETE | JWT | Delete flight → Return success/404 |
| /api/Admin/users | PUT | JWT | Update user → Return updated user |

### CheckinController
| Route | Method | Auth | Action |
|-------|--------|------|--------|
| /api/Checkin/search | POST | None | Search booking → Return booking details |
| /api/Checkin/perform | POST | None | Perform check-in → Return confirmation with seat |
| /api/Checkin/status/{ref} | GET | None | Get check-in status → Return status |

---

## 9. DTOs

### Request DTOs
UserRegisterRequest, UserLoginRequest, AdminLoginRequest, SearchRequest, BookingRequest, CreateFlightRequest, UpdateFlightRequest, UpdateUserRequest, BookingSearchRequest, CheckinRequest

### Response DTOs
BookingSearchResponse (BookingId, BookingReference, FlightNumber, From, To, FlightDate, PassengerName, Gender, IsCheckedIn, SeatNumber, CheckinId)

CheckinResponse (CheckinId, BookingReference, SeatNumber, PassengerName, FlightNumber, CheckinDate, Message)

---

## 10. Middleware - GlobalExceptionMiddleware

**Purpose:** Centralized exception handling

**Process:**
1. Wrap request in try-catch
2. If exception: determine status code, format response, return JSON

**Exception Mapping:**
- ArgumentException → 400 Bad Request
- KeyNotFoundException → 404 Not Found
- UnauthorizedAccessException → 401 Unauthorized
- Others → 500 Internal Server Error

**Response Format:** { error: "message", statusCode: 400, timestamp: "2025-10-11T15:30:00Z" }

---

## 11. Key Flows

### User Registration
Client → AuthApiController → AuthService.UserExists → UserRepository → Database → AuthService.RegisterUser → UserRepository.Add → Database → Return success

### User Login
Client → AuthApiController → AuthService.ValidateUser → UserRepository.GetByUsername → Database → Compare password → Generate JWT (username, JWT ID, HMAC-SHA256, 1hr expiration) → Return token

### Flight Booking
Client → BookingApiController.SearchFlights → FlightService → FlightRepository → Database → Return flights → Client selects → BookingApiController.CreateBooking (JWT validated) → BookingService validates flight → Generate GUID → BookingRepository.Add → Database → Return booking with reference

### Check-in
Client → CheckinController.SearchBooking → CheckinService → BookingRepository.GetBookingWithFlight (JOIN query) → Map to DTO → Return details → Client clicks check-in → CheckinController.PerformCheckin → Validate (exists, not checked in, future date) → Generate random seat (1-39 + A-F) → Update booking (IsCheckedIn=true, SeatNumber, CheckinDate) → Return confirmation

### Admin Operations
Admin → AdminController.Login → Validate (admin/admin123) → Generate JWT with Admin role (2hr) → Admin creates/updates/deletes flight → JWT validated → AdminService → FlightRepository → Database → Return result

### Exception Handling
Request → GlobalExceptionMiddleware (try) → Controller → Service throws exception → Middleware (catch) → Map exception type to status code → Create error response → Serialize JSON → Return to client

---

## 12. Design Patterns

**Repository Pattern:** Abstract data access, easy mocking, separates concerns

**Dependency Injection:** Constructor injection, scoped lifetime, registered in Program.cs

**DTO Pattern:** Separate internal models from API contracts, security, simplicity

**Middleware Pipeline:** Chain of responsibility (Exception → Auth → Authorization → Controllers)

**Service Layer:** Business logic separate from HTTP concerns, reusable, testable

---

## 13. Security

### JWT Authentication
- **Algorithm:** HMAC-SHA256
- **User Token:** Claims (sub: username, jti: GUID, exp: 1hr), Issuer: FlightBookingApp
- **Admin Token:** Same + role: "Admin", exp: 2hr

### Token Generation
Create claims → Create signing key → Create token (issuer, audience, claims, expiration, credentials) → Serialize → Return

### Token Validation
Extract from header → Verify signature → Check issuer/audience → Verify not expired → Success

### Authorization
**Public:** signup, signin, admin login, search flights, check-in endpoints  
**Protected (JWT):** create booking, admin CRUD operations

### Security Issues & Recommendations
**Current:** Plain text passwords, hardcoded admin, no refresh tokens, no rate limiting  
**Production:** Use BCrypt/Argon2, HTTPS only, refresh tokens, rate limiting, DB-driven admin accounts

---

## 14. Error Handling

### Validation Layers
1. **Model Validation:** Data annotations (Required, MaxLength)
2. **Controller Validation:** Null checks, ModelState, required fields
3. **Service Validation:** Business rules, entity existence, data integrity

### Exception Strategy
Services throw specific exceptions (ArgumentException, KeyNotFoundException) → GlobalExceptionMiddleware catches → Maps to HTTP status → Returns formatted JSON error

---

## 15. Configuration

**appsettings.json:**
- ConnectionStrings.DefaultConnection: SQL Server connection
- Jwt.Key: Secret for signing
- Jwt.Issuer: Token issuer
- Logging settings

**Dependency Registration (Program.cs):**
1. Repositories (Scoped)
2. Services (Scoped)
3. Controllers
4. Swagger
5. DbContext
6. Authentication (JWT Bearer)

**Middleware Pipeline:**
GlobalExceptionMiddleware (first) → Authentication → Authorization → MapControllers

**Database Initialization:** EnsureCreated() on startup

---

## 16. API Request/Response Examples

### POST /api/AuthApi/signup
Request: { username, password }  
Success (200): "User registered successfully."  
Error (400): "Username already exists."

### POST /api/AuthApi/signin
Request: { username, password }  
Success (200): { token: "JWT..." }  
Error (401): "Invalid credentials."

### POST /api/BookingApi/search
Request: { from: "NYC", to: "SFO", date: "2016-01-22" }  
Success (200): [{ id: 1, flightNumber: "BF101", from: "NYC", to: "SFO", date, fare: 101 }, ...]

### POST /api/BookingApi/create (JWT required)
Request: { flightId: 1, firstName: "John", lastName: "Doe", gender: "M" }  
Success (200): { id: 15, referenceNumber: "guid...", flightId: 1, firstName, lastName, gender, bookingDate, isCheckedIn: false, seatNumber: null, ... }

### POST /api/Checkin/perform
Request: { bookingReference: "guid..." }  
Success (200): { message: "Check-in completed!", checkin: { checkinId: 15, bookingReference, seatNumber: "23C", passengerName, flightNumber, checkinDate, message } }

### POST /api/Admin/flights (JWT required)
Request: { flightNumber: "BF201", from: "NYC", to: "LAX", date, fare: 299.99 }  
Success (200): { id: 10, flightNumber: "BF201", from, to, date, fare }

---

## Summary

**Architecture:** 3-tier layered system (Controllers → Services → Repositories → SQL Server)

**Database:** 3 tables (Users, Flights, Bookings) with proper constraints and foreign keys

**API:** 15+ RESTful endpoints with JWT authentication

**Design:** Repository pattern, DI, DTO, Middleware pipeline, Service layer separation

**Security:** JWT-based auth (HMAC-SHA256), role-based authorization, token expiration

**Error Handling:** Global exception middleware with appropriate HTTP status codes

**Testing:** NUnit + Moq for unit tests

This document provides technical specifications for implementation and maintenance.

---

**Version:** 1.0 | **Date:** October 11, 2025