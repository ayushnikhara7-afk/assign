using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models
{
    public class Booking
    {
        public int Id { get; set; }
        
        [Required]
        public string ReferenceNumber { get; set; } = string.Empty;
        
        [Required]
        public int FlightId { get; set; }
        
        [Required]
        public string FirstName { get; set; } = string.Empty;
        
        [Required]
        public string LastName { get; set; } = string.Empty;
        
        [Required]
        public string Gender { get; set; } = string.Empty;
        
        public DateTime BookingDate { get; set; } = DateTime.UtcNow;
        
        // Navigation property
        public Flight? Flight { get; set; }
    }
}
