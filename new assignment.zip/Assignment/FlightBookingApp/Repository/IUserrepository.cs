using FlightBookingApp.Models;

namespace FlightBookingApp.Repository
{
    public interface IUserRepository
    {
        User GetByUsername(string username);
        void Add(User user);
    }
}