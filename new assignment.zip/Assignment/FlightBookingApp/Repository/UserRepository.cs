using FlightBookingApp.Data;
using FlightBookingApp.Models;
using System.Linq;

namespace FlightBookingApp.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly FlightDbContext _context;
        public UserRepository(FlightDbContext context) => _context = context;

        public User? GetByUsername(string username) => _context.Users.FirstOrDefault(u => u.Username == username);

        public void Add(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }
    }
}