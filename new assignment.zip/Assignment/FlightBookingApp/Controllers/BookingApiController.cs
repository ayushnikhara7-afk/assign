using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FlightBookingApp.Data;
using FlightBookingApp.Models;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.AspNetCore.Authorization;

namespace FlightBookingApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookingApiController : ControllerBase
    {
        private readonly FlightDbContext _context;

        public BookingApiController(FlightDbContext context)
        {
            _context = context;
        }

        [HttpPost("search")]
        public IActionResult SearchFlights([FromBody] SearchRequest request)
        {
            var flights = _context.Flights
                .Where(f => f.From == request.From &&
                           f.To == request.To &&
                           f.Date.Date == request.Date.Date)
                .OrderBy(f => f.Fare)
                .ToList();

            return Ok(flights);
        }

        // public IActionResult BookFlight(int flightId)
        // {
        //     var flight = _context.Flights.Find(flightId);
        //     ViewBag.Flight = flight;
        //     return View();
        // }
        [Authorize]
        [HttpPost("create")]
        public IActionResult CreateBooking([FromBody] BookingRequest request)
        {
            var flight = _context.Flights.Find(request.FlightId);

            var referenceNumber = Guid.NewGuid().ToString();

            var booking = new Booking
            {
                ReferenceNumber = referenceNumber,
                FlightId = request.FlightId,
                FirstName = request.FirstName,
                LastName = request.LastName,
                Gender = request.Gender,
                BookingDate = DateTime.UtcNow
            };
            _context.Bookings.Add(booking);
            _context.SaveChanges();
            return Ok(booking);
        }
    }
}
