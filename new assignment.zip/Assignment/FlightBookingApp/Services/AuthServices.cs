using FlightBookingApp.Models;
using FlightBookingApp.Repository;

namespace FlightBookingApp.Services
{
    public class AuthService
    {
        private readonly IUserRepository _userRepo;
        public AuthService(IUserRepository userRepo) => _userRepo = userRepo;

        public bool ValidateUser(string username, string password)
        {
            var user = _userRepo.GetByUsername(username);
            return user != null && user.Password == password;
        }

        public bool UserExists(string username)
        {
            return _userRepo.GetByUsername(username) != null;
        }

        public void RegisterUser(User user)
        {
            _userRepo.Add(user);
        }
    }
}