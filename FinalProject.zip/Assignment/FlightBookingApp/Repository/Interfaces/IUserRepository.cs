using FlightBookingApp.Models.Domain;

namespace FlightBookingApp.Repository.Interfaces
{
    public interface IUserRepository
    {
        User? GetByUsername(string username);
        void Add(User user);
        User Update(User user);
    }
}

