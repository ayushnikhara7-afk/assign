using NUnit.Framework;
using Moq;
using FlightBookingApp.Controllers;
using FlightBookingApp.Services.Interfaces;
using FlightBookingApp.Models.DTOs;
using Microsoft.AspNetCore.Mvc;

namespace FlightBookingApp.Tests
{
    // This attribute tells NUnit this class contains tests
    [TestFixture]
    public class BookingApiControllerTests
    {
        // This is a test method
        [Test]
        public void CreateBooking_ValidRequest_ReturnsOkResult()
        {
            var mockFlightService = new Mock<IFlightService>();
            var request = new BookingRequest { FlightId = 1, FirstName = "John", LastName = "Doe", Gender = "M" };
            var booking = new FlightBookingApp.Models.Domain.Booking { ReferenceNumber = "ABC123", FirstName = "John", LastName = "Doe" };

            // ✅ Setup mock to return booking
            mockFlightService
                .Setup(s => s.CreateBooking(It.IsAny<BookingRequest>()))
                .Returns(booking);

            var controller = new BookingApiController(mockFlightService.Object);

            var result = controller.CreateBooking(request);
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(booking, okResult.Value);
        }
    }
} 
