using NUnit.Framework;
using Moq;
using Microsoft.AspNetCore.Mvc;
using FlightBookingApp.Controllers;
using FlightBookingApp.Services.Interfaces;
using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;
using Microsoft.Extensions.Configuration;

namespace FlightBookingApp.Tests.Controllers
{
    /// <summary>
    /// Unit tests for AuthApiController - 3 Essential Tests
    /// </summary>
    [TestFixture]
    public class AuthApiControllerTests
    {
        private Mock<IAuthService> _mockAuthService;
        private Mock<IConfiguration> _mockConfig;
        private AuthApiController _controller;

        [SetUp]
        public void Setup()
        {
            _mockAuthService = new Mock<IAuthService>();
            _mockConfig = new Mock<IConfiguration>();
            
            _mockConfig.Setup(c => c["Jwt:Key"]).Returns("ThisIsASecretKeyForJwtTokenGeneration123456");
            _mockConfig.Setup(c => c["Jwt:Issuer"]).Returns("FlightBookingApp");
            
            _controller = new AuthApiController(_mockAuthService.Object, _mockConfig.Object);
        }

        [Test]
        public void SignUp_WithNewUser_ReturnsOkWithSuccessMessage()
        {
            // Arrange
            var request = new UserRegisterRequest
            {
                Username = "newuser",
                Password = "password123"
            };

            _mockAuthService.Setup(s => s.UserExists(request.Username)).Returns(false);
            _mockAuthService.Setup(s => s.RegisterUser(It.IsAny<User>()));

            // Act
            var result = _controller.SignUp(request);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var okResult = result as OkObjectResult;
            Assert.That(okResult!.Value, Is.EqualTo("User registered successfully."));
            _mockAuthService.Verify(s => s.UserExists(request.Username), Times.Once);
        }

        [Test]
        public void SignUp_WithExistingUsername_ReturnsBadRequest()
        {
            // Arrange
            var request = new UserRegisterRequest
            {
                Username = "existinguser",
                Password = "password123"
            };

            _mockAuthService.Setup(s => s.UserExists(request.Username)).Returns(true);

            // Act
            var result = _controller.SignUp(request);

            // Assert
            Assert.That(result, Is.InstanceOf<BadRequestObjectResult>());
            var badRequestResult = result as BadRequestObjectResult;
            Assert.That(badRequestResult!.Value, Is.EqualTo("Username already exists."));
        }

        [Test]
        public void SignIn_WithValidCredentials_ReturnsOkWithToken()
        {
            // Arrange
            var request = new UserLoginRequest
            {
                Username = "testuser",
                Password = "password123"
            };

            _mockAuthService.Setup(s => s.ValidateUser(request.Username, request.Password)).Returns(true);

            // Act
            var result = _controller.SignIn(request);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            _mockAuthService.Verify(s => s.ValidateUser(request.Username, request.Password), Times.Once);
        }

        [TearDown]
        public void TearDown()
        {
            _controller = null!;
            _mockAuthService = null!;
            _mockConfig = null!;
        }
    }
}
