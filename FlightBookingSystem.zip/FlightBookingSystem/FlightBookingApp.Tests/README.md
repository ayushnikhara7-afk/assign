# FlightBookingApp Unit Tests

## 📋 Overview

This project contains **12 comprehensive unit tests** (3 tests per controller) covering all 4 controllers in the Flight Booking Application.

## 🧪 Test Coverage

### Test Files and Structure

```
FlightBookingApp.Tests/
└── Controllers/
    ├── AdminControllerTests.cs         (3 tests)
    ├── AuthApiControllerTests.cs       (3 tests)
    ├── BookingApiControllerTests.cs    (3 tests)
    └── CheckinControllerTests.cs       (3 tests)
```

### Detailed Test Coverage

| Controller | Test # | Test Name | What It Tests |
|------------|--------|-----------|---------------|
| **AdminController** | 1 | `AdminLogin_WithValidCredentials_ReturnsOkWithToken` | Admin authentication |
| | 2 | `CreateFlight_WithValidRequest_ReturnsOkWithFlight` | Creating new flights |
| | 3 | `DeleteFlight_WithExistingId_ReturnsOk` | Deleting flights |
| **AuthApiController** | 1 | `SignUp_WithNewUser_ReturnsOkWithSuccessMessage` | User registration |
| | 2 | `SignUp_WithExistingUsername_ReturnsBadRequest` | Duplicate username validation |
| | 3 | `SignIn_WithValidCredentials_ReturnsOkWithToken` | User authentication |
| **BookingApiController** | 1 | `SearchFlights_WithValidRequest_ReturnsOkWithFlightList` | Flight search |
| | 2 | `SearchFlights_WithNoResults_ReturnsOkWithEmptyList` | Empty search results |
| | 3 | `CreateBooking_WithValidRequest_ReturnsOkWithBooking` | Booking creation |
| **CheckinController** | 1 | `SearchBooking_WithValidReference_ReturnsOkWithBooking` | Booking search |
| | 2 | `SearchBooking_WithInvalidReference_ReturnsNotFound` | Invalid booking reference |
| | 3 | `PerformCheckin_WithValidReference_ReturnsOkWithCheckinDetails` | Check-in process |

**Total: 12 Unit Tests**

## 🚀 How to Run Tests

### Using Command Line

```bash
# Navigate to test directory
cd FlightBookingApp.Tests

# Restore packages (first time only)
dotnet restore

# Build the project
dotnet build

# Run all tests
dotnet test

# Run with detailed output
dotnet test --logger "console;verbosity=detailed"

# Run tests from a specific file
dotnet test --filter "FullyQualifiedName~AdminControllerTests"
```

### Using Visual Studio

1. Open the solution in Visual Studio
2. Open **Test Explorer** (`Test` → `Test Explorer` or `Ctrl+E, T`)
3. Click "Run All Tests" button (▶️)
4. View results in the Test Explorer window

### Using Visual Studio Code

1. Install the **".NET Core Test Explorer"** extension
2. Tests will appear in the Test sidebar
3. Click the play button (▶️) to run tests

## ✅ Expected Output

When all tests pass, you should see:

```
Passed!  - Failed:  0, Passed: 12, Skipped:  0, Total: 12, Duration: < 2 s
```

## 📦 Dependencies

- **NUnit 4.2.2** - Testing framework
- **Moq 4.20.72** - Mocking library for dependencies
- **Microsoft.NET.Test.Sdk 18.0.0** - Test SDK
- **Microsoft.Extensions.Configuration** - For configuration mocking

## 🎯 Testing Approach

### AAA Pattern

All tests follow the **Arrange-Act-Assert** pattern:

```csharp
[Test]
public void MethodName_Scenario_ExpectedResult()
{
    // Arrange: Set up test data and mock objects
    var request = new SomeRequest { ... };
    _mockService.Setup(s => s.Method()).Returns(expectedValue);
    
    // Act: Execute the method being tested
    var result = _controller.Method(request);
    
    // Assert: Verify the expected results
    Assert.That(result, Is.InstanceOf<OkObjectResult>());
    _mockService.Verify(s => s.Method(), Times.Once);
}
```

### Mocking Strategy

- **Services are mocked** - No real database or external dependencies
- **Configuration is mocked** - JWT settings provided via mock
- **Fast execution** - All tests run in memory
- **Isolated tests** - Each test is independent

## 📊 Test Statistics

| Metric | Value |
|--------|-------|
| **Total Tests** | 12 |
| **Controllers Tested** | 4 |
| **Tests per Controller** | 3 |
| **Test Files** | 4 |
| **Coverage Areas** | Authentication, Booking, Check-in, Admin Operations |

## 🔧 Troubleshooting

### Tests Not Discovered
**Solution**: Run `dotnet restore` and rebuild the solution

### Build Errors
**Solution**: 
- Ensure the main FlightBookingApp project builds successfully
- Check that all NuGet packages are restored
- Verify .NET 8.0 SDK is installed

### Test Failures
**Solution**:
- Check that the controller implementations match the test expectations
- Verify mock setups are correct
- Ensure DTOs and models match between main app and tests

### Configuration Errors
**Solution**: Mock configuration keys must match the ones used in controllers (Jwt:Key, Jwt:Issuer)

## 📝 Adding More Tests

To add additional tests, follow the existing pattern:

```csharp
[Test]
public void MethodName_Scenario_ExpectedResult()
{
    // Arrange
    var mockService = new Mock<IService>();
    var controller = new Controller(mockService.Object);
    var request = new Request { };
    mockService.Setup(s => s.Method()).Returns(expectedValue);
    
    // Act
    var result = controller.Method(request);
    
    // Assert
    Assert.That(result, Is.InstanceOf<OkObjectResult>());
    mockService.Verify(s => s.Method(), Times.Once);
}
```

## 🎓 Best Practices Demonstrated

✅ **Test Isolation** - Each test sets up its own mocks  
✅ **Clear Naming** - Test names describe scenario and expected outcome  
✅ **Setup/Teardown** - `[SetUp]` and `[TearDown]` for consistency  
✅ **Verification** - Mocks are verified to ensure methods were called  
✅ **Assertion Types** - Uses NUnit constraint model (`Is.`, `Is.Not.`)  

## 🏆 Test Quality

- ✅ All tests are **independent** (no shared state)
- ✅ Tests are **fast** (< 2 seconds for all 12 tests)
- ✅ Tests are **readable** (clear arrange-act-assert structure)
- ✅ Tests are **maintainable** (easy to update when code changes)
- ✅ Tests are **reliable** (no random failures)

---

**Last Updated**: October 2025  
**Framework**: NUnit 4.2.2 with Moq  
**Test Count**: 12 tests across 4 controllers  
**Status**: ✅ All tests passing
