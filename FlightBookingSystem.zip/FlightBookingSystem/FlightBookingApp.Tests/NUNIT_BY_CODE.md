# NUnit Testing - Learn By Code Examples

## Basic Test Structure

```csharp
using NUnit.Framework;
using Moq;

[TestFixture]  // Marks class as containing tests
public class MyTests
{
    private Mock<IService> _mockService;
    private MyController _controller;

    [SetUp]  // Runs before each test
    public void Setup()
    {
        _mockService = new Mock<IService>();
        _controller = new MyController(_mockService.Object);
    }

    [Test]  // Marks a test method
    public void MethodName_Scenario_ExpectedResult()
    {
        // ARRANGE: Setup
        var input = new Request { };
        _mockService.Setup(s => s.Method()).Returns(output);

        // ACT: Execute
        var result = _controller.Method(input);

        // ASSERT: Verify
        Assert.That(result, Is.Not.Null);
    }

    [TearDown]  // Runs after each test
    public void TearDown()
    {
        _controller = null!;
    }
}
```

## Assertions (Checking Results)

```csharp
// Check not null
Assert.That(result, Is.Not.Null);

// Check equals
Assert.That(actual, Is.EqualTo(expected));
Assert.That(user.Name, Is.EqualTo("John"));

// Check type
Assert.That(result, Is.InstanceOf<OkObjectResult>());

// Check true/false
Assert.That(isValid, Is.True);
Assert.That(isDeleted, Is.False);

// Check greater/less
Assert.That(count, Is.GreaterThan(0));
Assert.That(price, Is.LessThan(1000));

// Check collection
Assert.That(list.Count, Is.EqualTo(5));
Assert.That(list, Is.Empty);
Assert.That(list, Is.Not.Empty);
```

## Mocking with Moq

```csharp
// Create mock
var mockService = new Mock<IAuthService>();

// Setup: Return a value
mockService.Setup(s => s.GetUser(1)).Returns(user);

// Setup: Return null
mockService.Setup(s => s.GetUser(999)).Returns((User?)null);

// Setup: Match any parameter
mockService.Setup(s => s.Create(It.IsAny<User>())).Returns(user);

// Setup: Throw exception
mockService.Setup(s => s.Delete(999)).Throws(new Exception("Not found"));

// Verify method was called
mockService.Verify(s => s.GetUser(1), Times.Once);
mockService.Verify(s => s.Delete(1), Times.Never);
```

## Example 1: Testing Success Case

```csharp
[Test]
public void SignUp_WithNewUser_ReturnsOk()
{
    // ARRANGE
    var request = new UserRegisterRequest 
    { 
        Username = "john", 
        Password = "pass123" 
    };
    
    _mockAuthService.Setup(s => s.UserExists("john")).Returns(false);

    // ACT
    var result = _controller.SignUp(request);

    // ASSERT
    Assert.That(result, Is.InstanceOf<OkObjectResult>());
    var okResult = result as OkObjectResult;
    Assert.That(okResult!.Value, Is.EqualTo("User registered successfully."));
}
```

## Example 2: Testing Error Case

```csharp
[Test]
public void SignUp_WithExistingUser_ReturnsBadRequest()
{
    // ARRANGE
    var request = new UserRegisterRequest 
    { 
        Username = "john", 
        Password = "pass123" 
    };
    
    _mockAuthService.Setup(s => s.UserExists("john")).Returns(true);

    // ACT
    var result = _controller.SignUp(request);

    // ASSERT
    Assert.That(result, Is.InstanceOf<BadRequestObjectResult>());
    var badResult = result as BadRequestObjectResult;
    Assert.That(badResult!.Value, Is.EqualTo("Username already exists."));
}
```

## Example 3: Testing Exception

```csharp
[Test]
public void CreateFlight_WithInvalidData_ThrowsException()
{
    // ARRANGE
    var request = new CreateFlightRequest { };
    _mockAdminService.Setup(s => s.CreateFlight(request))
        .Throws(new ArgumentException("Invalid flight data"));

    // ACT & ASSERT
    var ex = Assert.Throws<ArgumentException>(() => _controller.CreateFlight(request));
    Assert.That(ex.Message, Is.EqualTo("Invalid flight data"));
}
```

## Example 4: Verifying Method Calls

```csharp
[Test]
public void DeleteFlight_CallsServiceOnce()
{
    // ARRANGE
    _mockAdminService.Setup(s => s.DeleteFlight(1)).Returns(true);

    // ACT
    _controller.DeleteFlight(1);

    // ASSERT
    _mockAdminService.Verify(s => s.DeleteFlight(1), Times.Once);
}
```

## Example 5: Testing Return Values

```csharp
[Test]
public void CreateBooking_ReturnsBookingWithReferenceNumber()
{
    // ARRANGE
    var request = new BookingRequest { FlightId = 1 };
    var booking = new Booking 
    { 
        ReferenceNumber = "ABC123",
        FlightId = 1 
    };
    
    _mockBookingService.Setup(s => s.CreateBooking(request)).Returns(booking);

    // ACT
    var result = _controller.CreateBooking(request);

    // ASSERT
    var okResult = result as OkObjectResult;
    var returnedBooking = okResult!.Value as Booking;
    Assert.That(returnedBooking!.ReferenceNumber, Is.EqualTo("ABC123"));
}
```

## Running Tests

```bash
# Run all tests
dotnet test

# Run specific test
dotnet test --filter "SignUp_WithNewUser_ReturnsOk"

# Run all tests in a class
dotnet test --filter "AdminControllerTests"

# Detailed output
dotnet test --logger "console;verbosity=detailed"
```

## Common Patterns

### Pattern 1: Test HTTP Response Type
```csharp
var result = _controller.Method();
Assert.That(result, Is.InstanceOf<OkObjectResult>());          // 200
Assert.That(result, Is.InstanceOf<BadRequestObjectResult>());  // 400
Assert.That(result, Is.InstanceOf<NotFoundObjectResult>());    // 404
Assert.That(result, Is.InstanceOf<UnauthorizedObjectResult>()); // 401
```

### Pattern 2: Test and Verify
```csharp
// Act
var result = _controller.Method();

// Assert result
Assert.That(result, Is.InstanceOf<OkObjectResult>());

// Verify service was called
_mockService.Verify(s => s.Method(), Times.Once);
```

### Pattern 3: Test Collection Count
```csharp
var flights = new List<Flight> { flight1, flight2 };
_mockService.Setup(s => s.SearchFlights()).Returns(flights);

var result = _controller.SearchFlights();

var okResult = result as OkObjectResult;
var list = okResult!.Value as List<Flight>;
Assert.That(list!.Count, Is.EqualTo(2));
```

## Your Actual Test Explained

```csharp
[Test]
public void AdminLogin_WithValidCredentials_ReturnsOkWithToken()
{
    // Create login request
    var request = new AdminLoginRequest
    {
        Username = "admin",
        Password = "admin123"
    };

    // Tell mock: "These credentials are valid"
    _mockAdminService.Setup(s => s.ValidateAdmin("admin", "admin123")).Returns(true);

    // Call the login method
    var result = _controller.AdminLogin(request);

    // Check: Is it OK response?
    Assert.That(result, Is.InstanceOf<OkObjectResult>());
    
    // Verify: Was ValidateAdmin called?
    _mockAdminService.Verify(s => s.ValidateAdmin("admin", "admin123"), Times.Once);
}
```

**What happens:**
1. We create a login request
2. We fake the service to say "valid credentials"
3. We call AdminLogin
4. We check it returns OK (200)
5. We verify the service was called once

## Practice Template

Copy this and fill in the blanks:

```csharp
[Test]
public void YourMethod_YourScenario_YourExpected()
{
    // ARRANGE
    var request = new YourRequest { /* data here */ };
    _mockService.Setup(s => s.YourMethod(/* params */)).Returns(/* result */);

    // ACT
    var result = _controller.YourMethod(request);

    // ASSERT
    Assert.That(result, Is.InstanceOf</* ResultType */>());
    _mockService.Verify(s => s.YourMethod(/* params */), Times.Once);
}
```

## Key Points

✅ `[TestFixture]` = Test class  
✅ `[Test]` = Test method  
✅ `[SetUp]` = Run before each test  
✅ `Mock<T>` = Fake object  
✅ `.Setup()` = Tell mock what to return  
✅ `.Verify()` = Check method was called  
✅ `Assert.That()` = Check result  

That's it! Now look at your test files and try to understand them using these patterns.