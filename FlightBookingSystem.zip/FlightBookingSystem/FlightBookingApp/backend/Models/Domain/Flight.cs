using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models.Domain
{
    public class Flight
    {
        public int Id { get; set; }
        
        [Required]
        [MaxLength(10)]
        public string FlightNumber { get; set; } = string.Empty;
        
        [Required]
        [MaxLength(20)]
        public string From { get; set; } = string.Empty;
        
        [Required]
        [MaxLength(20)]
        public string To { get; set; } = string.Empty;
        
        [Required]
        public DateTime Date { get; set; }
        
        public decimal Fare { get; set; }
        
    }
}

