namespace FlightBookingApp.Models.DTOs
{
    public class BookingSearchResponse
    {
        public int BookingId { get; set; }
        public string BookingReference { get; set; } = string.Empty;
        public string FlightNumber { get; set; } = string.Empty;
        public string From { get; set; } = string.Empty;
        public string To { get; set; } = string.Empty;
        public DateTime FlightDate { get; set; }
        public string PassengerName { get; set; } = string.Empty;
        public string Gender { get; set; } = string.Empty;
        public bool IsCheckedIn { get; set; }
        public string? SeatNumber { get; set; }
        public int? CheckinId { get; set; }
    }
}
