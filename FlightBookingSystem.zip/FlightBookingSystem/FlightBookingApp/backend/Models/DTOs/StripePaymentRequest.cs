namespace FlightBookingApp.Models.DTOs
{
    public class StripePaymentRequest
    {
        public string PaymentIntentId { get; set; } = string.Empty;
    }

    public class PaymentIntentResponse
    {
        public string ClientSecret { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public string Currency { get; set; } = "usd";
        public string Message { get; set; } = string.Empty;
    }
}

