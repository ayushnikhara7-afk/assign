using FlightBookingApp.Models.Domain;

namespace FlightBookingApp.Services.Interfaces
{
    public interface IAuthService
    {
        bool ValidateUser(string username, string password);
        bool UserExists(string username);
        bool EmailExists(string email);
        void RegisterUser(User user);
        bool ResetPassword(string email, string newPassword);
        User? GetUserByEmail(string email);
        User? GetUserByUsername(string username);
    }
}

