using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;

namespace FlightBookingApp.Services.Interfaces
{
    public interface IBookingService
    {
        Booking CreateBooking(BookingRequest request, int? userId = null);
        Booking? GetBookingByReference(string referenceNumber);
        List<Booking> GetUserBookings(int userId);
        bool CancelBooking(string referenceNumber);
        Task<string> CreatePaymentIntentAsync(string referenceNumber);
        Task<bool> ConfirmPaymentAsync(string referenceNumber, string paymentIntentId);
    }
}

