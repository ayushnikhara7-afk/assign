using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;

namespace FlightBookingApp.Services.Interfaces
{
    public interface IBookingService
    {
        Booking CreateBooking(BookingRequest request);
        Booking? GetBookingByReference(string referenceNumber);
        bool CancelBooking(string referenceNumber);
        bool ProcessPayment(string referenceNumber, PaymentRequest paymentRequest);
    }
}

