namespace FlightBookingApp.Services.Interfaces
{
    public interface IStripeService
    {
        Task<string> CreatePaymentIntentAsync(decimal amount, string currency, string description, Dictionary<string, string>? metadata = null);
        Task<bool> ConfirmPaymentAsync(string paymentIntentId);
        Task<string> GetPaymentStatusAsync(string paymentIntentId);
    }
}

