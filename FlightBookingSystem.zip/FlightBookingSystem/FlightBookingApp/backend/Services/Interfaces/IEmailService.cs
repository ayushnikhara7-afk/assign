namespace FlightBookingApp.Services.Interfaces
{
    public interface IEmailService
    {
        Task SendEmailAsync(string toEmail, string subject, string htmlBody);
        Task SendWelcomeEmailAsync(string toEmail, string userName);
        Task SendBookingConfirmationAsync(string toEmail, string passengerName, string referenceNumber, string flightNumber, string from, string to, DateTime flightDate);
        Task SendPasswordResetEmailAsync(string toEmail, string userName);
    }
}

