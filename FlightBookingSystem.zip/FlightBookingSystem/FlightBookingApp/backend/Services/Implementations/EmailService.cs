using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Options;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Services.Implementations
{
    public class EmailService : IEmailService
    {
        private readonly EmailSettings _emailSettings;
        private readonly ILogger<EmailService> _logger;

        public EmailService(IOptions<EmailSettings> emailSettings, ILogger<EmailService> logger)
        {
            _emailSettings = emailSettings.Value;
            _logger = logger;
        }

        public async Task SendEmailAsync(string toEmail, string subject, string htmlBody)
        {
            try
            {
                using var smtpClient = new SmtpClient(_emailSettings.SmtpServer, _emailSettings.SmtpPort)
                {
                    EnableSsl = _emailSettings.EnableSsl,
                    Credentials = new NetworkCredential(_emailSettings.Username, _emailSettings.Password)
                };

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(_emailSettings.SenderEmail, _emailSettings.SenderName),
                    Subject = subject,
                    Body = htmlBody,
                    IsBodyHtml = true
                };

                mailMessage.To.Add(toEmail);

                await smtpClient.SendMailAsync(mailMessage);
                _logger.LogInformation($"Email sent successfully to {toEmail}");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to send email to {toEmail}: {ex.Message}");
                // Don't throw exception - just log it so app continues working even if email fails
            }
        }

        public async Task SendWelcomeEmailAsync(string toEmail, string userName)
        {
            var subject = "Welcome to Flight Booking System!";
            var htmlBody = $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
                        .button {{ display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }}
                        .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 12px; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h1>Welcome to Flight Booking System!</h1>
                        </div>
                        <div class='content'>
                            <h2>Hello {userName}!</h2>
                            <p>Thank you for registering with Flight Booking System. We're excited to have you on board!</p>
                            <p>With your account, you can:</p>
                            <ul>
                                <li>Search and book flights</li>
                                <li>Manage your bookings</li>
                                <li>Check-in online</li>
                                <li>View your travel history</li>
                            </ul>
                            <p>Start exploring destinations and book your next adventure today!</p>
                            <a href='#' class='button'>Start Booking</a>
                        </div>
                        <div class='footer'>
                            <p>© 2025 Flight Booking System. All rights reserved.</p>
                        </div>
                    </div>
                </body>
                </html>
            ";

            await SendEmailAsync(toEmail, subject, htmlBody);
        }

        public async Task SendBookingConfirmationAsync(string toEmail, string passengerName, string referenceNumber, string flightNumber, string from, string to, DateTime flightDate)
        {
            var subject = $"Booking Confirmation - {referenceNumber}";
            var htmlBody = $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
                        .booking-details {{ background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }}
                        .detail-row {{ display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; }}
                        .detail-label {{ font-weight: bold; color: #667eea; }}
                        .reference {{ font-size: 24px; font-weight: bold; color: #667eea; text-align: center; padding: 20px; background: white; border-radius: 8px; margin: 20px 0; }}
                        .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 12px; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h1>✈️ Booking Confirmed!</h1>
                        </div>
                        <div class='content'>
                            <h2>Hello {passengerName}!</h2>
                            <p>Your flight booking has been confirmed. Please save this email for your records.</p>
                            
                            <div class='reference'>
                                Booking Reference: {referenceNumber}
                            </div>

                            <div class='booking-details'>
                                <h3>Flight Details</h3>
                                <div class='detail-row'>
                                    <span class='detail-label'>Flight Number:</span>
                                    <span>{flightNumber}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>From:</span>
                                    <span>{from}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>To:</span>
                                    <span>{to}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>Date:</span>
                                    <span>{flightDate:MMMM dd, yyyy}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>Passenger:</span>
                                    <span>{passengerName}</span>
                                </div>
                            </div>

                            <p><strong>What's Next?</strong></p>
                            <ul>
                                <li>Check in online 24 hours before your flight</li>
                                <li>Arrive at the airport at least 2 hours before departure</li>
                                <li>Keep your booking reference handy</li>
                            </ul>

                            <p>Have a great flight! ✈️</p>
                        </div>
                        <div class='footer'>
                            <p>© 2025 Flight Booking System. All rights reserved.</p>
                            <p>For support, please contact us at support@flightbooking.com</p>
                        </div>
                    </div>
                </body>
                </html>
            ";

            await SendEmailAsync(toEmail, subject, htmlBody);
        }

        public async Task SendPasswordResetEmailAsync(string toEmail, string userName)
        {
            var subject = "Password Reset Instructions";
            var htmlBody = $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
                        .button {{ display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }}
                        .warning {{ background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; }}
                        .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 12px; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h1>Password Reset Request</h1>
                        </div>
                        <div class='content'>
                            <h2>Hello {userName}!</h2>
                            <p>We received a request to reset your password for your Flight Booking System account.</p>
                            
                            <p>Your password has been reset successfully. You can now log in with your new password.</p>

                            <div class='warning'>
                                <strong>Security Note:</strong> If you didn't request this password reset, please contact our support team immediately.
                            </div>

                            <a href='#' class='button'>Login to Your Account</a>
                        </div>
                        <div class='footer'>
                            <p>© 2025 Flight Booking System. All rights reserved.</p>
                            <p>This is an automated email, please do not reply.</p>
                        </div>
                    </div>
                </body>
                </html>
            ";

            await SendEmailAsync(toEmail, subject, htmlBody);
        }
    }
}

