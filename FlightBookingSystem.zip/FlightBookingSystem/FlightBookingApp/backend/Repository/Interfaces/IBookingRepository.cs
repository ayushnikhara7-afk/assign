using FlightBookingApp.Models.Domain;

namespace FlightBookingApp.Repository.Interfaces
{
    public interface IBookingRepository
    {
        Booking Add(Booking booking);
        Booking? GetByReferenceNumber(string referenceNumber);
        Booking? GetBookingWithFlight(string referenceNumber);
        List<Booking> GetUserBookings(int userId);
        Booking Update(Booking booking);
        bool CancelBooking(string referenceNumber);
    }
}

