using FlightBookingApp.Models.Domain;

namespace FlightBookingApp.Repository.Interfaces
{
    public interface IFlightRepository
    {
        List<Flight> SearchFlights(string from, string to, DateTime date);
        List<Flight> GetAll();
        Flight? GetById(int id);
        Flight Add(Flight flight);
        Flight Update(Flight flight);
        bool Delete(int id);
    }
}

