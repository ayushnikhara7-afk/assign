using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class UserController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly ILogger<UserController> _logger;

        public UserController(IAuthService authService, ILogger<UserController> logger)
        {
            _authService = authService;
            _logger = logger;
        }

        [HttpGet("profile")]
        public IActionResult GetProfile()
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim) || !int.TryParse(userIdClaim, out int userId))
            {
                return Unauthorized(new { message = "User not found" });
            }

            var user = _authService.GetUserById(userId);
            if (user == null)
            {
                return NotFound(new { message = "User not found" });
            }

            return Ok(new
            {
                id = user.Id,
                username = user.Username,
                email = user.Email,
                firstName = user.FirstName,
                lastName = user.LastName
            });
        }

        [HttpPut("profile")]
        public async Task<IActionResult> UpdateProfile([FromBody] UpdateUserRequest request)
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userIdClaim) || !int.TryParse(userIdClaim, out int userId))
            {
                return Unauthorized(new { message = "User not found" });
            }

            try
            {
                var updatedUser = await _authService.UpdateUserProfileAsync(
                    userId,
                    request.Email,
                    request.Username,
                    request.FirstName,
                    request.LastName
                );

                _logger.LogInformation($"User {userId} updated their profile successfully");

                return Ok(new
                {
                    message = "Profile updated successfully",
                    user = new
                    {
                        id = updatedUser.Id,
                        username = updatedUser.Username,
                        email = updatedUser.Email,
                        firstName = updatedUser.FirstName,
                        lastName = updatedUser.LastName
                    }
                });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}

