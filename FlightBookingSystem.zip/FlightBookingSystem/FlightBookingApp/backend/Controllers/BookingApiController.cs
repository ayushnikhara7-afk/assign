using Microsoft.AspNetCore.Mvc;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;

namespace FlightBookingApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookingApiController : ControllerBase
    {
        private readonly IFlightService _flightService;
        private readonly IBookingService _bookingService;
        private readonly ILogger<BookingApiController> _logger;

        public BookingApiController(IFlightService flightService, IBookingService bookingService, ILogger<BookingApiController> logger)
        {
            _flightService = flightService;
            _bookingService = bookingService;
            _logger = logger;
        }

        private int? GetUserIdFromClaims()
        {
            // Try to get user ID from NameIdentifier claim (standard claim type)
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim != null && int.TryParse(userIdClaim.Value, out int userId))
            {
                return userId;
            }
            
            // Try alternative claim type for NameIdentifier (in case of claim mapping issues)
            userIdClaim = User.FindFirst("http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier");
            if (userIdClaim != null && int.TryParse(userIdClaim.Value, out userId))
            {
                return userId;
            }
            
            return null;
        }


        [HttpGet("search")]
        public IActionResult SearchFlights([FromQuery] string from, [FromQuery] string to, [FromQuery] DateTime date)
        {
            var currentDate = DateTime.UtcNow.Date;
            if (date.Date < currentDate)
            {
                return BadRequest(new { error = $"Cannot search for flights on {date:yyyy-MM-dd} as this date has already passed. Please search for flights from today ({currentDate:yyyy-MM-dd}) onwards." });
            }

            var flights = _flightService.SearchFlights(from, to, date);
            return Ok(flights);
        }

        [Authorize(Roles = "User")]
        [HttpPost("create")]
        public IActionResult CreateBooking([FromBody] BookingRequest request)
        {
            var userId = GetUserIdFromClaims();
            _logger.LogInformation($"Creating booking for user ID: {userId}, Flight ID: {request.FlightId}");
            
            if (userId == null)
            {
                _logger.LogWarning("User ID could not be extracted from claims");
            }
            
            var booking = _bookingService.CreateBooking(request, userId);
            return Ok(new { booking, message = "Booking created successfully" });
        }

        [Authorize(Roles = "User")]
        [HttpGet("my-bookings")]
        public IActionResult GetMyBookings()
        {
            var userId = GetUserIdFromClaims();
            if (userId == null)
            {
                return Unauthorized(new { 
                    message = "User not authenticated. Please logout and login again to refresh your session." 
                });
            }

            var bookings = _bookingService.GetUserBookings(userId.Value);
            return Ok(bookings);
        }

        [Authorize(Roles = "User")]
        [HttpDelete("cancel/{referenceNumber}")]
        public IActionResult CancelBooking(string referenceNumber)
        {
            var result = _bookingService.CancelBooking(referenceNumber);
            if (!result)
                throw new ArgumentException("Booking not found");

            return Ok(new { message = "Booking cancelled successfully" });
        }

        [Authorize(Roles = "User")]
        [HttpPost("create-payment-intent/{referenceNumber}")]
        public async Task<IActionResult> CreatePaymentIntent(string referenceNumber)
        {
            try
            {
                var booking = _bookingService.GetBookingByReference(referenceNumber);
                if (booking == null)
                    return NotFound(new { message = "Booking not found" });

                var clientSecret = await _bookingService.CreatePaymentIntentAsync(referenceNumber);
                
                return Ok(new { 
                    clientSecret,
                    message = "Payment intent created successfully" 
                });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [Authorize(Roles = "User")]
        [HttpPost("confirm-payment/{referenceNumber}")]
        public async Task<IActionResult> ConfirmPayment(string referenceNumber, [FromBody] StripePaymentRequest request)
        {
            try
            {
                var result = await _bookingService.ConfirmPaymentAsync(referenceNumber, request.PaymentIntentId);
                
                if (!result)
                    return BadRequest(new { message = "Payment confirmation failed" });

                return Ok(new { message = "Payment confirmed successfully" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
