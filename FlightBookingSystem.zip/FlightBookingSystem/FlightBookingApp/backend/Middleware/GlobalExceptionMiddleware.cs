using Microsoft.AspNetCore.Http;
using System.Net;
using System.Text.Json;

namespace FlightBookingApp.Middleware
{
    public class GlobalExceptionMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<GlobalExceptionMiddleware> _logger;

        public GlobalExceptionMiddleware(RequestDelegate next, ILogger<GlobalExceptionMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"An error occurred: {ex.Message}");
                
                if (ex is ArgumentException)
                {
                    context.Response.StatusCode = (int)HttpStatusCode.BadRequest;  // 400
                }
                else if (ex is KeyNotFoundException)
                {
                    context.Response.StatusCode = (int)HttpStatusCode.NotFound;  // 404
                }
                else if (ex is UnauthorizedAccessException)
                {
                    context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;  // 401
                }
                else
                {
                    context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;  // 500
                }
                
                context.Response.ContentType = "application/json";
                
                var result = JsonSerializer.Serialize(new 
                { 
                    error = ex.Message,
                    statusCode = context.Response.StatusCode,
                    timestamp = DateTime.UtcNow
                });
                
                await context.Response.WriteAsync(result);
            }
        }
    }
}
