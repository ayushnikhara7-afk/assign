import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { BookingService } from '../../services/booking.service';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-checkin',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, NavbarComponent],
  templateUrl: './checkin.component.html',
  styleUrl: './checkin.component.scss'
})
export class CheckinComponent implements OnInit {
  private fb = inject(FormBuilder);
  private bookingService = inject(BookingService);
  private route = inject(ActivatedRoute);
  private toastService = inject(ToastService);

  searchForm = this.fb.nonNullable.group({
    bookingReference: ['', [Validators.required]]
  });

  booking: any = null;
  searching = false;
  searchError = '';
  
  checkingIn = false;
  checkinError = '';
  checkinSuccess = '';

  ngOnInit(): void {
    // Check if booking reference is provided in query params
    this.route.queryParams.subscribe(params => {
      if (params['ref']) {
        this.searchForm.patchValue({ bookingReference: params['ref'] });
        this.searchBooking();
      }
    });
  }

  searchBooking(): void {
    if (this.searchForm.invalid) {
      this.searchForm.markAllAsTouched();
      return;
    }

    this.searching = true;
    this.searchError = '';
    this.booking = null;

    const { bookingReference } = this.searchForm.getRawValue();

    this.bookingService.searchBooking({ bookingReference }).subscribe({
      next: (response: any) => {
        this.booking = response.booking;
        this.searching = false;
        this.toastService.success('Booking found!');
      },
      error: (err: any) => {
        this.searching = false;
        this.searchError = err?.error?.message || 'Booking not found. Please check your reference number.';
        this.toastService.error(this.searchError);
      }
    });
  }

  performCheckin(): void {
    if (!this.booking) return;

    this.checkingIn = true;
    this.checkinError = '';
    this.checkinSuccess = '';

    const bookingReference = this.searchForm.getRawValue().bookingReference;

    this.bookingService.performCheckin({ bookingReference }).subscribe({
      next: (response: any) => {
        this.checkingIn = false;
        this.checkinSuccess = response.message;
        this.toastService.success(`Check-in successful! Seat: ${response.checkin?.seatNumber}`);
        
        // Refresh the booking to show updated status
        setTimeout(() => {
          this.searchBooking();
        }, 2000);
      },
      error: (err: any) => {
        this.checkingIn = false;
        this.checkinError = err?.error?.message || 'Check-in failed. Please try again.';
        this.toastService.error(this.checkinError);
      }
    });
  }

  cancelBooking(): void {
    if (!this.booking || !confirm('Are you sure you want to cancel this booking?')) {
      return;
    }

    const bookingReference = this.searchForm.getRawValue().bookingReference;

    this.bookingService.cancelBooking(bookingReference).subscribe({
      next: () => {
        this.toastService.success('Booking cancelled successfully');
        this.booking = null;
        this.searchForm.reset();
      },
      error: (err: any) => {
        const errorMsg = err?.error?.message || 'Failed to cancel booking';
        this.toastService.error(errorMsg);
      }
    });
  }
}

