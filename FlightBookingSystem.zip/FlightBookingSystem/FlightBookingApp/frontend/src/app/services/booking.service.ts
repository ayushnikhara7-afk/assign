import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface BookingRequest {
  flightId: number;
  firstName: string;
  lastName: string;
  gender: string;
}

export interface Booking {
  id: number;
  referenceNumber: string;
  flightId: number;
  firstName: string;
  lastName: string;
  gender: string;
  bookingDate: string;
  isCheckedIn: boolean;
  seatNumber?: string;
  checkinDate?: string;
  isPaid: boolean;
  paymentDate?: string;
  paymentIntentId?: string;
  flight?: {
    id: number;
    flightNumber: string;
    from: string;
    to: string;
    date: string;
    fare: number;
  };
}

export interface BookingResponse {
  booking: Booking;
  message: string;
}

export interface MessageResponse {
  message: string;
}

export interface CheckinRequest {
  bookingReference: string;
}

export interface BookingSearchRequest {
  bookingReference: string;
}

export interface BookingSearchResponse {
  message: string;
  booking: Booking;
}

export interface CheckinResponse {
  message: string;
  checkin: {
    seatNumber: string;
    passengerName: string;
    flightNumber: string;
  };
}

export interface CheckinStatusResponse {
  message: string;
  isCheckedIn: boolean;
  seatNumber?: string;
  passengerName: string;
  flightNumber: string;
}

export interface PaymentRequest {
  cardNumber: string;
  cardHolderName: string;
  expiryDate: string;
  cvv: string;
}

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private http = inject(HttpClient);
  private readonly basePath = '/api/BookingApi';
  private readonly checkinPath = '/api/Checkin';

  createBooking(request: BookingRequest): Observable<BookingResponse> {
    return this.http.post<BookingResponse>(`${this.basePath}/create`, request);
  }

  searchBooking(request: BookingSearchRequest): Observable<BookingSearchResponse> {
    return this.http.post<BookingSearchResponse>(`${this.checkinPath}/search`, request);
  }

  performCheckin(request: CheckinRequest): Observable<CheckinResponse> {
    return this.http.post<CheckinResponse>(`${this.checkinPath}/perform`, request);
  }

  getCheckinStatus(bookingReference: string): Observable<CheckinStatusResponse> {
    return this.http.get<CheckinStatusResponse>(`${this.checkinPath}/status/${bookingReference}`);
  }

  cancelBooking(referenceNumber: string): Observable<MessageResponse> {
    return this.http.delete<MessageResponse>(`${this.basePath}/cancel/${referenceNumber}`);
  }

  processPayment(referenceNumber: string, paymentRequest: PaymentRequest): Observable<MessageResponse> {
    return this.http.post<MessageResponse>(`${this.basePath}/payment/${referenceNumber}`, paymentRequest);
  }

  getMyBookings(): Observable<Booking[]> {
    return this.http.get<Booking[]>(`${this.basePath}/my-bookings`);
  }

  createPaymentIntent(referenceNumber: string): Observable<{clientSecret: string, message: string}> {
    return this.http.post<{clientSecret: string, message: string}>(
      `${this.basePath}/create-payment-intent/${referenceNumber}`, 
      {}
    );
  }

  confirmPayment(referenceNumber: string, paymentIntentId: string): Observable<MessageResponse> {
    return this.http.post<MessageResponse>(
      `${this.basePath}/confirm-payment/${referenceNumber}`,
      { paymentIntentId }
    );
  }
}


