import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface BookingRequest {
  flightId: number;
  firstName: string;
  lastName: string;
  gender: string;
}

export interface Booking {
  id: number;
  referenceNumber: string;
  flightId: number;
  firstName: string;
  lastName: string;
  gender: string;
  bookingDate: string;
  isCheckedIn: boolean;
  seatNumber?: string;
  checkinDate?: string;
  flight?: {
    id: number;
    flightNumber: string;
    from: string;
    to: string;
    date: string;
    fare: number;
  };
}

export interface BookingResponse {
  booking: Booking;
  message: string;
}

export interface MessageResponse {
  message: string;
}

export interface CheckinRequest {
  bookingReference: string;
}

export interface BookingSearchRequest {
  bookingReference: string;
}

export interface BookingSearchResponse {
  message: string;
  booking: Booking;
}

export interface CheckinResponse {
  message: string;
  checkin: {
    seatNumber: string;
    passengerName: string;
    flightNumber: string;
  };
}

export interface CheckinStatusResponse {
  message: string;
  isCheckedIn: boolean;
  seatNumber?: string;
  passengerName: string;
  flightNumber: string;
}

export interface PaymentRequest {
  cardNumber: string;
  cardHolderName: string;
  expiryDate: string;
  cvv: string;
}

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private http = inject(HttpClient);
  private readonly basePath = '/api/BookingApi';
  private readonly checkinPath = '/api/Checkin';

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('auth_token');
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  createBooking(request: BookingRequest): Observable<BookingResponse> {
    return this.http.post<BookingResponse>(`${this.basePath}/create`, request, {
      headers: this.getAuthHeaders()
    });
  }

  searchBooking(request: BookingSearchRequest): Observable<BookingSearchResponse> {
    return this.http.post<BookingSearchResponse>(`${this.checkinPath}/search`, request);
  }

  performCheckin(request: CheckinRequest): Observable<CheckinResponse> {
    return this.http.post<CheckinResponse>(`${this.checkinPath}/perform`, request);
  }

  getCheckinStatus(bookingReference: string): Observable<CheckinStatusResponse> {
    return this.http.get<CheckinStatusResponse>(`${this.checkinPath}/status/${bookingReference}`);
  }

  cancelBooking(referenceNumber: string): Observable<MessageResponse> {
    return this.http.delete<MessageResponse>(`${this.basePath}/cancel/${referenceNumber}`, {
      headers: this.getAuthHeaders()
    });
  }

  processPayment(referenceNumber: string, paymentRequest: PaymentRequest): Observable<MessageResponse> {
    return this.http.post<MessageResponse>(`${this.basePath}/payment/${referenceNumber}`, paymentRequest, {
      headers: this.getAuthHeaders()
    });
  }
}


