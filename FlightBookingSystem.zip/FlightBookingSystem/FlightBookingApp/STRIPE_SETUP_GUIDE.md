# Stripe Payment Integration Guide

## 🎉 Stripe Payment System Successfully Integrated!

Your Flight Booking System now uses **Stripe** for secure payment processing. This guide will help you set up and test the payment functionality.

---

## 📋 Table of Contents
1. [Overview](#overview)
2. [Getting Your Stripe API Keys](#getting-your-stripe-api-keys)
3. [Backend Configuration](#backend-configuration)
4. [Frontend Configuration](#frontend-configuration)
5. [Testing Payments](#testing-payments)
6. [Production Setup](#production-setup)
7. [Troubleshooting](#troubleshooting)

---

## 🌟 Overview

### What's Integrated:
- ✅ **Stripe Payment Intents** - Secure payment processing
- ✅ **Stripe Elements** - Beautiful, customizable payment forms
- ✅ **PCI Compliance** - Card data never touches your servers
- ✅ **3D Secure (SCA)** - Automatic Strong Customer Authentication
- ✅ **Real-time validation** - Instant feedback on card details
- ✅ **Multiple payment methods** - Credit cards, debit cards, and more

### How It Works:
1. User books a flight → booking is created
2. User goes to "My Bookings" → clicks "Make Payment"
3. Backend creates a Stripe Payment Intent
4. Frontend displays Stripe's secure payment form
5. User enters card details → Stripe processes payment
6. Backend confirms payment → booking is updated

---

## 🔑 Getting Your Stripe API Keys

### Step 1: Create a Stripe Account
1. Go to [https://stripe.com](https://stripe.com)
2. Click "Sign Up" and create your account
3. Complete the registration process

### Step 2: Get Your API Keys
1. Log in to your [Stripe Dashboard](https://dashboard.stripe.com)
2. Click on **"Developers"** in the left sidebar
3. Click on **"API keys"**
4. You'll see two keys:
   - **Publishable key** (starts with `pk_test_...`) - Safe to use in frontend
   - **Secret key** (starts with `sk_test_...`) - **KEEP THIS SECURE!**

### Step 3: Note Your Keys
```
Publishable Key: pk_test_51xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
Secret Key: sk_test_51xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

---

## ⚙️ Backend Configuration

### 1. Update `appsettings.json`

Open `backend/appsettings.json` and update the Stripe section:

```json
{
  "Stripe": {
    "PublishableKey": "pk_test_YOUR_PUBLISHABLE_KEY_HERE",
    "SecretKey": "sk_test_YOUR_SECRET_KEY_HERE"
  }
}
```

**⚠️ Important Security Notes:**
- Never commit your real Secret Key to version control
- For production, use environment variables:
  ```bash
  export Stripe__SecretKey="sk_live_YOUR_PRODUCTION_KEY"
  ```

### 2. Restore NuGet Packages

The Stripe.net package has been added to your project. Restore it:

```powershell
cd backend
dotnet restore
```

### 3. Verify Service Registration

The Stripe service is already registered in `Program.cs`:
```csharp
builder.Services.AddScoped<IStripeService, StripeService>();
```

---

## 🎨 Frontend Configuration

### 1. Update Stripe Publishable Key

Open `frontend/src/app/pages/my-bookings/my-bookings.component.ts`

Find this line (around line 35):
```typescript
stripePublishableKey = 'pk_test_51QRl3TRtkbZDtcB8KKmDGSVOVzUBIdQsHoZNMdoW7rPjw5GlcOcJzx3bL9eM5hT3F2ug5Q3iaBVThiPLZGCCW3zW00tDbVvWsz';
```

Replace with your actual Publishable Key:
```typescript
stripePublishableKey = 'pk_test_YOUR_PUBLISHABLE_KEY_HERE';
```

### 2. Verify Stripe.js is Loaded

Check `frontend/src/index.html` - Stripe.js is already included:
```html
<script src="https://js.stripe.com/v3/"></script>
```

---

## 🧪 Testing Payments

### Test Mode vs Live Mode

Stripe has two modes:
- **Test Mode** (`pk_test_...` / `sk_test_...`) - For development, no real money
- **Live Mode** (`pk_live_...` / `sk_live_...`) - For production, real transactions

### Test Card Numbers

Use these cards in **Test Mode**:

| Card Number | Description | Expected Result |
|-------------|-------------|-----------------|
| `4242 4242 4242 4242` | Visa | ✅ Success |
| `5555 5555 5555 4444` | Mastercard | ✅ Success |
| `4000 0025 0000 3155` | Visa (3D Secure) | ✅ Success with 3D Secure prompt |
| `4000 0000 0000 9995` | Visa | ❌ Declined - Insufficient funds |
| `4000 0000 0000 0002` | Visa | ❌ Declined - Generic decline |
| `4000 0000 0000 9987` | Visa | ❌ Declined - Lost card |

### Additional Test Details:
- **Expiry Date**: Any future date (e.g., `12/25`)
- **CVC**: Any 3 digits (e.g., `123`)
- **ZIP Code**: Any ZIP code (e.g., `12345`)

### Testing Flow:

1. **Start the Application**
   ```powershell
   # Terminal 1 - Backend
   cd backend
   dotnet run
   
   # Terminal 2 - Frontend
   cd frontend
   npm start
   ```

2. **Test a Payment**
   - Sign up / Log in
   - Search for a flight
   - Book a flight
   - Go to "My Bookings"
   - Click "Make Payment" on a booking
   - Enter test card: `4242 4242 4242 4242`
   - Enter any future expiry: `12/25`
   - Enter any CVC: `123`
   - Click "Pay Now"
   - ✅ Payment should succeed!

3. **Verify in Stripe Dashboard**
   - Go to [Stripe Dashboard](https://dashboard.stripe.com/test/payments)
   - You'll see your test payment listed
   - Click on it to see full details

---

## 🚀 Production Setup

### Before Going Live:

#### 1. Get Live API Keys
1. Complete Stripe account verification
2. Activate your account in the [Stripe Dashboard](https://dashboard.stripe.com)
3. Get your **Live** API keys (starts with `pk_live_` and `sk_live_`)

#### 2. Update Backend Configuration

**Option A: Environment Variables (Recommended)**
```powershell
# Windows PowerShell
$env:Stripe__SecretKey="sk_live_YOUR_LIVE_SECRET_KEY"
$env:Stripe__PublishableKey="pk_live_YOUR_LIVE_PUBLISHABLE_KEY"

# Linux/Mac
export Stripe__SecretKey="sk_live_YOUR_LIVE_SECRET_KEY"
export Stripe__PublishableKey="pk_live_YOUR_LIVE_PUBLISHABLE_KEY"
```

**Option B: Azure App Service**
Add these to Application Settings:
```
Stripe__SecretKey: sk_live_YOUR_LIVE_SECRET_KEY
Stripe__PublishableKey: pk_live_YOUR_LIVE_PUBLISHABLE_KEY
```

#### 3. Update Frontend

Replace the test key with your live publishable key:
```typescript
stripePublishableKey = 'pk_live_YOUR_LIVE_PUBLISHABLE_KEY';
```

#### 4. Enable Webhooks (Optional but Recommended)

Webhooks allow Stripe to notify your application about payment events:

1. In [Stripe Dashboard](https://dashboard.stripe.com/webhooks), add webhook endpoint:
   ```
   https://yourdomain.com/api/stripe/webhook
   ```

2. Select events to listen for:
   - `payment_intent.succeeded`
   - `payment_intent.payment_failed`
   - `charge.refunded`

3. Get your webhook secret (starts with `whsec_...`)

4. Add to your backend webhook controller (create if needed)

---

## 🔒 Security Best Practices

### 1. Never Expose Secret Keys
- ❌ **Don't** commit secret keys to Git
- ❌ **Don't** hardcode them in your code
- ✅ **Do** use environment variables
- ✅ **Do** use secure vaults (Azure Key Vault, AWS Secrets Manager)

### 2. Use HTTPS in Production
Stripe requires HTTPS for live payments:
```csharp
// In Program.cs for production
if (!app.Environment.IsDevelopment())
{
    app.UseHttpsRedirection();
}
```

### 3. Validate on Backend
Never trust client-side payment confirmations:
- ✅ Always verify payment status on backend
- ✅ Use Stripe's confirmation endpoint
- ✅ Check payment intent status before fulfilling orders

### 4. Log Everything (Securely)
```csharp
// Log payment attempts (without sensitive data)
_logger.LogInformation($"Payment intent created for booking {bookingRef}");
_logger.LogInformation($"Payment succeeded: {paymentIntentId}");
```

---

## 🐛 Troubleshooting

### Issue: "Stripe is not defined" Error

**Solution:**
- Check that Stripe.js is loaded in `index.html`
- Wait for page to fully load before initializing Stripe
- Check browser console for script loading errors

### Issue: "Invalid API Key" Error

**Solution:**
- Verify you're using the correct key format:
  - Backend: `sk_test_...` or `sk_live_...`
  - Frontend: `pk_test_...` or `pk_live_...`
- Ensure no extra spaces or newlines in the key
- Check that the key matches your Stripe account

### Issue: "No such payment_intent" Error

**Solution:**
- Check backend logs for payment intent creation errors
- Verify the booking exists before creating payment intent
- Ensure proper authentication headers are being sent

### Issue: Card Declined in Test Mode

**Solution:**
- Use correct test card numbers (see table above)
- Ensure expiry date is in the future
- Check Stripe Dashboard → Logs for detailed error

### Issue: Payment Succeeds but Not Confirming in Backend

**Solution:**
- Check CORS settings in `Program.cs`
- Verify authentication token is valid
- Check network tab in browser DevTools
- Review backend logs for errors

### Issue: Elements Not Displaying

**Solution:**
```typescript
// Ensure modal is visible before mounting
setTimeout(() => this.mountStripeElements(), 100);
```

### Issue: 3D Secure Not Working

**Solution:**
- Use test card `4000 0025 0000 3155`
- Follow the authentication prompt
- In production, 3D Secure is automatic for eligible cards

---

## 📊 Monitoring & Analytics

### Stripe Dashboard

Monitor your payments in real-time:
- [Test Mode Dashboard](https://dashboard.stripe.com/test/payments)
- [Live Mode Dashboard](https://dashboard.stripe.com/payments)

### Key Metrics to Track:
- 💰 **Total Revenue** - Track successful payments
- ❌ **Declined Rate** - Monitor failed payments
- 🔄 **Refund Rate** - Track customer refunds
- 📈 **Conversion Rate** - Booking → Payment completion

### Stripe Radar (Fraud Prevention)

Stripe automatically includes fraud protection:
- Machine learning-based fraud detection
- 3D Secure for high-risk transactions
- CVC and ZIP code verification
- Address verification (AVS)

---

## 💡 Additional Features You Can Add

### 1. Save Payment Methods
Allow customers to save cards for future bookings:
```typescript
await stripe.confirmSetup({
  elements,
  confirmParams: { return_url: window.location.origin },
});
```

### 2. Subscription Payments
For membership or recurring bookings:
```csharp
var subscription = await subscriptionService.CreateAsync(options);
```

### 3. Multiple Currencies
Support international payments:
```csharp
var options = new PaymentIntentCreateOptions
{
    Amount = amount,
    Currency = "eur", // or "gbp", "jpy", etc.
};
```

### 4. Refunds
Process refunds directly through Stripe:
```csharp
var refundService = new RefundService();
await refundService.CreateAsync(new RefundCreateOptions
{
    PaymentIntent = paymentIntentId,
});
```

---

## 📚 Resources

- [Stripe Documentation](https://stripe.com/docs)
- [Stripe.net Library](https://github.com/stripe/stripe-dotnet)
- [Stripe.js Reference](https://stripe.com/docs/js)
- [Testing Guide](https://stripe.com/docs/testing)
- [API Reference](https://stripe.com/docs/api)
- [Stripe Support](https://support.stripe.com)

---

## ✅ Quick Checklist

Before launching to production:

- [ ] Stripe account fully verified
- [ ] Live API keys obtained
- [ ] Backend updated with live secret key (via env variables)
- [ ] Frontend updated with live publishable key
- [ ] HTTPS enabled for production
- [ ] Tested live payment flow
- [ ] Webhooks configured (optional)
- [ ] Error logging implemented
- [ ] Customer support process for payment issues
- [ ] Refund policy defined

---

## 🎉 Congratulations!

Your Flight Booking System now has enterprise-grade payment processing powered by Stripe! 

**Need Help?**
- Check Stripe Dashboard logs
- Review backend application logs
- Test in Test Mode first
- Contact Stripe Support for payment-specific issues

---

**Happy Selling! ✈️💳**

