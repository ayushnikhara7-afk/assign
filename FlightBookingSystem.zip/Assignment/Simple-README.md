# Simple Flight Booking System

A beginner-friendly flight booking application built with .NET 8, ASP.NET Core MVC, and SQL Server.

## What This Application Does

This application allows users to:
1. **Search for flights** by entering departure city, destination, and date
2. **View available flights** in a table format
3. **Book a flight** by entering passenger details
4. **Get booking confirmation** with a reference number

## Features

✅ **Flight Search Form** - Search flights with NYC/SFO defaults  
✅ **Available Flights Table** - Shows flight details with Book links  
✅ **Selected Flight Booking** - Passenger details form with Satyendra Singh defaults  
✅ **Booking Confirmation** - Success message with reference number  
✅ **SQL Server Database** - Stores flights and bookings  
✅ **Responsive Design** - Works on desktop and mobile  
✅ **Beginner-Friendly Code** - No async/await, no complex exception handling  

## Prerequisites

- **.NET 8 SDK** - Download from [Microsoft](https://dotnet.microsoft.com/download)
- **SQL Server** - LocalDB is included with Visual Studio
- **Visual Studio 2022** or **VS Code** (optional)

## Quick Start

1. **Open Command Prompt** in the project folder

2. **Run the application:**
   ```bash
   # Option 1: Use the batch file
   run-app.bat
   
   # Option 2: Manual commands
   cd FlightBookingApp
   dotnet run
   ```

3. **Open your browser** and go to:
   - `https://localhost:5001` (HTTPS)
   - `http://localhost:5000` (HTTP)

## How to Use

### Step 1: Search Flights
- Enter departure city: `NYC`
- Enter destination: `SFO`  
- Select date: `2016-01-22`
- Click **SUBMIT**

### Step 2: View Available Flights
- See the table with flights: BF101, BF105, BF106
- Click **Book** next to any flight

### Step 3: Book Flight
- Enter passenger details:
  - First Name: `Satyendra`
  - Last Name: `Singh`
  - Gender: `Male`
- Click **CONFIRM**

### Step 4: Get Confirmation
- View booking confirmation with reference number
- Note down the reference number for future use

## Sample Data

The application comes with pre-loaded flights:
- **BF101**: NYC → SFO, Jan 22, 2016, $101
- **BF105**: NYC → SFO, Jan 22, 2016, $105  
- **BF106**: NYC → SFO, Jan 22, 2016, $106

## Project Structure

```
SimpleFlightBooking/
├── FlightBookingApp/           # Main application
│   ├── Controllers/            # MVC Controllers (simple, no async)
│   ├── Models/                 # Data models
│   ├── Views/                  # HTML views
│   ├── Data/                   # Database context
│   └── wwwroot/                # CSS and JavaScript
└── SimpleFlightBooking.sln     # Solution file
```

## Technologies Used

- **.NET 8** - Modern web framework
- **ASP.NET Core MVC** - Web application framework
- **Entity Framework Core** - Database ORM
- **SQL Server LocalDB** - Local database
- **HTML/CSS** - Frontend styling
- **JavaScript** - Client-side functionality

## For Beginners

This project is designed to be beginner-friendly with:

- **Simple Structure** - Easy to understand folder organization
- **Clear Code** - Well-commented and straightforward logic
- **No Async/Await** - Simple synchronous code for easy understanding
- **No Exception Handling** - Clean, focused code without complexity
- **Step-by-Step Flow** - Each page leads to the next
- **No Complex Dependencies** - Just basic .NET packages
- **Local Database** - No external setup required

## Troubleshooting

**Database Issues:**
- Make sure SQL Server LocalDB is installed
- The database will be created automatically on first run

**Port Issues:**
- If port 5000/5001 is busy, .NET will use the next available port
- Check the console output for the actual URL

**Build Errors:**
- Make sure you have .NET 8 SDK installed
- Run `dotnet restore` to restore packages

## Next Steps

Once you're comfortable with this basic version, you can:
- Add more flight data
- Implement booking search functionality
- Add check-in features
- Create a more advanced UI
- Add user authentication

Happy coding! 🚀
