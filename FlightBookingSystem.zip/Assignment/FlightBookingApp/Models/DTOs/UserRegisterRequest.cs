using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models.DTOs
{
    public class UserRegisterRequest
    {
        [Required]
        public string Username { get; set; } = string.Empty;
        
        [Required]
        public string Password { get; set; } = string.Empty;
    }
}

