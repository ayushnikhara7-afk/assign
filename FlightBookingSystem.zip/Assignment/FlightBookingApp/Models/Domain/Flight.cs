using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models.Domain
{
    public class Flight
    {
        public int Id { get; set; }
        
        [Required]
        public string FlightNumber { get; set; } = string.Empty;
        
        [Required]
        public string From { get; set; } = string.Empty;
        
        [Required]
        public string To { get; set; } = string.Empty;
        
        [Required]
        public DateTime Date { get; set; }
        
        public decimal Fare { get; set; }
        
    }
}

