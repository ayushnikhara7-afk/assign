using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Repository.Interfaces;

namespace FlightBookingApp.Services.Implementations
{
    public class AdminService : IAdminService
    {
        private readonly IFlightRepository _flightRepo;
        
        public AdminService(IFlightRepository flightRepo)
        {
            _flightRepo = flightRepo;
        }

        public Flight CreateFlight(CreateFlightRequest request)
        {
            var flight = new Flight
            {
                FlightNumber = request.FlightNumber,
                From = request.From,
                To = request.To,
                Date = request.Date,
                Fare = request.Fare
            };

            return _flightRepo.Add(flight);
        }

        public bool DeleteFlight(int id)
        {
            return _flightRepo.Delete(id);
        }

        public bool ValidateAdmin(string username, string password)
        {
            return username == "admin" && password == "admin123";
        }
    }
}
