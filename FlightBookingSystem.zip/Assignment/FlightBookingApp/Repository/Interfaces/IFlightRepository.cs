using FlightBookingApp.Models.Domain;

namespace FlightBookingApp.Repository.Interfaces
{
    public interface IFlightRepository
    {
        List<Flight> SearchFlights(string from, string to, DateTime date);
        Flight? GetById(int id);
        Flight Add(Flight flight);
        bool Delete(int id);
    }
}

