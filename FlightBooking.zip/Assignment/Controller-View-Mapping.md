# Controller-View Mapping Guide

This document explains which controller functions are connected to which HTML views in the Flight Booking System.

## 📁 HomeController.cs

The `HomeController` class contains all the main functionality and connects to various views:

### 1. **Index()** → **Index.cshtml**
- **Purpose**: Displays the Flight Search form
- **HTTP Method**: GET
- **Route**: `/` or `/Home`
- **View**: `Views/Home/Index.cshtml`
- **Function**: Shows the main search page with form for searching flights

```csharp
public IActionResult Index()
{
    return View(); // Returns Index.cshtml
}
```

### 2. **SearchFlights(SearchRequest request)** → **SearchFlights.cshtml**
- **Purpose**: Handles flight search and displays results
- **HTTP Method**: POST
- **Route**: `/Home/SearchFlights`
- **View**: `Views/Home/SearchFlights.cshtml`
- **Function**: Searches database for flights matching criteria and shows results table

```csharp
[HttpPost]
public IActionResult SearchFlights(SearchRequest request)
{
    var flights = _context.Flights.Where(...).ToList();
    return View("SearchFlights", flights); // Returns SearchFlights.cshtml
}
```

### 3. **BookFlight(int flightId)** → **BookFlight.cshtml**
- **Purpose**: Displays booking form for selected flight
- **HTTP Method**: GET
- **Route**: `/Home/BookFlight/{flightId}`
- **View**: `Views/Home/BookFlight.cshtml`
- **Function**: Shows passenger details form for booking the selected flight

```csharp
public IActionResult BookFlight(int flightId)
{
    var flight = _context.Flights.Find(flightId);
    ViewBag.Flight = flight;
    return View(); // Returns BookFlight.cshtml
}
```

### 4. **CreateBooking(BookingRequest request)** → **CreateBooking.cshtml**
- **Purpose**: Creates booking and shows confirmation
- **HTTP Method**: POST
- **Route**: `/Home/CreateBooking`
- **View**: `Views/Home/CreateBooking.cshtml`
- **Function**: Processes booking form, saves to database, and shows confirmation

```csharp
[HttpPost]
public IActionResult CreateBooking(BookingRequest request)
{
    // Create booking logic...
    ViewBag.Booking = booking;
    ViewBag.Flight = flight;
    return View("CreateBooking"); // Returns CreateBooking.cshtml
}
```

## 📁 View Files Structure

```
Views/
├── _ViewStart.cshtml          # Sets default layout
├── _ViewImports.cshtml        # Imports namespaces
├── Shared/
│   └── _Layout.cshtml         # Main layout template
└── Home/
    ├── Index.cshtml           # Flight Search form
    ├── SearchFlights.cshtml   # Flight results table
    ├── BookFlight.cshtml      # Passenger booking form
    └── CreateBooking.cshtml   # Booking success page
```

## 🔄 Complete User Flow

1. **User visits homepage** → `Index()` → `Index.cshtml`
2. **User submits search** → `SearchFlights()` → `SearchFlights.cshtml`
3. **User clicks "Book"** → `BookFlight()` → `BookFlight.cshtml`
4. **User submits booking** → `CreateBooking()` → `CreateBooking.cshtml`

## 📊 Data Flow

| Controller Action | View | Data Passed |
|------------------|------|-------------|
| `Index()` | `Index.cshtml` | None (empty form) |
| `SearchFlights()` | `SearchFlights.cshtml` | `IEnumerable<Flight>` |
| `BookFlight()` | `BookFlight.cshtml` | Flight via ViewBag |
| `CreateBooking()` | `CreateBooking.cshtml` | Booking & Flight via ViewBag |

## 🎯 Key Features

- **Simple MVC Pattern**: Each controller action returns one specific view
- **Data Binding**: Views receive data through strongly-typed models or ViewBag
- **Form Handling**: POST actions process form submissions
- **Navigation**: GET actions display forms and pages
- **User Experience**: Clear flow from search → results → book → confirm

This architecture follows standard ASP.NET Core MVC patterns and is perfect for beginners to understand the relationship between controllers and views!
