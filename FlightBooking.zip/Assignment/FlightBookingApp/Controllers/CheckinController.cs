using Microsoft.AspNetCore.Mvc;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CheckinController : ControllerBase
    {
        private readonly ICheckinService _checkinService;

        public CheckinController(ICheckinService checkinService)
        {
            _checkinService = checkinService;
        }

        [HttpPost("search")]
        public IActionResult SearchBooking([FromBody] BookingSearchRequest request)
        {
            try
            {
                // Validate input
                if (request == null)
                {
                    return BadRequest(new { message = "Request body cannot be empty" });
                }

                if (string.IsNullOrWhiteSpace(request.BookingReference))
                {
                    return BadRequest(new { message = "Booking reference is required" });
                }

                // Search for booking
                var booking = _checkinService.SearchBooking(request.BookingReference.Trim());
                
                if (booking == null)
                {
                    return NotFound(new { message = "Booking not found. Please check your booking reference number." });
                }

                return Ok(new { 
                    message = "Booking found successfully",
                    booking = booking
                });
            }
            catch (ArgumentException ex)
            {
                // Handle specific business logic errors
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                // Log the error (in production, use proper logging)
                Console.WriteLine($"Error in SearchBooking: {ex.Message}");
                
                return StatusCode(500, new { 
                    message = "An error occurred while searching for the booking. Please try again later." 
                });
            }
        }

        [HttpPost("perform")]
        public IActionResult PerformCheckin([FromBody] CheckinRequest request)
        {
            try
            {
                // Validate input
                if (request == null)
                {
                    return BadRequest(new { message = "Request body cannot be empty" });
                }

                if (string.IsNullOrWhiteSpace(request.BookingReference))
                {
                    return BadRequest(new { message = "Booking reference is required" });
                }

                // Perform check-in
                var checkinResult = _checkinService.PerformCheckin(request.BookingReference.Trim());
                
                return Ok(new { 
                    message = "Check-in completed successfully!",
                    checkin = checkinResult
                });
            }
            catch (ArgumentException ex)
            {
                // Handle specific business logic errors
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                // Log the error (in production, use proper logging)
                Console.WriteLine($"Error in PerformCheckin: {ex.Message}");
                
                return StatusCode(500, new { 
                    message = "An error occurred while processing check-in. Please try again later." 
                });
            }
        }

        [HttpGet("status/{bookingReference}")]
        public IActionResult GetCheckinStatus(string bookingReference)
        {
            try
            {
                // Validate input
                if (string.IsNullOrWhiteSpace(bookingReference))
                {
                    return BadRequest(new { message = "Booking reference is required" });
                }

                // Search for booking
                var booking = _checkinService.SearchBooking(bookingReference.Trim());
                
                if (booking == null)
                {
                    return NotFound(new { message = "Booking not found. Please check your booking reference number." });
                }

                return Ok(new { 
                    message = "Check-in status retrieved successfully",
                    isCheckedIn = booking.IsCheckedIn,
                    seatNumber = booking.SeatNumber,
                    passengerName = booking.PassengerName,
                    flightNumber = booking.FlightNumber
                });
            }
            catch (ArgumentException ex)
            {
                // Handle specific business logic errors
                return BadRequest(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                // Log the error (in production, use proper logging)
                Console.WriteLine($"Error in GetCheckinStatus: {ex.Message}");
                
                return StatusCode(500, new { 
                    message = "An error occurred while retrieving check-in status. Please try again later." 
                });
            }
        }
    }
}
