using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models.DTOs
{
    public class SearchRequest
    {
        [Required]
        [MaxLength(20)]
        public string From { get; set; } = string.Empty;
        
        [Required]
        [MaxLength(20)]
        public string To { get; set; } = string.Empty;
        
        [Required]
        public DateTime Date { get; set; }
    }
}

