using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Repository.Interfaces;

namespace FlightBookingApp.Services.Implementations
{
    public class CheckinService : ICheckinService
    {
        private readonly IBookingRepository _bookingRepo;
        
        public CheckinService(IBookingRepository bookingRepo)
        {
            _bookingRepo = bookingRepo;
        }

        public BookingSearchResponse? SearchBooking(string bookingReference)
        {
            try
            {
                // Validate input
                if (string.IsNullOrWhiteSpace(bookingReference))
                {
                    throw new ArgumentException("Booking reference is required");
                }

                // Get booking with flight details
                var booking = _bookingRepo.GetBookingWithFlight(bookingReference.Trim());
                
                if (booking == null)
                {
                    return null; // Booking not found
                }

                // Map to response DTO
                var response = new BookingSearchResponse
                {
                    BookingId = booking.Id,
                    BookingReference = booking.ReferenceNumber,
                    FlightNumber = booking.Flight?.FlightNumber ?? "",
                    From = booking.Flight?.From ?? "",
                    To = booking.Flight?.To ?? "",
                    FlightDate = booking.Flight?.Date ?? DateTime.MinValue,
                    PassengerName = $"{booking.FirstName} {booking.LastName}",
                    Gender = booking.Gender,
                    IsCheckedIn = booking.IsCheckedIn,
                    SeatNumber = booking.SeatNumber,
                    CheckinId = booking.IsCheckedIn ? booking.Id : null
                };

                return response;
            }
            catch (ArgumentException)
            {
                // Re-throw business logic exceptions
                throw;
            }
            catch (Exception ex)
            {
                // Log the error (in production, use proper logging)
                Console.WriteLine($"Error in SearchBooking: {ex.Message}");
                throw new InvalidOperationException("An error occurred while searching for the booking. Please try again later.");
            }
        }

        public CheckinResponse PerformCheckin(string bookingReference)
        {
            try
            {
                // Validate input
                if (string.IsNullOrWhiteSpace(bookingReference))
                {
                    throw new ArgumentException("Booking reference is required");
                }

                // Get booking with flight details
                var booking = _bookingRepo.GetBookingWithFlight(bookingReference.Trim());
                
                if (booking == null)
                {
                    throw new ArgumentException("Booking not found. Please check your booking reference.");
                }

                // Check if already checked in
                if (booking.IsCheckedIn)
                {
                    throw new ArgumentException("This booking has already been checked in.");
                }

                // Check if flight date is valid for check-in
                if (booking.Flight?.Date.Date < DateTime.Today)
                {
                    throw new ArgumentException("Cannot check in for a flight that has already departed.");
                }

                // Generate seat number
                var seatNumber = GenerateSeatNumber();

                // Perform check-in
                booking.IsCheckedIn = true;
                booking.SeatNumber = seatNumber;
                booking.CheckinDate = DateTime.UtcNow;

                // Update booking in database
                var updatedBooking = _bookingRepo.Update(booking);

                // Create response
                var response = new CheckinResponse
                {
                    CheckinId = updatedBooking.Id,
                    BookingReference = updatedBooking.ReferenceNumber,
                    SeatNumber = updatedBooking.SeatNumber!,
                    PassengerName = $"{updatedBooking.FirstName} {updatedBooking.LastName}",
                    FlightNumber = booking.Flight?.FlightNumber ?? "",
                    CheckinDate = updatedBooking.CheckinDate!.Value,
                    Message = $"Checked In, Seat Number is {updatedBooking.SeatNumber}, checkin id is {updatedBooking.Id}"
                };

                return response;
            }
            catch (ArgumentException)
            {
                // Re-throw business logic exceptions
                throw;
            }
            catch (Exception ex)
            {
                // Log the error (in production, use proper logging)
                Console.WriteLine($"Error in PerformCheckin: {ex.Message}");
                throw new InvalidOperationException("An error occurred while processing check-in. Please try again later.");
            }
        }

        private string GenerateSeatNumber()
        {
            try
            {
                // Generate a random seat number
                var random = new Random();
                var rowNumber = random.Next(1, 40); // Rows 1-39
                var seatLetter = (char)('A' + random.Next(0, 6)); // Seats A-F
                
                return $"{rowNumber}{seatLetter}";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error generating seat number: {ex.Message}");
                // Fallback to simple format
                return "1A";
            }
        }
    }
}
