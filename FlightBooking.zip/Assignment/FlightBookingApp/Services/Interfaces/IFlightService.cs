using FlightBookingApp.Models.Domain;

namespace FlightBookingApp.Services.Interfaces
{
    public interface IFlightService
    {
        List<Flight> SearchFlights(string from, string to, DateTime date);
        Flight? GetFlightById(int id);
    }
}

