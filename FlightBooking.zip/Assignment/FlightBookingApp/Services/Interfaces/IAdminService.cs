using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;

namespace FlightBookingApp.Services.Interfaces
{
    public interface IAdminService
    {
        Flight CreateFlight(CreateFlightRequest request);
        bool DeleteFlight(int id);
        bool ValidateAdmin(string username, string password);
    }
}
