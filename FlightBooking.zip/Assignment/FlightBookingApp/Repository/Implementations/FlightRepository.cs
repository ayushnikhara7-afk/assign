using FlightBookingApp.Data;
using FlightBookingApp.Models.Domain;
using FlightBookingApp.Repository.Interfaces;

namespace FlightBookingApp.Repository.Implementations
{
    public class FlightRepository : IFlightRepository
    {
        private readonly FlightDbContext _context;
        
        public FlightRepository(FlightDbContext context)
        {
            _context = context;
        }

        public List<Flight> SearchFlights(string from, string to, DateTime date)
        {
            return _context.Flights
                .Where(f => f.From == from &&
                           f.To == to &&
                           f.Date.Date == date.Date)
                .OrderBy(f => f.Fare)
                .ToList();
        }

        public Flight? GetById(int id)
        {
            return _context.Flights.Find(id);
        }

        public Flight Add(Flight flight)
        {
            _context.Flights.Add(flight);
            _context.SaveChanges();
            return flight;
        }

        public bool Delete(int id)
        {
            var flight = _context.Flights.Find(id);
            if (flight == null)
                return false;

            _context.Flights.Remove(flight);
            _context.SaveChanges();
            return true;
        }
    }
}

