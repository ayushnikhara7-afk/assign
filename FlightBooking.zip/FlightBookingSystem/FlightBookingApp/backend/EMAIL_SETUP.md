# SMTP Email Configuration Guide

This application includes email functionality for sending notifications to users. Follow these steps to configure SMTP settings.

## Configuration

The email settings are configured in `appsettings.json`:

```json
"EmailSettings": {
  "SmtpServer": "smtp.gmail.com",
  "SmtpPort": 587,
  "SenderEmail": "your-email@gmail.com",
  "SenderName": "Flight Booking System",
  "Username": "your-email@gmail.com",
  "Password": "your-app-password",
  "EnableSsl": true
}
```

## Using Gmail SMTP

### Step 1: Enable 2-Factor Authentication
1. Go to your Google Account settings
2. Navigate to Security
3. Enable 2-Step Verification

### Step 2: Generate App Password
1. After enabling 2FA, go to https://myaccount.google.com/apppasswords
2. Select "Mail" as the app
3. Select your device
4. Click "Generate"
5. Copy the 16-character password (remove spaces)

### Step 3: Update Configuration
Update `appsettings.json` with your credentials:
```json
"EmailSettings": {
  "SmtpServer": "smtp.gmail.com",
  "SmtpPort": 587,
  "SenderEmail": "youremail@gmail.com",
  "SenderName": "Flight Booking System",
  "Username": "youremail@gmail.com",
  "Password": "xxxx xxxx xxxx xxxx",  // Your 16-char app password
  "EnableSsl": true
}
```

## Using Other Email Providers

### Microsoft Outlook/Office 365
```json
"EmailSettings": {
  "SmtpServer": "smtp-mail.outlook.com",
  "SmtpPort": 587,
  "SenderEmail": "youremail@outlook.com",
  "SenderName": "Flight Booking System",
  "Username": "youremail@outlook.com",
  "Password": "your-password",
  "EnableSsl": true
}
```

### Yahoo Mail
```json
"EmailSettings": {
  "SmtpServer": "smtp.mail.yahoo.com",
  "SmtpPort": 587,
  "SenderEmail": "youremail@yahoo.com",
  "SenderName": "Flight Booking System",
  "Username": "youremail@yahoo.com",
  "Password": "your-app-password",
  "EnableSsl": true
}
```

## Email Templates

The application sends three types of emails:

### 1. Welcome Email
Sent when a user registers:
- Subject: "Welcome to Flight Booking System!"
- Contains: Welcome message and account features

### 2. Booking Confirmation
Sent when a booking is created:
- Subject: "Booking Confirmation - {ReferenceNumber}"
- Contains: Flight details, booking reference, passenger information

### 3. Password Reset
Sent when a password is reset:
- Subject: "Password Reset Instructions"
- Contains: Confirmation of password reset with security notice

## Troubleshooting

### Emails Not Sending

1. **Check SMTP Settings**: Verify server, port, and credentials
2. **Firewall**: Ensure port 587 is not blocked
3. **App Password**: For Gmail, use app password, not regular password
4. **SSL/TLS**: Ensure EnableSsl is set to true
5. **Logs**: Check application logs for error messages

### Common Issues

**"Authentication failed"**
- Verify username and password are correct
- For Gmail, ensure you're using an App Password, not your regular password

**"Timeout"**
- Check if port 587 is accessible
- Try port 465 with EnableSsl=true
- Check firewall settings

**"Invalid sender address"**
- Ensure SenderEmail matches your authenticated email account

## Security Best Practices

1. **Never commit passwords** to source control
2. Use **Environment Variables** for sensitive data in production:
   ```csharp
   "Password": "${EMAIL_PASSWORD}"
   ```
3. Use **Azure Key Vault** or similar for production environments
4. Rotate passwords regularly
5. Monitor email sending logs for suspicious activity

## Testing

To test email functionality:

1. Register a new user → Check for welcome email
2. Create a booking → Check for confirmation email  
3. Reset password → Check for reset confirmation email

## Production Considerations

For production environments:
- Use a dedicated SMTP service (SendGrid, AWS SES, Mailgun)
- Implement email queuing for better performance
- Add email templates management
- Track email delivery status
- Implement bounce and complaint handling
- Set up SPF, DKIM, and DMARC records

## Support

If you continue to experience issues with email configuration, please:
1. Check the application logs
2. Verify your email provider's SMTP settings
3. Ensure your account has necessary permissions
4. Contact your email provider's support if needed

