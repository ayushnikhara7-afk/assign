using FlightBookingApp.Models.Domain;
using FlightBookingApp.Repository.Interfaces;
using FlightBookingApp.Services.Interfaces;
using FlightBookingApp.Utils;

namespace FlightBookingApp.Services.Implementations
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _userRepo;
        private readonly IEmailService _emailService;
        
        public AuthService(IUserRepository userRepo, IEmailService emailService) 
        {
            _userRepo = userRepo;
            _emailService = emailService;
        }

        public bool ValidateUser(string username, string password)
        {
            var user = _userRepo.GetByUsername(username);
            return user != null && PasswordHasher.VerifyPassword(password, user.Password);
        }

        public bool UserExists(string username)
        {
            return _userRepo.GetByUsername(username) != null;
        }

        public bool EmailExists(string email)
        {
            return _userRepo.GetByEmail(email) != null;
        }

        public void RegisterUser(User user)
        {
            _userRepo.Add(user);
            
            // Send welcome email asynchronously
            _ = _emailService.SendWelcomeEmailAsync(user.Email, user.FirstName + " " + user.LastName);
        }

        public bool ResetPassword(string email, string newPassword)
        {
            var user = _userRepo.GetByEmail(email);
            if (user == null)
                return false;

            user.Password = PasswordHasher.HashPassword(newPassword);
            _userRepo.Update(user);
            
            // Send password reset confirmation email asynchronously
            _ = _emailService.SendPasswordResetEmailAsync(user.Email, user.FirstName + " " + user.LastName);
            
            return true;
        }

        public User? GetUserByEmail(string email)
        {
            return _userRepo.GetByEmail(email);
        }

        public User? GetUserByUsername(string username)
        {
            return _userRepo.GetByUsername(username);
        }
    }
}

