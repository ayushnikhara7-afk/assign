using FlightBookingApp.Models.DTOs;

namespace FlightBookingApp.Services.Interfaces
{
    public interface ICheckinService
    {
        BookingSearchResponse? SearchBooking(string bookingReference);
        CheckinResponse PerformCheckin(string bookingReference);
    }
}
