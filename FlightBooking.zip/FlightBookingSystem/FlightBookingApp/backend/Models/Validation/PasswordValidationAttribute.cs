using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;

namespace FlightBookingApp.Models.Validation
{
    public class PasswordValidationAttribute : ValidationAttribute
    {
        public int MinLength { get; set; } = 8;
        public bool RequireUppercase { get; set; } = true;
        public bool RequireLowercase { get; set; } = true;
        public bool RequireDigit { get; set; } = true;
        public bool RequireSpecialCharacter { get; set; } = true;

        public override bool IsValid(object? value)
        {
            if (value == null || string.IsNullOrEmpty(value.ToString()))
                return false;

            string password = value.ToString()!;

            // Check minimum length
            if (password.Length < MinLength)
            {
                ErrorMessage = $"Password must be at least {MinLength} characters long.";
                return false;
            }

            // Check for uppercase letter
            if (RequireUppercase && !Regex.IsMatch(password, @"[A-Z]"))
            {
                ErrorMessage = "Password must contain at least one uppercase letter.";
                return false;
            }

            // Check for lowercase letter
            if (RequireLowercase && !Regex.IsMatch(password, @"[a-z]"))
            {
                ErrorMessage = "Password must contain at least one lowercase letter.";
                return false;
            }

            // Check for digit
            if (RequireDigit && !Regex.IsMatch(password, @"[0-9]"))
            {
                ErrorMessage = "Password must contain at least one digit.";
                return false;
            }

            // Check for special character
            if (RequireSpecialCharacter && !Regex.IsMatch(password, @"[!@#$%^&*()_+\-=\[\]{};':""\\|,.<>\/?]"))
            {
                ErrorMessage = "Password must contain at least one special character (!@#$%^&*()_+-=[]{}|;':\",./<>?).";
                return false;
            }

            return true;
        }
    }
}
