using System.ComponentModel.DataAnnotations;
using FlightBookingApp.Models.Validation;

namespace FlightBookingApp.Models.DTOs
{
    public class PasswordChangeRequest
    {
        [Required(ErrorMessage = "Current password is required")]
        public string CurrentPassword { get; set; } = string.Empty;
        
        [Required(ErrorMessage = "New password is required")]
        [PasswordValidation(MinLength = 8, ErrorMessage = "Password must be at least 8 characters long and contain uppercase, lowercase, digit, and special character")]
        public string NewPassword { get; set; } = string.Empty;
        
        [Required(ErrorMessage = "Confirm password is required")]
        [Compare("NewPassword", ErrorMessage = "New password and confirm password do not match")]
        public string ConfirmPassword { get; set; } = string.Empty;
    }
}
