using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models.DTOs
{
    public class PaymentRequest
    {
        [Required]
        public string CardNumber { get; set; } = string.Empty;
        
        [Required]
        public string CardHolderName { get; set; } = string.Empty;
        
        [Required]
        public string ExpiryDate { get; set; } = string.Empty;
        
        [Required]
        public string CVV { get; set; } = string.Empty;
        
        [Required]
        public decimal Amount { get; set; }
    }
}
