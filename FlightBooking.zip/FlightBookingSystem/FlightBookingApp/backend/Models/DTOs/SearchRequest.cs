using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models.DTOs
{
    public class SearchRequest
    {
        [Required]
        [MaxLength(20)]
        public string? From { get; set; }
        
        [Required]
        [MaxLength(20)]
        public string? To { get; set; }
        
        [Required]
        public DateTime Date { get; set; }
    }
}

