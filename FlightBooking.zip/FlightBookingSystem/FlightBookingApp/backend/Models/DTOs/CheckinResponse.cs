namespace FlightBookingApp.Models.DTOs
{
    public class CheckinResponse
    {
        public int CheckinId { get; set; }
        public string BookingReference { get; set; } = string.Empty;
        public string SeatNumber { get; set; } = string.Empty;
        public string PassengerName { get; set; } = string.Empty;
        public string FlightNumber { get; set; } = string.Empty;
        public DateTime CheckinDate { get; set; }
        public string Message { get; set; } = string.Empty;
    }
}
