import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { FlightService, Flight } from '../../services/flight.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, NavbarComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent implements OnInit {
  private fb = inject(FormBuilder);
  private flightService = inject(FlightService);

  searching = false;
  hasSearched = false;
  searchError = '';
  flights: Flight[] = [];
  minDate = '';

  searchForm = this.fb.nonNullable.group({
    from: ['', [Validators.required]],
    to: ['', [Validators.required]],
    date: ['', [Validators.required]]
  });

  ngOnInit(): void {
    // Set minimum date to today
    const today = new Date();
    this.minDate = today.toISOString().split('T')[0];
  }

  searchFlights(): void {
    if (this.searchForm.invalid) {
      this.searchForm.markAllAsTouched();
      return;
    }

    this.searching = true;
    this.searchError = '';
    this.flights = [];
    this.hasSearched = false;

    const { from, to, date } = this.searchForm.getRawValue();

    this.flightService.searchFlights(from, to, date).subscribe({
      next: (flights: Flight[]) => {
        this.flights = flights;
        this.hasSearched = true;
        this.searching = false;
      },
      error: (err: any) => {
        this.searching = false;
        this.hasSearched = true;
        this.searchError = err?.error?.error || 'Failed to search flights. Please try again.';
      }
    });
  }
}
