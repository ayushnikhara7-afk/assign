import { Component, inject } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div style="max-width:380px;margin:40px auto;padding:24px;border:1px solid #ddd;border-radius:8px;">
      <h2 style="margin:0 0 16px;">Login</h2>
      <form [formGroup]="form" (ngSubmit)="onSubmit()">
        <div style="display:flex;flex-direction:column;gap:12px;">
          <label>
            <div>Username</div>
            <input formControlName="username" placeholder="Enter username" />
          </label>
          <label>
            <div>Password</div>
            <input type="password" formControlName="password" placeholder="Enter password" />
          </label>
          <button type="submit" [disabled]="form.invalid || loading">{{ loading ? 'Signing in…' : 'Sign in' }}</button>
        </div>
      </form>
      <div style="margin-top:12px;font-size:14px;">
        Don’t have an account?
        <a routerLink="/signup">Create one</a>
      </div>
      <div *ngIf="error" style="color:#b00020;margin-top:12px;">{{ error }}</div>
    </div>
  `,
  styles: ``
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);

  loading = false;
  error = '';

  form = this.fb.nonNullable.group({
    username: ['', [Validators.required, Validators.minLength(3)]],
    password: ['', [Validators.required, Validators.minLength(6)]]
  });

  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.loading = true;
    this.error = '';
    this.auth.signin(this.form.getRawValue()).subscribe({
      next: res => {
        localStorage.setItem('auth_token', res.token);
        alert('Login successful');
        this.loading = false;
        // Navigate somewhere meaningful later; for now, stay on page
      },
      error: err => {
        this.loading = false;
        this.error = err?.error?.message || 'Login failed';
      }
    });
  }
}
