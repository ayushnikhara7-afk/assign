using NUnit.Framework;
using Moq;
using Microsoft.AspNetCore.Mvc;
using FlightBookingApp.Controllers;
using FlightBookingApp.Services.Interfaces;
using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;
using Microsoft.Extensions.Configuration;

namespace FlightBookingApp.Tests.Controllers
{
    /// <summary>
    /// Unit tests for AdminController - 3 Essential Tests
    /// </summary>
    [TestFixture]
    public class AdminControllerTests
    {
        private Mock<IAdminService> _mockAdminService;
        private Mock<IConfiguration> _mockConfig;
        private AdminController _controller;

        [SetUp]
        public void Setup()
        {
            _mockAdminService = new Mock<IAdminService>();
            _mockConfig = new Mock<IConfiguration>();
            
            _mockConfig.Setup(c => c["Jwt:Key"]).Returns("ThisIsASecretKeyForJwtTokenGeneration123456");
            _mockConfig.Setup(c => c["Jwt:Issuer"]).Returns("FlightBookingApp");
            
            _controller = new AdminController(_mockAdminService.Object, _mockConfig.Object);
        }

        [Test]
        public void AdminLogin_WithValidCredentials_ReturnsOkWithToken()
        {
            // Arrange
            var request = new AdminLoginRequest
            {
                Username = "admin",
                Password = "admin123"
            };

            _mockAdminService.Setup(s => s.ValidateAdmin(request.Username, request.Password)).Returns(true);

            // Act
            var result = _controller.AdminLogin(request);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            _mockAdminService.Verify(s => s.ValidateAdmin(request.Username, request.Password), Times.Once);
        }

        [Test]
        public void CreateFlight_WithValidRequest_ReturnsOkWithFlight()
        {
            // Arrange
            var request = new CreateFlightRequest
            {
                FlightNumber = "FL001",
                From = "NYC",
                To = "LAX",
                Date = DateTime.Now.AddDays(7),
                Fare = 299.99m
            };

            var expectedFlight = new Flight
            {
                Id = 1,
                FlightNumber = "FL001",
                From = "NYC",
                To = "LAX",
                Date = request.Date,
                Fare = 299.99m
            };

            _mockAdminService.Setup(s => s.CreateFlight(request)).Returns(expectedFlight);

            // Act
            var result = _controller.CreateFlight(request);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var okResult = result as OkObjectResult;
            var flight = okResult!.Value as Flight;
            Assert.That(flight, Is.Not.Null);
            Assert.That(flight!.FlightNumber, Is.EqualTo("FL001"));
        }

        [Test]
        public void DeleteFlight_WithExistingId_ReturnsOk()
        {
            // Arrange
            int flightId = 1;
            _mockAdminService.Setup(s => s.DeleteFlight(flightId)).Returns(true);

            // Act
            var result = _controller.DeleteFlight(flightId);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            _mockAdminService.Verify(s => s.DeleteFlight(flightId), Times.Once);
        }

        [TearDown]
        public void TearDown()
        {
            _controller = null!;
            _mockAdminService = null!;
            _mockConfig = null!;
        }
    }
}

