# SQL Server Connection Fix Guide

## ✅ Fixed: Connection String Updated

**Changed:** `Server=LIN-5CG11529M9` → `Server=(localdb)\\mssqllocaldb`

Your connection string now uses **SQL Server LocalDB**, which is included with Visual Studio and .NET SDK.

---

## 🚀 Quick Start (Try This First)

### Option 1: Run with LocalDB (Already Configured)
```bash
cd FlightBookingApp
dotnet run
```

If this works, you're all set! ✅

---

## 🔧 If LocalDB Doesn't Work

### Check if LocalDB is Installed
```bash
sqllocaldb info
```

**Expected output:**
```
MSSQLLocalDB
```

If you see this, LocalDB is installed. ✅

### Start LocalDB Instance
```bash
sqllocaldb start MSSQLLocalDB
```

### Check LocalDB Version
```bash
sqllocaldb info MSSQLLocalDB
```

---

## 📋 Alternative Connection Strings

### Option 2: SQL Server Express (Full Instance)
```json
"DefaultConnection": "Server=.\\SQLEXPRESS;Database=SimpleFlightBookingDb;Trusted_Connection=True;TrustServerCertificate=True"
```

### Option 3: SQL Server (Default Instance)
```json
"DefaultConnection": "Server=.;Database=SimpleFlightBookingDb;Trusted_Connection=True;TrustServerCertificate=True"
```

### Option 4: SQL Server with Username/Password
```json
"DefaultConnection": "Server=.;Database=SimpleFlightBookingDb;User Id=sa;Password=YourPassword;TrustServerCertificate=True"
```

### Option 5: Named SQL Server Instance
```json
"DefaultConnection": "Server=YOUR_COMPUTER_NAME\\SQLEXPRESS;Database=SimpleFlightBookingDb;Trusted_Connection=True;TrustServerCertificate=True"
```

---

## 🔍 Troubleshooting Steps

### Step 1: Check SQL Server Service Status

#### Windows:
1. Press `Win + R`
2. Type `services.msc` and press Enter
3. Look for:
   - **SQL Server (MSSQLSERVER)** or
   - **SQL Server (SQLEXPRESS)**
4. Make sure it's **Running**

#### PowerShell:
```powershell
Get-Service | Where-Object {$_.Name -like "*SQL*"}
```

### Step 2: Find Your SQL Server Instance Name

#### Using SQL Server Configuration Manager:
1. Open SQL Server Configuration Manager
2. Look at "SQL Server Services"
3. Note the instance name in parentheses

#### Using Command Line:
```bash
sqlcmd -L
```

This lists all SQL Server instances on your network.

### Step 3: Test Connection

#### Using sqlcmd:
```bash
sqlcmd -S (localdb)\mssqllocaldb -Q "SELECT @@VERSION"
```

**For SQL Express:**
```bash
sqlcmd -S .\SQLEXPRESS -Q "SELECT @@VERSION"
```

If this works, SQL Server is running! ✅

---

## 🆕 Install SQL Server LocalDB

### If LocalDB is Not Installed:

#### Option A: Install SQL Server Express (Includes LocalDB)
1. Download: https://www.microsoft.com/en-us/sql-server/sql-server-downloads
2. Choose **Express** edition (Free)
3. Select **Download Media** → **LocalDB**
4. Run installer

#### Option B: Install with Visual Studio
1. Open Visual Studio Installer
2. Modify your installation
3. Check "Data storage and processing"
4. Select "SQL Server Express 2019 LocalDB"

#### Option C: Standalone LocalDB Installer
Download from: https://aka.ms/downloadsqlserverlocaldb

---

## 🔥 Quick Fixes

### Fix 1: Create LocalDB Instance
```bash
sqllocaldb create MSSQLLocalDB
sqllocaldb start MSSQLLocalDB
```

### Fix 2: Delete and Recreate LocalDB
```bash
sqllocaldb stop MSSQLLocalDB
sqllocaldb delete MSSQLLocalDB
sqllocaldb create MSSQLLocalDB
sqllocaldb start MSSQLLocalDB
```

### Fix 3: Enable TCP/IP for SQL Server

1. Open **SQL Server Configuration Manager**
2. Expand **SQL Server Network Configuration**
3. Click **Protocols for SQLEXPRESS** (or your instance name)
4. Right-click **TCP/IP** → **Enable**
5. Restart SQL Server service

---

## 🎯 Testing Your Connection

After updating the connection string, test your application:

```bash
cd FlightBookingApp
dotnet run
```

**Expected output:**
```
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: https://localhost:7001
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: http://localhost:5001
info: Microsoft.Hosting.Lifetime[0]
      Application started. Press Ctrl+C to shut down.
```

If you see this, the database connection is working! ✅

---

## 📊 Verify Database Creation

### Using sqlcmd:
```bash
sqlcmd -S (localdb)\mssqllocaldb -Q "SELECT name FROM sys.databases"
```

You should see `SimpleFlightBookingDb` in the list.

### Using SQL Server Management Studio (SSMS):
1. Open SSMS
2. Connect to: `(localdb)\mssqllocaldb`
3. Expand **Databases**
4. You should see `SimpleFlightBookingDb`

---

## ⚠️ Common Errors & Solutions

### Error 53: SQL Server does not exist or access denied
**Solution:** SQL Server is not running or wrong server name
- Check if SQL Server service is running
- Verify server name in connection string
- Try using LocalDB: `(localdb)\mssqllocaldb`

### Error 26: Error Locating Server/Instance Specified
**Solution:** SQL Server Browser service not running or TCP/IP disabled
- Start SQL Server Browser service
- Enable TCP/IP in SQL Server Configuration Manager

### Error 18456: Login failed for user
**Solution:** Authentication issue
- Use `Trusted_Connection=True` for Windows Authentication
- Or provide correct username and password

### Error 2: The system cannot find the file specified
**Solution:** Named Pipes not enabled or wrong connection string
- Enable Named Pipes in SQL Server Configuration Manager
- Use correct connection string format

### Cannot open database
**Solution:** Database doesn't exist yet
- Run the application once (EnsureCreated will create it)
- Or manually create the database

---

## 🛠️ Manual Database Creation (If Needed)

### Using Entity Framework CLI:

#### Drop existing database (if any):
```bash
dotnet ef database drop --project FlightBookingApp
```

#### Create new database:
```bash
dotnet ef database update --project FlightBookingApp
```

---

## 📝 Current Configuration Summary

**Connection String:** `Server=(localdb)\\mssqllocaldb;Database=SimpleFlightBookingDb;Trusted_Connection=True;TrustServerCertificate=True`

**Database Name:** SimpleFlightBookingDb

**Authentication:** Windows Authentication (Trusted_Connection=True)

**SSL:** TrustServerCertificate=True (bypass certificate validation)

---

## 🎓 Understanding Connection String Parameters

| Parameter | Value | Purpose |
|-----------|-------|---------|
| Server | (localdb)\\mssqllocaldb | SQL Server instance address |
| Database | SimpleFlightBookingDb | Database name |
| Trusted_Connection | True | Use Windows Authentication |
| TrustServerCertificate | True | Skip SSL certificate validation |

---

## 🔄 Switching Between Development and Production

### Development (appsettings.Development.json):
```json
"ConnectionStrings": {
  "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=SimpleFlightBookingDb;Trusted_Connection=True;TrustServerCertificate=True"
}
```

### Production (appsettings.Production.json):
```json
"ConnectionStrings": {
  "DefaultConnection": "Server=YOUR_PROD_SERVER;Database=FlightBookingDb;User Id=produser;Password=STRONG_PASSWORD;TrustServerCertificate=False"
}
```

---

## ✅ Verification Checklist

After setup, verify:

- [ ] SQL Server LocalDB is installed
- [ ] LocalDB instance is running (`sqllocaldb info MSSQLLocalDB`)
- [ ] Connection string is correct in appsettings.json
- [ ] Application starts without errors (`dotnet run`)
- [ ] Database is created (check with sqlcmd or SSMS)
- [ ] Swagger UI loads (https://localhost:7001/swagger)
- [ ] Can register a user
- [ ] Can login and get JWT token

---

## 🆘 Still Having Issues?

### Get Your Computer Name:
```bash
hostname
```

### Check .NET Version:
```bash
dotnet --version
```

### Check EF Core Tools:
```bash
dotnet ef --version
```

If not installed:
```bash
dotnet tool install --global dotnet-ef
```

### View All SQL Server Instances:
```powershell
Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server' -Name InstalledInstances | Select-Object -ExpandProperty InstalledInstances
```

---

## 📞 Additional Resources

- [SQL Server LocalDB Documentation](https://learn.microsoft.com/sql/database-engine/configure-windows/sql-server-express-localdb)
- [Connection Strings Reference](https://www.connectionstrings.com/sql-server/)
- [Entity Framework Core with SQL Server](https://learn.microsoft.com/ef/core/providers/sql-server/)

---

**Fixed:** October 11, 2025  
**Connection:** SQL Server LocalDB  
**Status:** Ready to use ✅


