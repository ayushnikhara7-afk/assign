using FlightBookingApp.Models.Domain;

namespace FlightBookingApp.Repository.Interfaces
{
    public interface IUserRepository
    {
        User? GetByUsername(string username);
        User? GetByEmail(string email);
        User? GetById(int id);
        List<User> GetAll();
        void Add(User user);
        User Update(User user);
        bool Delete(int id);
    }
}

