using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Services.Interfaces;
using FlightBookingApp.Utils;

namespace FlightBookingApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthApiController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly IConfiguration _config;

        public AuthApiController(IAuthService authService, IConfiguration config)
        {
            _authService = authService;
            _config = config;
        }

        [HttpPost("signup")]
        public IActionResult SignUp([FromBody] UserRegisterRequest request)
        {
            if (_authService.UserExists(request.Username))
                throw new ArgumentException("Username already exists.");

            if (_authService.EmailExists(request.Email))
                throw new ArgumentException("Email already exists.");

            var user = new User
            {
                Username = request.Username,
                Password = PasswordHasher.HashPassword(request.Password),
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email
            };

            _authService.RegisterUser(user);
            return Ok(new { message = "User registered successfully." });
        }
 
        [HttpPost("signin")]
        public IActionResult SignIn([FromBody] UserLoginRequest request)
        {
            if (!_authService.ValidateUser(request.Username, request.Password))
                throw new UnauthorizedAccessException("Invalid credentials.");

            var token = GenerateJwtToken(request.Username);
            return Ok(new { token, message = "Login successful" });
        }

        [HttpPost("forgot-password")]
        public IActionResult ForgotPassword([FromBody] ForgotPasswordRequest request)
        {
            var user = _authService.GetUserByEmail(request.Email);
            if (user == null)
                throw new ArgumentException("Email not found.");

            // In a real application, you would send an email with a reset link
            // For now, we'll just return a success message
            return Ok(new { message = "Password reset instructions sent to your email." });
        }

        [HttpPost("reset-password")]
        public IActionResult ResetPassword([FromBody] ResetPasswordRequest request)
        {
            var success = _authService.ResetPassword(request.Email, request.NewPassword);
            if (!success)
                throw new ArgumentException("Email not found.");

            return Ok(new { message = "Password reset successfully." });
        }

        private string GenerateJwtToken(string username)
        {
            var jwtKey = _config["Jwt:Key"];
            var jwtIssuer = _config["Jwt:Issuer"];

            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, username),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.Role, "User")
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: jwtIssuer,
                audience: jwtIssuer, 
                claims: claims,
                expires: DateTime.Now.AddHours(1),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
