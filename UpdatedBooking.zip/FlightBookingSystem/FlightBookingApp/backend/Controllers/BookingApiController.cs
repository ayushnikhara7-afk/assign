using Microsoft.AspNetCore.Mvc;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;

namespace FlightBookingApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookingApiController : ControllerBase
    {
        private readonly IFlightService _flightService;
        private readonly IBookingService _bookingService;

        public BookingApiController(IFlightService flightService, IBookingService bookingService)
        {
            _flightService = flightService;
            _bookingService = bookingService;
        }


        [HttpGet("search")]
        public IActionResult SearchFlights([FromQuery] string from, [FromQuery] string to, [FromQuery] DateTime date)
        {
            var currentDate = DateTime.UtcNow.Date;
            if (date.Date < currentDate)
            {
                return BadRequest(new { error = $"Cannot search for flights on {date:yyyy-MM-dd} as this date has already passed. Please search for flights from today ({currentDate:yyyy-MM-dd}) onwards." });
            }

            var flights = _flightService.SearchFlights(from, to, date);
            return Ok(flights);
        }

        [Authorize(Roles = "User")]
        [HttpPost("create")]
        public IActionResult CreateBooking([FromBody] BookingRequest request)
        {
            var booking = _bookingService.CreateBooking(request);
            return Ok(new { booking, message = "Booking created successfully" });
        }

        [Authorize(Roles = "User")]
        [HttpDelete("cancel/{referenceNumber}")]
        public IActionResult CancelBooking(string referenceNumber)
        {
            var result = _bookingService.CancelBooking(referenceNumber);
            if (!result)
                throw new ArgumentException("Booking not found");

            return Ok(new { message = "Booking cancelled successfully" });
        }

        [Authorize(Roles = "User")]
        [HttpPost("payment/{referenceNumber}")]
        public IActionResult ProcessPayment(string referenceNumber, [FromBody] PaymentRequest paymentRequest)
        {
            var result = _bookingService.ProcessPayment(referenceNumber, paymentRequest);
            if (!result)
                throw new ArgumentException("Payment processing failed. Please check your payment details and try again.");

            return Ok(new { message = "Payment processed successfully" });
        }
    }
}
