using Microsoft.AspNetCore.Mvc;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CheckinController : ControllerBase
    {
        private readonly ICheckinService _checkinService;

        public CheckinController(ICheckinService checkinService)
        {
            _checkinService = checkinService;
        }

        [HttpPost("search")]
        public IActionResult SearchBooking([FromBody] BookingSearchRequest request)
        {
            if (request == null)
            {
                return BadRequest(new { message = "Request body cannot be empty" });
            }
            if (string.IsNullOrWhiteSpace(request.BookingReference))
            {
                return BadRequest(new { message = "Booking reference is required" });
            }
            var booking = _checkinService.SearchBooking(request.BookingReference.Trim());
            if (booking == null)
            {
                return NotFound(new { message = "Booking not found. Please check your booking reference number." });
            }
            return Ok(new { 
                message = "Booking found successfully",
                booking = booking
            });
        }

        [HttpPost("perform")]
        public IActionResult PerformCheckin([FromBody] CheckinRequest request)
        {
            if (request == null)
            {
                return BadRequest(new { message = "Request body cannot be empty" });
            }
            if (string.IsNullOrWhiteSpace(request.BookingReference))
            {
                return BadRequest(new { message = "Booking reference is required" });
            }
            var checkinResult = _checkinService.PerformCheckin(request.BookingReference.Trim());
            return Ok(new { 
                message = "Check-in completed successfully!",
                checkin = checkinResult
            });
        }

        [HttpGet("status/{bookingReference}")]
        public IActionResult GetCheckinStatus(string bookingReference)
        {
            if (string.IsNullOrWhiteSpace(bookingReference))
            {
                return BadRequest(new { message = "Booking reference is required" });
            }
            var booking = _checkinService.SearchBooking(bookingReference.Trim());
            if (booking == null)
            {
                return NotFound(new { message = "Booking not found. Please check your booking reference number." });
            }
            return Ok(new { 
                message = "Check-in status retrieved successfully",
                isCheckedIn = booking.IsCheckedIn,
                seatNumber = booking.SeatNumber,
                passengerName = booking.PassengerName,
                flightNumber = booking.FlightNumber
            });
        }
    }
}
