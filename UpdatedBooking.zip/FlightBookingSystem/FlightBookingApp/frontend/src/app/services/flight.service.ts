import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Flight {
  id: number;
  flightNumber: string;
  from: string;
  to: string;
  date: string;
  fare: number;
}

@Injectable({
  providedIn: 'root'
})
export class FlightService {
  private http = inject(HttpClient);
  private readonly basePath = '/api/BookingApi';

  searchFlights(from: string, to: string, date: string): Observable<Flight[]> {
    return this.http.get<Flight[]>(`${this.basePath}/search`, {
      params: { from, to, date }
    });
  }
}
