import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface BookingRequest {
  flightId: number;
  firstName: string;
  lastName: string;
  gender: string;
}

export interface Booking {
  id: number;
  referenceNumber: string;
  flightId: number;
  firstName: string;
  lastName: string;
  gender: string;
  bookingDate: string;
  isCheckedIn: boolean;
  seatNumber?: string;
  checkinDate?: string;
  flight?: {
    id: number;
    flightNumber: string;
    from: string;
    to: string;
    date: string;
    fare: number;
  };
}

export interface BookingResponse {
  booking: Booking;
  message: string;
}

export interface MessageResponse {
  message: string;
}

export interface CheckinRequest {
  referenceNumber: string;
}

export interface CheckinResponse {
  seatNumber: string;
  message: string;
}

@Injectable({
  providedIn: 'root'
})
export class BookingService {
  private http = inject(HttpClient);
  private readonly basePath = '/api/BookingApi';
  private readonly checkinPath = '/api/Checkin';

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('auth_token');
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  createBooking(request: BookingRequest): Observable<BookingResponse> {
    return this.http.post<BookingResponse>(`${this.basePath}/create`, request, {
      headers: this.getAuthHeaders()
    });
  }

  searchBookings(referenceNumber: string): Observable<Booking> {
    return this.http.get<Booking>(`${this.checkinPath}/search/${referenceNumber}`);
  }

  checkin(request: CheckinRequest): Observable<CheckinResponse> {
    return this.http.post<CheckinResponse>(`${this.checkinPath}/checkin`, request);
  }

  cancelBooking(referenceNumber: string): Observable<MessageResponse> {
    return this.http.delete<MessageResponse>(`${this.basePath}/cancel/${referenceNumber}`, {
      headers: this.getAuthHeaders()
    });
  }
}

