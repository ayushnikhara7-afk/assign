import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { BookingService, Booking } from '../../services/booking.service';

@Component({
  selector: 'app-my-bookings',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, NavbarComponent],
  templateUrl: './my-bookings.component.html',
  styleUrl: './my-bookings.component.scss'
})
export class MyBookingsComponent {
  private fb = inject(FormBuilder);
  private bookingService = inject(BookingService);

  searchForm = this.fb.nonNullable.group({
    referenceNumber: ['', [Validators.required]]
  });

  checkinForm = this.fb.nonNullable.group({
    referenceNumber: ['', [Validators.required]]
  });

  booking: Booking | null = null;
  searching = false;
  searchError = '';
  
  checkingIn = false;
  checkinError = '';
  checkinSuccess = '';
  showCheckinModal = false;

  searchBooking(): void {
    if (this.searchForm.invalid) {
      this.searchForm.markAllAsTouched();
      return;
    }

    this.searching = true;
    this.searchError = '';
    this.booking = null;

    const { referenceNumber } = this.searchForm.getRawValue();

    this.bookingService.searchBookings(referenceNumber).subscribe({
      next: (data: Booking) => {
        this.booking = data;
        this.searching = false;
      },
      error: (err: any) => {
        this.searching = false;
        this.searchError = err?.error?.error || 'Booking not found. Please check your reference number.';
      }
    });
  }

  openCheckinModal(): void {
    this.showCheckinModal = true;
    this.checkinForm.reset();
    this.checkinError = '';
    this.checkinSuccess = '';
  }

  closeCheckinModal(): void {
    this.showCheckinModal = false;
    this.checkinError = '';
    this.checkinSuccess = '';
  }

  performCheckin(): void {
    if (this.checkinForm.invalid) {
      this.checkinForm.markAllAsTouched();
      return;
    }

    this.checkingIn = true;
    this.checkinError = '';
    this.checkinSuccess = '';

    const { referenceNumber } = this.checkinForm.getRawValue();

    this.bookingService.checkin({ referenceNumber }).subscribe({
      next: (response: any) => {
        this.checkingIn = false;
        this.checkinSuccess = `Check-in successful! Your seat number is: ${response.seatNumber}`;
        
        // Refresh the booking to show updated status
        setTimeout(() => {
          this.closeCheckinModal();
          this.searchForm.patchValue({ referenceNumber });
          this.searchBooking();
        }, 2000);
      },
      error: (err: any) => {
        this.checkingIn = false;
        this.checkinError = err?.error?.error || 'Check-in failed. Please try again.';
      }
    });
  }
}
