import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { FlightService, Flight } from '../../services/flight.service';
import { BookingService } from '../../services/booking.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, NavbarComponent],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss'
})
export class HomeComponent implements OnInit {
  private fb = inject(FormBuilder);
  private flightService = inject(FlightService);
  private bookingService = inject(BookingService);

  searching = false;
  hasSearched = false;
  searchError = '';
  flights: Flight[] = [];
  minDate = '';

  showBookingModal = false;
  selectedFlight: Flight | null = null;
  booking = false;
  bookingError = '';
  bookingSuccess = '';

  searchForm = this.fb.nonNullable.group({
    from: ['', [Validators.required]],
    to: ['', [Validators.required]],
    date: ['', [Validators.required]]
  });

  bookingForm = this.fb.nonNullable.group({
    firstName: ['', [Validators.required]],
    lastName: ['', [Validators.required]],
    gender: ['', [Validators.required]]
  });

  ngOnInit(): void {
    // Set minimum date to today
    const today = new Date();
    this.minDate = today.toISOString().split('T')[0];
  }

  searchFlights(): void {
    if (this.searchForm.invalid) {
      this.searchForm.markAllAsTouched();
      return;
    }

    this.searching = true;
    this.searchError = '';
    this.flights = [];
    this.hasSearched = false;

    const { from, to, date } = this.searchForm.getRawValue();

    this.flightService.searchFlights(from, to, date).subscribe({
      next: (flights: Flight[]) => {
        this.flights = flights;
        this.hasSearched = true;
        this.searching = false;
      },
      error: (err: any) => {
        this.searching = false;
        this.hasSearched = true;
        this.searchError = err?.error?.error || 'Failed to search flights. Please try again.';
      }
    });
  }

  openBookingModal(flight: Flight): void {
    this.selectedFlight = flight;
    this.showBookingModal = true;
    this.bookingForm.reset();
    this.bookingError = '';
    this.bookingSuccess = '';
  }

  closeBookingModal(): void {
    this.showBookingModal = false;
    this.selectedFlight = null;
    this.bookingError = '';
    this.bookingSuccess = '';
  }

  submitBooking(): void {
    if (this.bookingForm.invalid || !this.selectedFlight) {
      this.bookingForm.markAllAsTouched();
      return;
    }

    this.booking = true;
    this.bookingError = '';
    this.bookingSuccess = '';

    const bookingData = {
      flightId: this.selectedFlight.id,
      ...this.bookingForm.getRawValue()
    };

    this.bookingService.createBooking(bookingData).subscribe({
      next: (response: any) => {
        this.booking = false;
        this.bookingSuccess = `Booking successful! Reference Number: ${response.booking.referenceNumber}`;
        
        setTimeout(() => {
          this.closeBookingModal();
        }, 3000);
      },
      error: (err: any) => {
        this.booking = false;
        this.bookingError = err?.error?.message || 'Booking failed. Please try again.';
      }
    });
  }
}
