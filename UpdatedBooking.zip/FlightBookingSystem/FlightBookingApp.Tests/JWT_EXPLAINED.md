# JWT Token in .NET - Explained with Your Code

## 1️⃣ What is JWT?

**JWT** = **J**SON **W**eb **T**oken

### Simple Explanation
JWT is like a **digital ID card** that proves who you are without asking for username/password every time.

```
Traditional Way (Bad):
User → Every Request → Send Username + Password → Server checks

JWT Way (Good):
User → Login Once → Get Token → Every Request → Send Token → Server trusts it
```

---

## 2️⃣ JWT Structure

### A JWT Token Looks Like This:
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJqb2huIiwianRpIjoiMTIzIiwiZXhwIjoxNjk5OTk5fQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c
```

### It Has 3 Parts (Separated by dots):
```
HEADER.PAYLOAD.SIGNATURE

Part 1: Header      → Metadata (algorithm, type)
Part 2: Payload     → User data (username, role, etc.)
Part 3: Signature   → Proof it's valid (can't be faked)
```

---

## 3️⃣ How It Works in Your Project

### Step 1: User Logs In (Get Token)

```csharp
[HttpPost("signin")]
public IActionResult SignIn([FromBody] UserLoginRequest request)
{
    // 1. Check username and password
    if (!_authService.ValidateUser(request.Username, request.Password))
        return Unauthorized("Invalid credentials.");

    // 2. Generate JWT token
    var token = GenerateJwtToken(request.Username);
    
    // 3. Return token to user
    return Ok(new { token });
}
```

**What happens:**
```
User sends: { username: "john", password: "pass123" }
     ↓
Server checks: Is password correct? YES ✅
     ↓
Server creates JWT token with username "john"
     ↓
Returns: { token: "eyJhbGci..." }
```

### Step 2: Generate JWT Token (Your Code)

```csharp
private string GenerateJwtToken(string username)
{
    // 1. Get secret key from appsettings.json
    var jwtKey = _config["Jwt:Key"];  // "ayushthegreat-secret-key..."
    var jwtIssuer = _config["Jwt:Issuer"];  // "FlightBookingApp"

    // 2. Create claims (data to store in token)
    var claims = new[]
    {
        new Claim(JwtRegisteredClaimNames.Sub, username),  // Username
        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())  // Unique ID
    };

    // 3. Create security key from secret
    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
    
    // 4. Create signing credentials (how to sign token)
    var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

    // 5. Create the token
    var token = new JwtSecurityToken(
        issuer: jwtIssuer,              // Who created token
        audience: jwtIssuer,            // Who can use token
        claims: claims,                  // Data in token
        expires: DateTime.Now.AddHours(1),  // Token expires in 1 hour
        signingCredentials: creds       // How to verify token
    );

    // 6. Convert token to string
    return new JwtSecurityTokenHandler().WriteToken(token);
}
```

**Breaking It Down:**

```csharp
// 1. Claims = Data stored in token
var claims = new[]
{
    new Claim(JwtRegisteredClaimNames.Sub, "john"),  // Username: john
    new Claim(JwtRegisteredClaimNames.Jti, "abc123") // Token ID: abc123
};

// Result: Token contains { "sub": "john", "jti": "abc123" }
```

```csharp
// 2. Signing = Making token tamper-proof
var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

// Token is signed with secret key
// Anyone can READ token, but only server can VERIFY it's real
```

```csharp
// 3. Expiration = Token has deadline
expires: DateTime.Now.AddHours(1)

// After 1 hour, token becomes invalid
// User must login again to get new token
```

### Step 3: User Uses Token

```csharp
[Authorize]  // ← Requires valid JWT token!
[HttpPost("flights")]
public IActionResult CreateFlight([FromBody] CreateFlightRequest request)
{
    var flight = _adminService.CreateFlight(request);
    return Ok(flight);
}
```

**How user sends token:**
```http
POST /api/admin/flights
Headers:
  Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
  Content-Type: application/json

Body:
{
  "flightNumber": "FL001",
  "from": "NYC",
  "to": "LAX"
}
```

### Step 4: Server Validates Token (Automatic)

Your `Program.cs` configures this:

```csharp
// JWT Configuration in Program.cs
builder.Services.AddAuthentication(options =>
{
    // Use JWT Bearer tokens for authentication
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,         // Check who created token
        ValidateAudience = true,       // Check who can use token
        ValidateLifetime = true,       // Check if token expired
        ValidateIssuerSigningKey = true,  // Check signature is valid
        
        ValidIssuer = jwtIssuer,       // Expected issuer
        ValidAudience = jwtIssuer,     // Expected audience
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey))  // Secret key
    };
});
```

**What happens when request comes in:**

```
1. User sends request with token
        ↓
2. [Authorize] attribute checks token
        ↓
3. JWT middleware validates:
   ✅ Is signature valid? (using secret key)
   ✅ Is issuer correct? ("FlightBookingApp")
   ✅ Is token expired? (check expiration)
        ↓
4. If ALL checks pass → Allow request ✅
   If ANY check fails → Return 401 Unauthorized ❌
```

---

## 4️⃣ Complete Flow Example

### Login and Use API

```csharp
// STEP 1: User logs in
POST /api/auth/signin
Body: { "username": "john", "password": "pass123" }

Response: { "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." }

// STEP 2: User creates booking (with token)
POST /api/booking/create
Headers: 
  Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
Body: { "flightId": 1, "firstName": "John" }

Response: { "referenceNumber": "ABC123", ... }

// STEP 3: 1 hour later, token expires
POST /api/booking/create
Headers: 
  Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...  (expired!)

Response: 401 Unauthorized ❌

// STEP 4: User must login again
POST /api/auth/signin
Body: { "username": "john", "password": "pass123" }

Response: { "token": "NEW_TOKEN_HERE..." } ✅
```

---

## 5️⃣ Your Configuration Files

### appsettings.json
```json
{
  "Jwt": {
    "Key": "ayushthegreat-secret-key-for-jwt-token",  // Secret key
    "Issuer": "FlightBookingApp"  // Your app name
  }
}
```

**Key** = Secret password only your server knows  
**Issuer** = Name of your application

---

## 6️⃣ [Authorize] Attribute

### Without [Authorize]
```csharp
[HttpGet("flights")]
public IActionResult GetFlights()
{
    return Ok(flights);  // Anyone can access! No login needed
}
```

### With [Authorize]
```csharp
[Authorize]  // ← Must have valid JWT token!
[HttpPost("flights")]
public IActionResult CreateFlight()
{
    return Ok(flight);  // Only users with token can access
}
```

**Result:**
```
Without token:
  Request → 401 Unauthorized ❌

With valid token:
  Request → 200 OK ✅

With expired token:
  Request → 401 Unauthorized ❌
```

---

## 7️⃣ Admin vs Regular User Tokens

### Regular User Token
```csharp
var claims = new[]
{
    new Claim(JwtRegisteredClaimNames.Sub, "john"),
    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
};
// Token contains: username only
```

### Admin Token
```csharp
var claims = new[]
{
    new Claim(JwtRegisteredClaimNames.Sub, "admin"),
    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
    new Claim(ClaimTypes.Role, "Admin")  // ← Extra: Admin role!
};
// Token contains: username + role
```

**Difference:** Admin token has `Role: "Admin"` claim

---

## 8️⃣ Security Features

### 1. Tamper-Proof
```
User receives token: eyJhbGci...xyz

User tries to change username in token
  ↓
Token signature becomes invalid
  ↓
Server rejects it ❌
```

### 2. Expiration
```csharp
expires: DateTime.Now.AddHours(1)

After 1 hour → Token is useless
Must login again to get new token
```

### 3. Server-Side Validation
```
Every request:
  ✅ Check signature
  ✅ Check expiration
  ✅ Check issuer
  ✅ Check audience
```

---

## 9️⃣ Common JWT Scenarios

### Scenario 1: First Login
```
1. POST /api/auth/signin { username, password }
2. Server: Check password ✅
3. Server: Generate token
4. Return: { token: "..." }
5. User saves token (localStorage/cookie)
```

### Scenario 2: Making API Calls
```
1. User has token stored
2. Add to request header: Authorization: Bearer {token}
3. Server validates token automatically
4. If valid → Process request ✅
```

### Scenario 3: Token Expired
```
1. User sends request with old token
2. Server checks expiration → Expired! ❌
3. Return: 401 Unauthorized
4. Frontend: Show "Session expired, please login"
5. User logs in again → Gets new token
```

### Scenario 4: Invalid Token
```
1. User sends fake/modified token
2. Server checks signature → Invalid! ❌
3. Return: 401 Unauthorized
4. User must login again
```

---

## 🔟 Testing JWT in Your Project

### Test 1: Login and Get Token
```http
POST https://localhost:7xxx/api/auth/signin
Content-Type: application/json

{
  "username": "john",
  "password": "pass123"
}

Response:
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

### Test 2: Use Token (Without [Authorize])
```http
POST https://localhost:7xxx/api/booking/search
Content-Type: application/json

{
  "from": "NYC",
  "to": "LAX"
}

Response: 200 OK ✅ (No token needed!)
```

### Test 3: Use Token (With [Authorize])
```http
POST https://localhost:7xxx/api/booking/create
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json

{
  "flightId": 1,
  "firstName": "John"
}

Response: 200 OK ✅ (Token valid!)
```

### Test 4: No Token (With [Authorize])
```http
POST https://localhost:7xxx/api/booking/create
Content-Type: application/json

{
  "flightId": 1
}

Response: 401 Unauthorized ❌ (No token!)
```

---

## 1️⃣1️⃣ Visualizing JWT Flow

```
┌──────────┐                  ┌──────────┐
│  User    │                  │  Server  │
└────┬─────┘                  └────┬─────┘
     │                              │
     │  1. Login (user/pass)        │
     ├─────────────────────────────>│
     │                              │ Check password ✅
     │                              │ Create JWT token
     │                              │
     │  2. Return token             │
     │<─────────────────────────────┤
     │                              │
     │  Store token                 │
     │                              │
     │  3. API Call + Token         │
     ├─────────────────────────────>│
     │                              │ Validate token ✅
     │                              │ Process request
     │                              │
     │  4. Response                 │
     │<─────────────────────────────┤
     │                              │
```

---

## 1️⃣2️⃣ Key Takeaways

### What is JWT?
✅ Digital ID card that proves who you are  
✅ Contains user information (username, role, etc.)  
✅ Signed by server (tamper-proof)  
✅ Has expiration time  

### How it works?
1. User logs in → Gets token
2. User sends token with every request
3. Server validates token automatically
4. If valid → Allow access ✅
5. If invalid/expired → Reject ❌

### Benefits?
✅ **Stateless** - Server doesn't store sessions  
✅ **Scalable** - No session storage needed  
✅ **Secure** - Tamper-proof signature  
✅ **Fast** - No database lookup for every request  

### Your JWT Settings:
- **Secret Key**: `ayushthegreat-secret-key-for-jwt-token`
- **Issuer**: `FlightBookingApp`
- **Expiration**: 1 hour (users), 2 hours (admin)
- **Algorithm**: HMACSHA256

---

## Quick Reference

| Task | Code |
|------|------|
| Generate token | `GenerateJwtToken(username)` |
| Protect endpoint | `[Authorize]` |
| Get token | Login endpoint returns `{ token: "..." }` |
| Use token | Header: `Authorization: Bearer {token}` |
| Token expires | After 1 hour (user) or 2 hours (admin) |

---

**Now you understand JWT in .NET!** 🎉