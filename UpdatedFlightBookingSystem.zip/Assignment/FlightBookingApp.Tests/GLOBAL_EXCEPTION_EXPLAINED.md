# Global Exception Handling - Explained with Code

## 1️⃣ Basic Exception Handling (What You Know)

### Without Exception Handling ❌
```csharp
public IActionResult GetFlight(int id)
{
    var flight = _flightService.GetById(id);  // If id=999, throws exception!
    return Ok(flight);  // App crashes! 💥
}
```

**Result**: App crashes, user sees error page

### With Try-Catch (Basic) ✅
```csharp
public IActionResult GetFlight(int id)
{
    try
    {
        var flight = _flightService.GetById(id);
        return Ok(flight);
    }
    catch (Exception ex)
    {
        return BadRequest(new { error = ex.Message });  // Handle error
    }
}
```

**Result**: Error handled, returns nice error message

---

## 2️⃣ Problem with Basic Try-Catch

### You Have Many Controllers 😫

```csharp
// AdminController.cs
public IActionResult CreateFlight(CreateFlightRequest request)
{
    try { /* code */ } 
    catch (Exception ex) { return BadRequest(ex.Message); }  // ← Repeat
}

public IActionResult DeleteFlight(int id)
{
    try { /* code */ }
    catch (Exception ex) { return BadRequest(ex.Message); }  // ← Repeat
}

// BookingController.cs
public IActionResult CreateBooking(BookingRequest request)
{
    try { /* code */ }
    catch (Exception ex) { return BadRequest(ex.Message); }  // ← Repeat
}

// AuthController.cs
public IActionResult SignUp(UserRegisterRequest request)
{
    try { /* code */ }
    catch (Exception ex) { return BadRequest(ex.Message); }  // ← Repeat
}
```

**Problems:**
- ❌ Repeating try-catch in EVERY method
- ❌ Hard to maintain
- ❌ Easy to forget
- ❌ Code duplication

---

## 3️⃣ Solution: Global Exception Middleware

### What is Middleware? 🤔

**Middleware** = Code that runs BEFORE and AFTER your controller methods

```
Request comes in
       ↓
[Middleware 1] ← Runs first
       ↓
[Middleware 2] ← Runs second
       ↓
[Middleware 3] ← Runs third
       ↓
[Your Controller] ← Finally runs
       ↓
Response goes back
```

**Global Exception Middleware** = Middleware that catches ALL exceptions

---

## 4️⃣ How It Works (Visual)

### WITHOUT Global Exception Middleware

```
User Request → Controller throws error → 💥 CRASH!
```

### WITH Global Exception Middleware

```
User Request 
    → [Global Exception Middleware wraps everything in try-catch]
    → Controller throws error
    → [Middleware catches it!]
    → Returns nice error message ✅
```

---

## 5️⃣ Your Actual Global Exception Middleware

```csharp
public class GlobalExceptionMiddleware
{
    private readonly RequestDelegate _next;  // ← Next middleware in pipeline

    public GlobalExceptionMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);  // ← Call next middleware (eventually your controller)
        }
        catch (Exception ex)  // ← Catches ANY exception from ANY controller!
        {
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;  // 500
            var result = JsonSerializer.Serialize(new { error = ex.Message });
            await context.Response.WriteAsync(result);
        }
    }
}
```

### Breaking It Down

```csharp
// 1. Store reference to next middleware
private readonly RequestDelegate _next;

// 2. Constructor receives next middleware
public GlobalExceptionMiddleware(RequestDelegate next)
{
    _next = next;
}

// 3. This method is called for EVERY request
public async Task InvokeAsync(HttpContext context)
{
    try
    {
        // 4. Call the next middleware (and eventually your controller)
        await _next(context);
        
        // If no exception, request completes normally ✅
    }
    catch (Exception ex)  // 5. Catches ANY exception from anywhere!
    {
        // 6. Set response type to JSON
        context.Response.ContentType = "application/json";
        
        // 7. Set status code to 500 (Internal Server Error)
        context.Response.StatusCode = 500;
        
        // 8. Create error response
        var result = JsonSerializer.Serialize(new { error = ex.Message });
        
        // 9. Send error response
        await context.Response.WriteAsync(result);
    }
}
```

---

## 6️⃣ Registering Middleware in Program.cs

```csharp
var app = builder.Build();

// ✅ Register Global Exception Middleware FIRST!
app.UseMiddleware<GlobalExceptionMiddleware>();  // ← Wraps everything below

app.UseAuthentication();  // ← Protected by middleware
app.UseAuthorization();   // ← Protected by middleware
app.MapControllers();     // ← Protected by middleware

app.Run();
```

**Order Matters!** Middleware runs in order:
```
Request
  ↓
[GlobalExceptionMiddleware] ← Catches everything below
  ↓
[Authentication]
  ↓
[Authorization]
  ↓
[Your Controllers]
```

---

## 7️⃣ Real Example: Before vs After

### BEFORE (Without Global Exception Middleware)

```csharp
// Every controller method needs try-catch
public IActionResult CreateFlight(CreateFlightRequest request)
{
    try
    {
        var flight = _adminService.CreateFlight(request);
        return Ok(flight);
    }
    catch (Exception ex)
    {
        return BadRequest(new { error = ex.Message });
    }
}

public IActionResult DeleteFlight(int id)
{
    try
    {
        var result = _adminService.DeleteFlight(id);
        return Ok("Deleted");
    }
    catch (Exception ex)
    {
        return BadRequest(new { error = ex.Message });
    }
}
```

### AFTER (With Global Exception Middleware)

```csharp
// No try-catch needed! Middleware handles it!
public IActionResult CreateFlight(CreateFlightRequest request)
{
    var flight = _adminService.CreateFlight(request);
    return Ok(flight);
}

public IActionResult DeleteFlight(int id)
{
    var result = _adminService.DeleteFlight(id);
    return Ok("Deleted");
}
```

**Middleware automatically catches any exception!** ✅

---

## 8️⃣ What Happens When Exception Occurs?

### Example Scenario

```csharp
// User calls: DELETE /api/admin/flights/999

public IActionResult DeleteFlight(int id)
{
    var result = _adminService.DeleteFlight(999);  // ← Throws exception!
    return Ok("Deleted");
}
```

### Flow

```
1. Request comes in: DELETE /api/admin/flights/999

2. Middleware receives request
   ↓
   try {
       await _next(context);  // ← Calls DeleteFlight
   }

3. DeleteFlight executes
   ↓
   _adminService.DeleteFlight(999);  // ← Throws exception!

4. Exception travels back to middleware
   ↓
   catch (Exception ex) {
       // Middleware catches it!
       return { error: "Flight not found" }
   }

5. User receives: 
   Status: 500
   Body: { "error": "Flight not found" }
```

---

## 9️⃣ Improving Global Exception Middleware

### Current Version (Basic)
```csharp
catch (Exception ex)
{
    context.Response.StatusCode = 500;  // Always 500
    var result = JsonSerializer.Serialize(new { error = ex.Message });
    await context.Response.WriteAsync(result);
}
```
 
### Improved Version (Different Status Codes)
```csharp
catch (Exception ex)
{
    // Choose status code based on exception type
    context.Response.StatusCode = ex switch
    {
        ArgumentException => 400,        // Bad Request
        KeyNotFoundException => 404,     // Not Found
        UnauthorizedAccessException => 401,  // Unauthorized
        _ => 500                        // Internal Server Error
    };
    
    context.Response.ContentType = "application/json";
    
    var result = JsonSerializer.Serialize(new 
    { 
        error = ex.Message,
        statusCode = context.Response.StatusCode,
        timestamp = DateTime.UtcNow
    });
    
    await context.Response.WriteAsync(result);
}
```

### Even Better (Logging)
```csharp
catch (Exception ex)
{
    // Log the error
    Console.WriteLine($"ERROR: {ex.Message}");
    Console.WriteLine($"Stack Trace: {ex.StackTrace}");
    
    context.Response.ContentType = "application/json";
    context.Response.StatusCode = 500;
    
    var result = JsonSerializer.Serialize(new { error = ex.Message });
    await context.Response.WriteAsync(result);
}
```

---

## 🔟 Benefits of Global Exception Middleware

### ✅ Benefits
1. **DRY (Don't Repeat Yourself)** - Write try-catch once, works everywhere
2. **Consistent** - All errors handled the same way
3. **Clean Code** - Controllers are cleaner (no try-catch clutter)
4. **Centralized** - One place to change error handling
5. **Automatic** - Catches exceptions you forgot to handle

### Before vs After

**Before**: 100 methods = 100 try-catch blocks  
**After**: 100 methods = 1 global middleware ✅

---

## 1️⃣1️⃣ Testing Exception Handling

### Without Global Middleware (Manual Testing)
```csharp
[Test]
public void DeleteFlight_WithInvalidId_ReturnsBadRequest()
{
    _mockService.Setup(s => s.DeleteFlight(999))
        .Throws(new Exception("Not found"));

    var result = _controller.DeleteFlight(999);

    Assert.That(result, Is.InstanceOf<BadRequestObjectResult>());
}
```

### With Global Middleware (Exception Propagates)
```csharp
[Test]
public void DeleteFlight_WithInvalidId_ThrowsException()
{
    _mockService.Setup(s => s.DeleteFlight(999))
        .Throws(new Exception("Not found"));

    // Exception is thrown, middleware will catch it in real app
    Assert.Throws<Exception>(() => _controller.DeleteFlight(999));
}
```

---

## 1️⃣2️⃣ Common Mistakes

### ❌ Mistake 1: Not Registering Middleware
```csharp
var app = builder.Build();
// Forgot to add middleware!
app.MapControllers();
app.Run();
```

### ✅ Fix
```csharp
var app = builder.Build();
app.UseMiddleware<GlobalExceptionMiddleware>();  // ← Add this!
app.MapControllers();
app.Run();
```

### ❌ Mistake 2: Wrong Order
```csharp
app.MapControllers();
app.UseMiddleware<GlobalExceptionMiddleware>();  // ← Too late!
```

### ✅ Fix
```csharp
app.UseMiddleware<GlobalExceptionMiddleware>();  // ← First!
app.MapControllers();
```

### ❌ Mistake 3: Catching in Controller AND Middleware
```csharp
public IActionResult Delete(int id)
{
    try
    {
        _service.Delete(id);
        return Ok();
    }
    catch (Exception ex)
    {
        return BadRequest(ex.Message);  // ← Unnecessary!
    }
}
```

### ✅ Fix
```csharp
public IActionResult Delete(int id)
{
    _service.Delete(id);  // Let middleware handle exceptions
    return Ok();
}
```

---

## Key Takeaways

```
Basic Exception Handling:
  try-catch in every method ❌

Global Exception Middleware:
  One middleware catches ALL exceptions ✅
```

### Remember
1. Middleware = Code that runs before/after controllers
2. Global = Catches exceptions from ALL controllers
3. Register it FIRST in Program.cs
4. No need for try-catch in controllers anymore
5. All errors handled consistently

---

## Quick Comparison

| Feature | Basic Try-Catch | Global Middleware |
|---------|----------------|-------------------|
| Code Duplication | ❌ High | ✅ None |
| Easy to Forget | ❌ Yes | ✅ No |
| Consistent Errors | ❌ No | ✅ Yes |
| Clean Controllers | ❌ No | ✅ Yes |
| Centralized | ❌ No | ✅ Yes |

**Conclusion**: Global Exception Middleware = Better way to handle errors! 🎯

