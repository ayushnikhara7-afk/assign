using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Repository.Interfaces;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Services.Implementations
{
    public class BookingService : IBookingService
    {
        private readonly IBookingRepository _bookingRepo;
        private readonly IFlightRepository _flightRepo;
        
        public BookingService(IBookingRepository bookingRepo, IFlightRepository flightRepo)
        {
            _bookingRepo = bookingRepo;
            _flightRepo = flightRepo;
        }

        public Booking CreateBooking(BookingRequest request)
        {
            var flight = _flightRepo.GetById(request.FlightId);
            if (flight == null)
            {
                throw new ArgumentException("Flight not found");
            }

            var referenceNumber = Guid.NewGuid().ToString();

            var booking = new Booking
            {
                ReferenceNumber = referenceNumber,
                FlightId = request.FlightId,
                FirstName = request.FirstName,
                LastName = request.LastName,
                Gender = request.Gender,
                BookingDate = DateTime.UtcNow
            };

            return _bookingRepo.Add(booking);
        }

        public Booking? GetBookingByReference(string referenceNumber)
        {
            return _bookingRepo.GetByReferenceNumber(referenceNumber);
        }

        public bool CancelBooking(string referenceNumber)
        {
            return _bookingRepo.CancelBooking(referenceNumber);
        }

        public bool ProcessPayment(string referenceNumber, PaymentRequest paymentRequest)
        {
            var booking = _bookingRepo.GetBookingWithFlight(referenceNumber);
            if (booking == null)
                return false;

            // Simulate payment processing
            // In a real application, you would integrate with a payment gateway
            // For now, we'll just validate the payment details and return success
            
            if (string.IsNullOrEmpty(paymentRequest.CardNumber) || 
                string.IsNullOrEmpty(paymentRequest.CardHolderName) ||
                string.IsNullOrEmpty(paymentRequest.ExpiryDate) ||
                string.IsNullOrEmpty(paymentRequest.CVV))
            {
                return false;
            }

            // Simulate payment success
            return true;
        }
    }
}

