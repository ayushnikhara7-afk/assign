using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Repository.Interfaces;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Services.Implementations
{
    public class CheckinService : ICheckinService
    {
        private readonly IBookingRepository _bookingRepo;
        
        public CheckinService(IBookingRepository bookingRepo)
        {
            _bookingRepo = bookingRepo;
        }

        public BookingSearchResponse? SearchBooking(string bookingReference)
        {
            if (string.IsNullOrWhiteSpace(bookingReference))
            {
                throw new ArgumentException("Booking reference is required");
            }

            var booking = _bookingRepo.GetBookingWithFlight(bookingReference.Trim());
            
            if (booking == null)
            {
                return null;
            }

            var response = new BookingSearchResponse
            {
                BookingId = booking.Id,
                BookingReference = booking.ReferenceNumber,
                FlightNumber = booking.Flight?.FlightNumber ?? "",
                From = booking.Flight?.From ?? "",
                To = booking.Flight?.To ?? "",
                FlightDate = booking.Flight?.Date ?? DateTime.MinValue,
                PassengerName = $"{booking.FirstName} {booking.LastName}",
                Gender = booking.Gender,
                IsCheckedIn = booking.IsCheckedIn,
                SeatNumber = booking.SeatNumber,
                CheckinId = booking.IsCheckedIn ? booking.Id : null
            };

            return response;
        }

        public CheckinResponse PerformCheckin(string bookingReference)
        {
            if (string.IsNullOrWhiteSpace(bookingReference))
            {
                throw new ArgumentException("Booking reference is required");
            }

            var booking = _bookingRepo.GetBookingWithFlight(bookingReference.Trim());
            
            if (booking == null)
            {
                throw new ArgumentException("Booking not found. Please check your booking reference.");
            }

            if (booking.IsCheckedIn)
            {
                throw new ArgumentException("This booking has already been checked in.");
            }

            if (booking.Flight?.Date.Date < DateTime.Today)
            {
                throw new ArgumentException("Cannot check in for a flight that has already departed.");
            }

            var seatNumber = GenerateSeatNumber();

            booking.IsCheckedIn = true;
            booking.SeatNumber = seatNumber;
            booking.CheckinDate = DateTime.UtcNow;

            var updatedBooking = _bookingRepo.Update(booking);

            var response = new CheckinResponse
            {
                CheckinId = updatedBooking.Id,
                BookingReference = updatedBooking.ReferenceNumber,
                SeatNumber = updatedBooking.SeatNumber!,
                PassengerName = $"{updatedBooking.FirstName} {updatedBooking.LastName}",
                FlightNumber = booking.Flight?.FlightNumber ?? "",
                CheckinDate = updatedBooking.CheckinDate!.Value,
                Message = $"Checked In, Seat Number is {updatedBooking.SeatNumber}, checkin id is {updatedBooking.Id}"
            };

            return response;
        }

        private string GenerateSeatNumber()
        {
            var random = new Random();
            var rowNumber = random.Next(1, 40); 
            var seatLetter = (char)('A' + random.Next(0, 6)); 
            
            return $"{rowNumber}{seatLetter}";
        }
    }
}