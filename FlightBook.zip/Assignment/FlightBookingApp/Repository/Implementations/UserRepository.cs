using FlightBookingApp.Data;
using FlightBookingApp.Models.Domain;
using FlightBookingApp.Repository.Interfaces;

namespace FlightBookingApp.Repository.Implementations
{
    public class UserRepository : IUserRepository
    {
        private readonly FlightDbContext _context;
        
        public UserRepository(FlightDbContext context) 
        {
            _context = context;
        }

        public User? GetByUsername(string username)
        {
            return _context.Users.FirstOrDefault(u => u.Username == username);
        }

        public User? GetById(int id)
        {
            return _context.Users.FirstOrDefault(u => u.Id == id);
        }

        public void Add(User user)
        {
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public User Update(User user)
        {
            _context.Users.Update(user);
            _context.SaveChanges();
            return user;
        }
    }
}

