using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models.DTOs
{
    public class BookingSearchRequest
    {
        [Required]
        public string BookingReference { get; set; } = string.Empty;
    }
}
