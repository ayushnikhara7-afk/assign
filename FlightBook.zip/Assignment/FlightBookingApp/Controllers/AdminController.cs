using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;

namespace FlightBookingApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : ControllerBase
    {
        private readonly IAdminService _adminService;
        private readonly IConfiguration _config;

        public AdminController(IAdminService adminService, IConfiguration config)
        {
            _adminService = adminService;
            _config = config;
        }

        [HttpPost("login")]
        public IActionResult AdminLogin([FromBody] AdminLoginRequest request)
        {
            if (!_adminService.ValidateAdmin(request.Username, request.Password))
                return Unauthorized("Invalid admin credentials.");

            var token = GenerateAdminJwtToken(request.Username);
            return Ok(new { token, message = "Admin login successful" });
        }

        [Authorize]
        [HttpPost("flights")]
        public IActionResult CreateFlight([FromBody] CreateFlightRequest request)
        {
            var flight = _adminService.CreateFlight(request);
            return Ok(flight);
        }

        [Authorize]
        [HttpDelete("flights/{id}")]
        public IActionResult DeleteFlight(int id)
        {
            var result = _adminService.DeleteFlight(id);
            if (!result)
                return NotFound("Flight not found");

            return Ok(new { message = "Flight deleted successfully" });
        }

        [Authorize]
        [HttpPut("flights")]
        public IActionResult UpdateFlight([FromBody] UpdateFlightRequest request)
        {
            var flight = _adminService.UpdateFlight(request);
            return Ok(flight);
        }

        [Authorize]
        [HttpPut("users")]
        public IActionResult UpdateUser([FromBody] UpdateUserRequest request)
        {
            var user = _adminService.UpdateUser(request);
            return Ok(user);
        }

        private string GenerateAdminJwtToken(string username)
        {
            var jwtKey = _config["Jwt:Key"];
            var jwtIssuer = _config["Jwt:Issuer"];

            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, username),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(ClaimTypes.Role, "Admin")
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                issuer: jwtIssuer,
                audience: jwtIssuer,
                claims: claims,
                expires: DateTime.Now.AddHours(2),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
