using Microsoft.AspNetCore.Mvc;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;

namespace FlightBookingApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BookingApiController : ControllerBase
    {
        private readonly IFlightService _flightService;
        private readonly IBookingService _bookingService;

        public BookingApiController(IFlightService flightService, IBookingService bookingService)
        {
            _flightService = flightService;
            _bookingService = bookingService;
        }


        [HttpPost("search")]
        public IActionResult SearchFlights([FromBody] SearchRequest request)
        {
            var flights = _flightService.SearchFlights(request.From, request.To, request.Date);
            return Ok(flights);
        }

        [Authorize]
        [HttpPost("create")]
        public IActionResult CreateBooking([FromBody] BookingRequest request)
        {
            var booking = _bookingService.CreateBooking(request);
            return Ok(booking);
        }
    }
}
