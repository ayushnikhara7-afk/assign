using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;

namespace FlightBookingApp.Services.Interfaces
{
    public interface IAdminService
    {
        Flight CreateFlight(CreateFlightRequest request);
        Flight UpdateFlight(UpdateFlightRequest request);
        User UpdateUser(UpdateUserRequest request);
        bool DeleteFlight(int id);
        bool ValidateAdmin(string username, string password);
    }
}
