using FlightBookingApp.Models.Domain;

namespace FlightBookingApp.Services.Interfaces
{
    public interface IAuthService
    {
        bool ValidateUser(string username, string password);
        bool UserExists(string username);
        void RegisterUser(User user);
    }
}

