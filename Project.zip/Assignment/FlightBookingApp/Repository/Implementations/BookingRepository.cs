using FlightBookingApp.Data;
using FlightBookingApp.Models.Domain;
using FlightBookingApp.Repository.Interfaces;

namespace FlightBookingApp.Repository.Implementations
{
    public class BookingRepository : IBookingRepository
    {
        private readonly FlightDbContext _context;
        
        public BookingRepository(FlightDbContext context)
        {
            _context = context;
        }

        public Booking Add(Booking booking)
        {
            _context.Bookings.Add(booking);
            _context.SaveChanges();
            return booking;
        }

        public Booking? GetByReferenceNumber(string referenceNumber)
        {
            return _context.Bookings.FirstOrDefault(b => b.ReferenceNumber == referenceNumber);
        }
    }
}

