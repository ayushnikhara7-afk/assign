using FlightBookingApp.Models.Domain;

namespace FlightBookingApp.Repository.Interfaces
{
    public interface IFlightRepository
    {
        List<Flight> SearchFlights(string from, string to, DateTime date);
        Flight? GetById(int id);
        List<Flight> GetAllFlights();
        Flight Add(Flight flight);
        Flight Update(Flight flight);
        bool Delete(int id);
    }
}

