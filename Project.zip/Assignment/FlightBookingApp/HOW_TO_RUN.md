# Flight Booking App - How to Run

## Prerequisites
- ✅ .NET 8.0 SDK installed
- ✅ SQL Server running (or SQL Server Express)
- ✅ Visual Studio or VS Code (optional)

## Step-by-Step Instructions

### Method 1: Using Visual Studio
1. **Open the project**
   - Double-click `FlightBookingApp.sln`
   
2. **Run the application**
   - Press `F5` or click the green "Run" button
   - Browser will automatically open to Swagger UI

### Method 2: Using Command Line / Terminal

#### Step 1: Navigate to Project Directory
```bash
cd "C:\Users\AyushNik\Downloads\new assignment\Assignment\FlightBookingApp"
```

#### Step 2: Restore NuGet Packages (First time only)
```bash
dotnet restore
```

#### Step 3: Build the Project
```bash
dotnet build
```

#### Step 4: Run the Application
```bash
dotnet run
```

#### Step 5: Access the Application
- Open your browser and go to: **https://localhost:5001/swagger**
- Or: **http://localhost:5000/swagger**

## Testing the API Endpoints

### 1. Sign Up (Create a new user)
- **Endpoint**: `POST /api/authapi/signup`
- **Request Body**:
```json
{
  "username": "testuser",
  "password": "password123"
}
```

### 2. Sign In (Get JWT Token)
- **Endpoint**: `POST /api/authapi/signin`
- **Request Body**:
```json
{
  "username": "testuser",
  "password": "password123"
}
```
- **Response**: You'll get a JWT token like:
```json
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

### 3. Search Flights
- **Endpoint**: `POST /api/bookingapi/search`
- **Request Body**:
```json
{
  "from": "NYC",
  "to": "SFO",
  "date": "2016-01-22T00:00:00"
}
```

### 4. Create Booking (Requires Authentication)
- **Endpoint**: `POST /api/bookingapi/create`
- **Authorization**: Bearer Token (from Sign In)
- **Request Body**:
```json
{
  "flightId": 1,
  "firstName": "John",
  "lastName": "Doe",
  "gender": "Male"
}
```

## Using Swagger UI

1. **Open Swagger**: https://localhost:5001/swagger
2. **Sign Up**: Use `/api/authapi/signup` to create a user
3. **Sign In**: Use `/api/authapi/signin` to get a token
4. **Authorize**: 
   - Click the green "Authorize" button at the top
   - Enter: `Bearer YOUR_TOKEN_HERE`
   - Click "Authorize"
5. **Test Protected Endpoints**: Now you can test `/api/bookingapi/create`

## Troubleshooting

### Issue: "Failed to load API definitions"
**Solution**: Make sure you're running in Development mode
- Check that `ASPNETCORE_ENVIRONMENT=Development` is set

### Issue: Database connection error
**Solution**: Check your SQL Server connection
- Verify SQL Server is running
- Update connection string in `appsettings.json` if needed

### Issue: Port already in use
**Solution**: Change the port in `Properties/launchSettings.json`
```json
"applicationUrl": "https://localhost:5001;http://localhost:5000"
```

### Issue: JWT Token errors
**Solution**: The JWT key has been updated to meet minimum length requirements
- Current key: "ayushthegreat-secret-key-for-jwt-token"

## Database Information
- **Server**: LIN-5CG11529M9
- **Database**: SimpleFlightBookingDb
- **Authentication**: Windows Authentication (Trusted_Connection)

The database will be automatically created when you first run the application!

## Pre-seeded Data
The following flights are available for testing:
- Flight BF101: NYC → SFO (2016-01-22) - $101
- Flight BF105: NYC → SFO (2016-01-22) - $105
- Flight BF106: NYC → SFO (2016-01-22) - $106

## Architecture
- **Controllers**: Handle HTTP requests
- **Services**: Business logic layer
- **Repository**: Data access layer
- **Models**: Domain entities and DTOs

