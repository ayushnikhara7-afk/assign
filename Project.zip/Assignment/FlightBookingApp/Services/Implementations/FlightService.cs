using FlightBookingApp.Models.Domain;
using FlightBookingApp.Repository.Interfaces;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Services.Implementations
{
    public class FlightService : IFlightService
    {
        private readonly IFlightRepository _flightRepo;
        
        public FlightService(IFlightRepository flightRepo)
        {
            _flightRepo = flightRepo;
        }

        public List<Flight> SearchFlights(string from, string to, DateTime date)
        {
            return _flightRepo.SearchFlights(from, to, date);
        }

        public Flight? GetFlightById(int id)
        {
            return _flightRepo.GetById(id);
        }
    }
}

