using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Repository.Interfaces;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Services.Implementations
{
    public class AdminService : IAdminService
    {
        private readonly IFlightRepository _flightRepo;
        
        public AdminService(IFlightRepository flightRepo)
        {
            _flightRepo = flightRepo;
        }

        public List<Flight> GetAllFlights()
        {
            return _flightRepo.GetAllFlights();
        }

        public Flight? GetFlightById(int id)
        {
            return _flightRepo.GetById(id);
        }

        public Flight CreateFlight(CreateFlightRequest request)
        {
            var flight = new Flight
            {
                FlightNumber = request.FlightNumber,
                From = request.From,
                To = request.To,
                Date = request.Date,
                Fare = request.Fare
            };

            return _flightRepo.Add(flight);
        }

        public Flight UpdateFlight(UpdateFlightRequest request)
        {
            var existingFlight = _flightRepo.GetById(request.Id);
            if (existingFlight == null)
            {
                throw new ArgumentException("Flight not found");
            }

            existingFlight.FlightNumber = request.FlightNumber;
            existingFlight.From = request.From;
            existingFlight.To = request.To;
            existingFlight.Date = request.Date;
            existingFlight.Fare = request.Fare;

            return _flightRepo.Update(existingFlight);
        }

        public bool DeleteFlight(int id)
        {
            return _flightRepo.Delete(id);
        }

        public bool ValidateAdmin(string username, string password)
        {
            // Simple admin validation - in production, this should be more secure
            // You can extend this to use a proper admin table or role-based authentication
            return username == "admin" && password == "admin123";
        }
    }
}
