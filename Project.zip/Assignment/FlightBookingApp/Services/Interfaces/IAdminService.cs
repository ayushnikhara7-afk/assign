using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Repository.Interfaces;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Services.Interfaces
{
    public interface IAdminService
    {
        List<Flight> GetAllFlights();
        Flight? GetFlightById(int id);
        Flight CreateFlight(CreateFlightRequest request);
        Flight UpdateFlight(UpdateFlightRequest request);
        bool DeleteFlight(int id);
        bool ValidateAdmin(string username, string password);
    }
}
