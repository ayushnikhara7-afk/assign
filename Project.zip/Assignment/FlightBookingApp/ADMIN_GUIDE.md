# 🛡️ Admin Panel - Flight Management Guide

## 🔐 **Admin Login Credentials**
- **Username**: `admin`
- **Password**: `admin123`

---

## 🚀 **How to Use Admin Panel**

### **Step 1: Admin Login**
1. **Restart your application** (`dotnet run`)
2. Go to Swagger: `http://localhost:5001/swagger`
3. Find **POST /api/admin/login**
4. Click **"Try it out"**
5. Enter admin credentials:
```json
{
  "username": "admin",
  "password": "admin123"
}
```
6. Click **"Execute"**
7. **Copy the admin token** from the response

### **Step 2: Authorize as Admin**
1. Click the green **"Authorize"** button in Swagger
2. Enter: `Bearer YOUR_ADMIN_TOKEN`
3. Click **"Authorize"** then **"Close"**

### **Step 3: Manage Flights**

Now you can use all admin endpoints:

---

## 📋 **Admin API Endpoints**

### **1. Get All Flights**
- **Endpoint**: `GET /api/admin/flights`
- **Description**: View all flights in the database
- **Authentication**: Required (Admin token)

### **2. Get Flight by ID**
- **Endpoint**: `GET /api/admin/flights/{id}`
- **Description**: Get details of a specific flight
- **Example**: `GET /api/admin/flights/1`
- **Authentication**: Required (Admin token)

### **3. Create New Flight**
- **Endpoint**: `POST /api/admin/flights`
- **Description**: Add a new flight to the database
- **Request Body**:
```json
{
  "flightNumber": "BF201",
  "from": "LAX",
  "to": "NYC",
  "date": "2025-01-15T10:00:00",
  "fare": 250.00
}
```
- **Authentication**: Required (Admin token)

### **4. Update Existing Flight**
- **Endpoint**: `PUT /api/admin/flights`
- **Description**: Update an existing flight
- **Request Body**:
```json
{
  "id": 1,
  "flightNumber": "BF101",
  "from": "NYC",
  "to": "SFO",
  "date": "2016-01-22T08:00:00",
  "fare": 120.00
}
```
- **Authentication**: Required (Admin token)

### **5. Delete Flight**
- **Endpoint**: `DELETE /api/admin/flights/{id}`
- **Description**: Remove a flight from the database
- **Example**: `DELETE /api/admin/flights/1`
- **Authentication**: Required (Admin token)

---

## 🎯 **Complete Admin Workflow Example**

### **Scenario: Add a New Flight**

1. **Login as Admin**:
```json
POST /api/admin/login
{
  "username": "admin",
  "password": "admin123"
}
```

2. **Authorize** with the received token

3. **Create New Flight**:
```json
POST /api/admin/flights
{
  "flightNumber": "BF301",
  "from": "CHI",
  "to": "MIA",
  "date": "2025-02-01T14:30:00",
  "fare": 180.50
}
```

4. **Verify Flight Created**:
```json
GET /api/admin/flights
```

5. **Update Flight Fare**:
```json
PUT /api/admin/flights
{
  "id": 4,
  "flightNumber": "BF301",
  "from": "CHI",
  "to": "MIA",
  "date": "2025-02-01T14:30:00",
  "fare": 175.00
}
```

---

## 🔒 **Security Features**

- **Admin Authentication**: Separate admin login system
- **JWT Tokens**: Admin tokens last 2 hours (longer than user tokens)
- **Role Claims**: Admin tokens include "Admin" role claim
- **Protected Endpoints**: All admin operations require authentication

---

## 📊 **Database Impact**

- **Flights Table**: Admin can add, update, and delete flights
- **Bookings**: Existing bookings remain intact
- **Users**: Admin operations don't affect user accounts

---

## ⚠️ **Important Notes**

1. **Admin Credentials**: Currently hardcoded for demo purposes
   - In production, store admin credentials securely in database
   - Consider implementing role-based authentication

2. **Flight Validation**: 
   - Flight numbers must be unique
   - Fare must be greater than 0
   - Date must be valid

3. **Cascade Effects**:
   - Deleting flights may affect existing bookings
   - Consider soft delete for production use

---

## 🧪 **Testing Admin Features**

### **Test Data Examples**:

**Add Domestic Flight**:
```json
{
  "flightNumber": "AA101",
  "from": "NYC",
  "to": "LAX",
  "date": "2025-01-20T09:00:00",
  "fare": 299.99
}
```

**Add International Flight**:
```json
{
  "flightNumber": "BA202",
  "from": "LHR",
  "to": "JFK",
  "date": "2025-01-25T15:30:00",
  "fare": 850.00
}
```

---

## 🎉 **You're All Set!**

Your admin panel is now fully functional! Admins can:
- ✅ View all flights
- ✅ Add new flights
- ✅ Update existing flights
- ✅ Delete flights
- ✅ Secure authentication

**Restart your app and test the admin functionality!** 🚀

