using Microsoft.EntityFrameworkCore;
using FlightBookingApp.Models.Domain;

namespace FlightBookingApp.Data
{
    public class FlightDbContext : DbContext
    {
        public FlightDbContext(DbContextOptions<FlightDbContext> options) : base(options)
        {
        }

        public DbSet<Flight> Flights { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<Flight>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.FlightNumber).IsRequired().HasMaxLength(10);
                entity.Property(e => e.From).IsRequired().HasMaxLength(3);
                entity.Property(e => e.To).IsRequired().HasMaxLength(3);
                entity.Property(e => e.Fare).HasColumnType("decimal(10,2)");
            });

            modelBuilder.Entity<Booking>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.ReferenceNumber).IsRequired().HasMaxLength(50);
                entity.Property(e => e.FirstName).IsRequired().HasMaxLength(100);
                entity.Property(e => e.LastName).IsRequired().HasMaxLength(100);
                entity.Property(e => e.Gender).IsRequired().HasMaxLength(10);
                entity.HasIndex(e => e.ReferenceNumber).IsUnique();
            });

            modelBuilder.Entity<Flight>().HasData(
                new Flight
                {
                    Id = 1,
                    FlightNumber = "BF101",
                    From = "NYC",
                    To = "SFO",
                    Date = new DateTime(2016, 1, 22),
                    Fare = 101
                },
                new Flight
                {
                    Id = 2,
                    FlightNumber = "BF105",
                    From = "NYC",
                    To = "SFO",
                    Date = new DateTime(2016, 1, 22),
                    Fare = 105
                },
                new Flight
                {
                    Id = 3,
                    FlightNumber = "BF106",
                    From = "NYC",
                    To = "SFO",
                    Date = new DateTime(2016, 1, 22),
                    Fare = 106
                }
            );
        }
    }
}
