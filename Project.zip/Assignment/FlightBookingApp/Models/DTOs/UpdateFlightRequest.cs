using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models.DTOs
{
    public class UpdateFlightRequest
    {
        [Required]
        public int Id { get; set; }
        
        [Required]
        [MaxLength(10)]
        public string FlightNumber { get; set; } = string.Empty;
        
        [Required]
        [MaxLength(3)]
        public string From { get; set; } = string.Empty;
        
        [Required]
        [MaxLength(3)]
        public string To { get; set; } = string.Empty;
        
        [Required]
        public DateTime Date { get; set; }
        
        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Fare must be greater than 0")]
        public decimal Fare { get; set; }
    }
}

