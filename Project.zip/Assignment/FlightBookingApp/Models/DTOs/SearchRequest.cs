using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models.DTOs
{
    public class SearchRequest
    {
        [Required]
        public string From { get; set; } = string.Empty;
        
        [Required]
        public string To { get; set; } = string.Empty;
        
        [Required]
        public DateTime Date { get; set; }
    }
}

