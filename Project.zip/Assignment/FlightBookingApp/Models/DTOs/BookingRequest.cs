using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models.DTOs
{
    public class BookingRequest
    {
        [Required]
        public int FlightId { get; set; }
        
        [Required]
        public string FirstName { get; set; } = string.Empty;
        
        [Required]
        public string LastName { get; set; } = string.Empty;
        
        [Required]
        public string Gender { get; set; } = string.Empty;
    }
}

