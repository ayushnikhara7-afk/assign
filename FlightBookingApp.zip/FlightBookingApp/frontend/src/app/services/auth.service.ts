import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface UserRegisterRequest {
  username: string;
  password: string;
  firstName: string;
  lastName: string;
  email: string;
}

export interface UserLoginRequest {
  username: string;
  password: string;
}

export interface MessageResponse {
  message: string;
}

export interface SigninResponse {
  token: string;
  message: string;
}

export interface AdminLoginRequest {
  username: string;
  password: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private readonly basePath = '/api/AuthApi';
  private readonly adminBasePath = '/api/Admin';

  signup(body: UserRegisterRequest): Observable<MessageResponse> {
    return this.http.post<MessageResponse>(`${this.basePath}/signup`, body);
  }

  signin(body: UserLoginRequest): Observable<SigninResponse> {
    return this.http.post<SigninResponse>(`${this.basePath}/signin`, body);
  }

  adminLogin(body: AdminLoginRequest): Observable<SigninResponse> {
    return this.http.post<SigninResponse>(`${this.adminBasePath}/login`, body);
  }
  
  isLoggedIn(): boolean {
    return !!localStorage.getItem('auth_token');
  }

  logout(): void {
    localStorage.removeItem('auth_token');
  }
}





