import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Flight } from './flight.service';

export interface User {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
}

export interface CreateFlightRequest {
  flightNumber: string;
  from: string;
  to: string;
  date: string;
  fare: number;
}

export interface UpdateFlightRequest {
  id: number;
  flightNumber: string;
  from: string;
  to: string;
  date: string;
  fare: number;
}

export interface UpdateUserRequest {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  email: string;
}

export interface MessageResponse {
  message: string;
}

export interface FlightResponse {
  flight: Flight;
  message: string;
}

export interface UserResponse {
  user: User;
  message: string;
}

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private http = inject(HttpClient);
  private readonly basePath = '/api/Admin';

  // Flight Management
  createFlight(request: CreateFlightRequest): Observable<FlightResponse> {
    return this.http.post<FlightResponse>(`${this.basePath}/flights`, request);
  }

  updateFlight(request: UpdateFlightRequest): Observable<FlightResponse> {
    return this.http.put<FlightResponse>(`${this.basePath}/flights`, request);
  }

  deleteFlight(id: number): Observable<MessageResponse> {
    return this.http.delete<MessageResponse>(`${this.basePath}/flights/${id}`);
  }

  getAllFlights(): Observable<Flight[]> {
    return this.http.get<Flight[]>(`${this.basePath}/flights`);
  }

  // User Management
  getAllUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.basePath}/users`);
  }

  updateUser(request: UpdateUserRequest): Observable<UserResponse> {
    return this.http.put<UserResponse>(`${this.basePath}/users`, request);
  }

  deleteUser(id: number): Observable<MessageResponse> {
    return this.http.delete<MessageResponse>(`${this.basePath}/users/${id}`);
  }
}

