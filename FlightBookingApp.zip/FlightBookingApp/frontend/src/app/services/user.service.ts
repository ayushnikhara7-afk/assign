import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface UserProfile {
  id: number;
  username: string;
  email: string;
  firstName: string;
  lastName: string;
}

export interface UpdateUserProfileRequest {
  username: string;
  email: string;
  firstName: string;
  lastName: string;
}

export interface UpdateUserProfileResponse {
  message: string;
  user: UserProfile;
}

@Injectable({ providedIn: 'root' })
export class UserService {
  private http = inject(HttpClient);
  private readonly basePath = '/api/User';

  getProfile(): Observable<UserProfile> {
    return this.http.get<UserProfile>(`${this.basePath}/profile`);
  }

  updateProfile(body: UpdateUserProfileRequest): Observable<UpdateUserProfileResponse> {
    return this.http.put<UpdateUserProfileResponse>(`${this.basePath}/profile`, body);
  }
}

