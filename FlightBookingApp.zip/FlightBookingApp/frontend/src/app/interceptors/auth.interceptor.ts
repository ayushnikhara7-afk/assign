import { HttpInterceptorFn } from '@angular/common/http';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  // Check for both user and admin tokens
  const userToken = localStorage.getItem('auth_token');
  const adminToken = localStorage.getItem('admin_token');
  
  // Use admin token for admin routes, user token for user routes
  const token = req.url.includes('/api/Admin') ? adminToken : userToken;
  
  if (token) {
    // Clone the request and add the Authorization header
    const clonedReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
    return next(clonedReq);
  }
  
  return next(req);
};

