import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators, AbstractControl, ValidationErrors } from '@angular/forms';
import { Router } from '@angular/router';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { AdminService, User, CreateFlightRequest, UpdateFlightRequest, UpdateUserRequest } from '../../services/admin.service';
import { Flight } from '../../services/flight.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, NavbarComponent],
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.scss'
})
export class AdminDashboardComponent implements OnInit {
  private fb = inject(FormBuilder);
  private adminService = inject(AdminService);
  private router = inject(Router);

  activeTab: 'flights' | 'users' = 'flights';
  
  // Flight management
  flights: Flight[] = [];
  loadingFlights = false;
  flightsError = '';
  showFlightModal = false;
  flightModalMode: 'create' | 'edit' = 'create';
  selectedFlight: Flight | null = null;
  savingFlight = false;
  flightError = '';
  flightSuccess = '';

  flightForm = this.fb.nonNullable.group({
    flightNumber: ['', [Validators.required]],
    from: ['', [Validators.required]],
    to: ['', [Validators.required]],
    date: ['', [Validators.required, this.futureDateValidator]],
    fare: [0, [Validators.required, Validators.min(0)]]
  });

  // User management
  users: User[] = [];
  loadingUsers = false;
  usersError = '';
  showUserModal = false;
  selectedUser: User | null = null;
  savingUser = false;
  userError = '';
  userSuccess = '';

  userForm = this.fb.nonNullable.group({
    username: ['', [Validators.required, Validators.minLength(3)]],
    firstName: ['', [Validators.required]],
    lastName: ['', [Validators.required]],
    email: ['', [Validators.required, Validators.email]]
  });

  ngOnInit(): void {
    // Check if admin is logged in before loading flights
    const adminToken = localStorage.getItem('admin_token');
    if (!adminToken) {
      this.router.navigate(['/admin-login']);
      return;
    }
    this.loadFlights();
  }

  // Custom validator for future dates
  futureDateValidator(control: AbstractControl): ValidationErrors | null {
    if (!control.value) {
      return null;
    }
    
    const selectedDate = new Date(control.value);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (selectedDate < today) {
      return { pastDate: { message: 'Flight date cannot be in the past' } };
    }
    
    return null;
  }

  // Tab management
  switchTab(tab: 'flights' | 'users'): void {
    this.activeTab = tab;
    if (tab === 'flights') {
      this.loadFlights();
    } else {
      this.loadUsers();
    }
  }

  // Flight operations
  loadFlights(): void {
    const adminToken = localStorage.getItem('admin_token');
    if (!adminToken) {
      this.router.navigate(['/admin-login']);
      return;
    }

    this.loadingFlights = true;
    this.flightsError = '';
    this.adminService.getAllFlights().subscribe({
      next: (flights) => {
        this.flights = flights;
        this.loadingFlights = false;
      },
      error: (err) => {
        this.loadingFlights = false;
        console.error('Flight loading error:', err);
        
        if (err?.status === 401) {
          this.flightsError = 'Admin session expired. Please login again.';
          setTimeout(() => {
            localStorage.removeItem('admin_token');
            this.router.navigate(['/admin-login']);
          }, 2000);
        } else {
          this.flightsError = err?.error?.message || 'Failed to load flights';
        }
      }
    });
  }

  openCreateFlightModal(): void {
    this.flightModalMode = 'create';
    this.selectedFlight = null;
    this.showFlightModal = true;
    this.flightForm.reset();
    this.flightError = '';
    this.flightSuccess = '';
  }

  openEditFlightModal(flight: Flight): void {
    this.flightModalMode = 'edit';
    this.selectedFlight = flight;
    this.showFlightModal = true;
    this.flightForm.patchValue({
      flightNumber: flight.flightNumber,
      from: flight.from,
      to: flight.to,
      date: flight.date.split('T')[0],
      fare: flight.fare
    });
    this.flightError = '';
    this.flightSuccess = '';
  }

  closeFlightModal(): void {
    this.showFlightModal = false;
    this.selectedFlight = null;
    this.flightError = '';
    this.flightSuccess = '';
  }

  submitFlight(): void {
    if (this.flightForm.invalid) {
      this.flightForm.markAllAsTouched();
      return;
    }

    this.savingFlight = true;
    this.flightError = '';
    this.flightSuccess = '';

    const formValue = this.flightForm.getRawValue();

    if (this.flightModalMode === 'create') {
      const request: CreateFlightRequest = formValue;
      this.adminService.createFlight(request).subscribe({
        next: (response) => {
          this.savingFlight = false;
          this.flightSuccess = response.message;
          this.loadFlights();
          setTimeout(() => this.closeFlightModal(), 1500);
        },
        error: (err) => {
          this.savingFlight = false;
          this.flightError = err?.error?.message || 'Failed to create flight';
        }
      });
    } else {
      const request: UpdateFlightRequest = {
        id: this.selectedFlight!.id,
        ...formValue
      };
      this.adminService.updateFlight(request).subscribe({
        next: (response) => {
          this.savingFlight = false;
          this.flightSuccess = response.message;
          this.loadFlights();
          setTimeout(() => this.closeFlightModal(), 1500);
        },
        error: (err) => {
          this.savingFlight = false;
          this.flightError = err?.error?.message || 'Failed to update flight';
        }
      });
    }
  }

  deleteFlight(flight: Flight): void {
    if (!confirm(`Are you sure you want to delete flight ${flight.flightNumber}?`)) {
      return;
    }

    this.adminService.deleteFlight(flight.id).subscribe({
      next: () => {
        this.loadFlights();
      },
      error: (err) => {
        alert(err?.error?.message || 'Failed to delete flight');
      }
    });
  }

  // User operations
  loadUsers(): void {
    const adminToken = localStorage.getItem('admin_token');
    if (!adminToken) {
      this.router.navigate(['/admin-login']);
      return;
    }

    this.loadingUsers = true;
    this.usersError = '';
    this.adminService.getAllUsers().subscribe({
      next: (users) => {
        this.users = users;
        this.loadingUsers = false;
      },
      error: (err) => {
        this.loadingUsers = false;
        console.error('Users loading error:', err);
        
        if (err?.status === 401) {
          this.usersError = 'Admin session expired. Please login again.';
          setTimeout(() => {
            localStorage.removeItem('admin_token');
            this.router.navigate(['/admin-login']);
          }, 2000);
        } else {
          this.usersError = err?.error?.message || 'Failed to load users';
        }
      }
    });
  }

  openEditUserModal(user: User): void {
    this.selectedUser = user;
    this.showUserModal = true;
    this.userForm.patchValue({
      username: user.username,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email
    });
    this.userError = '';
    this.userSuccess = '';
  }

  closeUserModal(): void {
    this.showUserModal = false;
    this.selectedUser = null;
    this.userError = '';
    this.userSuccess = '';
  }

  submitUser(): void {
    if (this.userForm.invalid) {
      this.userForm.markAllAsTouched();
      return;
    }

    this.savingUser = true;
    this.userError = '';
    this.userSuccess = '';

    const request: UpdateUserRequest = {
      id: this.selectedUser!.id,
      ...this.userForm.getRawValue()
    };

    this.adminService.updateUser(request).subscribe({
      next: (response) => {
        this.savingUser = false;
        this.userSuccess = response.message;
        this.loadUsers();
        setTimeout(() => this.closeUserModal(), 1500);
      },
      error: (err) => {
        this.savingUser = false;
        this.userError = err?.error?.message || 'Failed to update user';
      }
    });
  }

  deleteUser(user: User): void {
    if (!confirm(`Are you sure you want to delete user ${user.username}?`)) {
      return;
    }

    this.adminService.deleteUser(user.id).subscribe({
      next: () => {
        this.loadUsers();
      },
      error: (err) => {
        alert(err?.error?.message || 'Failed to delete user');
      }
    });
  }

  logout(): void {
    localStorage.removeItem('admin_token');
    this.router.navigateByUrl('/admin-login');
  }
}

