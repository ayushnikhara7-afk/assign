import { Component, inject, OnInit } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { ToastService } from '../../services/toast.service';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.scss'
})
export class ProfileComponent implements OnInit {
  private fb = inject(FormBuilder);
  private userService = inject(UserService);
  private router = inject(Router);
  private toast = inject(ToastService);

  loading = false;
  loadingProfile = true;
  error = '';
  success = '';

  form = this.fb.nonNullable.group({
    username: ['', [Validators.required, Validators.minLength(3)]],
    email: ['', [Validators.required, Validators.email]],
    firstName: ['', [Validators.required, Validators.minLength(2)]],
    lastName: ['', [Validators.required, Validators.minLength(2)]]
  });

  ngOnInit(): void {
    this.loadProfile();
  }

  loadProfile(): void {
    this.loadingProfile = true;
    this.userService.getProfile().subscribe({
      next: (profile) => {
        this.form.patchValue({
          username: profile.username,
          email: profile.email,
          firstName: profile.firstName,
          lastName: profile.lastName
        });
        this.loadingProfile = false;
      },
      error: (err) => {
        this.error = err?.error?.message || 'Failed to load profile';
        this.loadingProfile = false;
        this.toast.error('Failed to load profile');
      }
    });
  }

  onSubmit(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.loading = true;
    this.error = '';
    this.success = '';

    this.userService.updateProfile(this.form.getRawValue()).subscribe({
      next: (res) => {
        this.loading = false;
        this.success = 'Profile updated successfully! A confirmation email has been sent.';
        this.toast.success('Profile updated successfully!');
      },
      error: (err) => {
        this.loading = false;
        this.error = err?.error?.message || 'Failed to update profile';
        this.toast.error(this.error);
      }
    });
  }

  onCancel(): void {
    this.router.navigateByUrl('/home');
  }
}
