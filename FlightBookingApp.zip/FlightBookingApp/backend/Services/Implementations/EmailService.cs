using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Options;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Services.Implementations
{
    public class EmailService : IEmailService
    {
        private readonly EmailSettings _emailSettings;
        private readonly ILogger<EmailService> _logger;

        public EmailService(IOptions<EmailSettings> emailSettings, ILogger<EmailService> logger)
        {
            _emailSettings = emailSettings.Value;
            _logger = logger;
        }

        public async Task SendEmailAsync(string toEmail, string subject, string htmlBody)
        {
            try
            {
                using var smtpClient = new SmtpClient(_emailSettings.SmtpServer, _emailSettings.SmtpPort)
                {
                    EnableSsl = _emailSettings.EnableSsl,
                    Credentials = new NetworkCredential(_emailSettings.Username, _emailSettings.Password)
                };

                var mailMessage = new MailMessage
                {
                    From = new MailAddress(_emailSettings.SenderEmail, _emailSettings.SenderName),
                    Subject = subject,
                    Body = htmlBody,
                    IsBodyHtml = true
                };

                mailMessage.To.Add(toEmail);

                await smtpClient.SendMailAsync(mailMessage);
                _logger.LogInformation($"Email sent successfully to {toEmail}");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to send email to {toEmail}: {ex.Message}");
                // Don't throw exception - just log it so app continues working even if email fails
            }
        }

        public async Task SendWelcomeEmailAsync(string toEmail, string userName)
        {
            var subject = "Welcome to Flight Booking System!";
            var htmlBody = $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
                        .button {{ display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }}
                        .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 12px; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h1>Welcome to Flight Booking System!</h1>
                        </div>
                        <div class='content'>
                            <h2>Hello {userName}!</h2>
                            <p>Thank you for registering with Flight Booking System. We're excited to have you on board!</p>
                            <p>With your account, you can:</p>
                            <ul>
                                <li>Search and book flights</li>
                                <li>Manage your bookings</li>
                                <li>Check-in online</li>
                                <li>View your travel history</li>
                            </ul>
                            <p>Start exploring destinations and book your next adventure today!</p>
                            <a href='#' class='button'>Start Booking</a>
                        </div>
                        <div class='footer'>
                            <p>© 2025 Flight Booking System. All rights reserved.</p>
                        </div>
                    </div>
                </body>
                </html>
            ";

            await SendEmailAsync(toEmail, subject, htmlBody);
        }

        public async Task SendBookingConfirmationAsync(string toEmail, string passengerName, string referenceNumber, string flightNumber, string from, string to, DateTime flightDate)
        {
            var subject = $"Booking Confirmation - {referenceNumber}";
            var htmlBody = $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
                        .booking-details {{ background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }}
                        .detail-row {{ display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; }}
                        .detail-label {{ font-weight: bold; color: #667eea; }}
                        .reference {{ font-size: 24px; font-weight: bold; color: #667eea; text-align: center; padding: 20px; background: white; border-radius: 8px; margin: 20px 0; }}
                        .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 12px; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h1>✈️ Booking Confirmed!</h1>
                        </div>
                        <div class='content'>
                            <h2>Hello {passengerName}!</h2>
                            <p>Your flight booking has been confirmed. Please save this email for your records.</p>
                            
                            <div class='reference'>
                                Booking Reference: {referenceNumber}
                            </div>

                            <div class='booking-details'>
                                <h3>Flight Details</h3>
                                <div class='detail-row'>
                                    <span class='detail-label'>Flight Number:</span>
                                    <span>{flightNumber}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>From:</span>
                                    <span>{from}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>To:</span>
                                    <span>{to}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>Date:</span>
                                    <span>{flightDate:MMMM dd, yyyy}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>Passenger:</span>
                                    <span>{passengerName}</span>
                                </div>
                            </div>

                            <p><strong>What's Next?</strong></p>
                            <ul>
                                <li>Check in online 24 hours before your flight</li>
                                <li>Arrive at the airport at least 2 hours before departure</li>
                                <li>Keep your booking reference handy</li>
                            </ul>

                            <p>Have a great flight! ✈️</p>
                        </div>
                        <div class='footer'>
                            <p>© 2025 Flight Booking System. All rights reserved.</p>
                            <p>For support, please contact us at support@flightbooking.com</p>
                        </div>
                    </div>
                </body>
                </html>
            ";

            await SendEmailAsync(toEmail, subject, htmlBody);
        }

        public async Task SendPasswordResetEmailAsync(string toEmail, string userName)
        {
            var subject = "Password Reset Instructions";
            var htmlBody = $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
                        .button {{ display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }}
                        .warning {{ background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; }}
                        .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 12px; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h1>Password Reset Request</h1>
                        </div>
                        <div class='content'>
                            <h2>Hello {userName}!</h2>
                            <p>We received a request to reset your password for your Flight Booking System account.</p>
                            
                            <p>Your password has been reset successfully. You can now log in with your new password.</p>

                            <div class='warning'>
                                <strong>Security Note:</strong> If you didn't request this password reset, please contact our support team immediately.
                            </div>

                            <a href='#' class='button'>Login to Your Account</a>
                        </div>
                        <div class='footer'>
                            <p>© 2025 Flight Booking System. All rights reserved.</p>
                            <p>This is an automated email, please do not reply.</p>
                        </div>
                    </div>
                </body>
                </html>
            ";

            await SendEmailAsync(toEmail, subject, htmlBody);
        }

        public async Task SendCheckinConfirmationAsync(string toEmail, string passengerName, string referenceNumber, string flightNumber, string from, string to, DateTime flightDate, string seatNumber)
        {
            var subject = $"Check-in Confirmation - {referenceNumber}";
            var htmlBody = $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
                        .boarding-pass {{ background: white; padding: 20px; border-radius: 8px; margin: 20px 0; border-left: 4px solid #667eea; }}
                        .detail-row {{ display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; }}
                        .detail-label {{ font-weight: bold; color: #667eea; }}
                        .seat-number {{ font-size: 32px; font-weight: bold; color: #667eea; text-align: center; padding: 20px; background: white; border-radius: 8px; margin: 20px 0; border: 2px dashed #667eea; }}
                        .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 12px; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h1>✅ Check-in Successful!</h1>
                        </div>
                        <div class='content'>
                            <h2>Hello {passengerName}!</h2>
                            <p>You have successfully checked in for your flight. Your boarding pass is ready!</p>
                            
                            <div class='seat-number'>
                                Seat Number: {seatNumber}
                            </div>

                            <div class='boarding-pass'>
                                <h3>Flight Details</h3>
                                <div class='detail-row'>
                                    <span class='detail-label'>Booking Reference:</span>
                                    <span>{referenceNumber}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>Flight Number:</span>
                                    <span>{flightNumber}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>From:</span>
                                    <span>{from}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>To:</span>
                                    <span>{to}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>Date:</span>
                                    <span>{flightDate:MMMM dd, yyyy}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>Passenger:</span>
                                    <span>{passengerName}</span>
                                </div>
                            </div>

                            <p><strong>Important Reminders:</strong></p>
                            <ul>
                                <li>Arrive at the airport at least 2 hours before departure</li>
                                <li>Bring a valid photo ID</li>
                                <li>Keep your booking reference handy</li>
                                <li>Your seat number is {seatNumber}</li>
                            </ul>

                            <p>Have a wonderful flight! ✈️</p>
                        </div>
                        <div class='footer'>
                            <p>© 2025 Flight Booking System. All rights reserved.</p>
                            <p>For support, please contact us at support@flightbooking.com</p>
                        </div>
                    </div>
                </body>
                </html>
            ";

            await SendEmailAsync(toEmail, subject, htmlBody);
        }

        public async Task SendPaymentSuccessAsync(string toEmail, string passengerName, string referenceNumber, string flightNumber, decimal amount, DateTime paymentDate)
        {
            var subject = $"Payment Successful - {referenceNumber}";
            var htmlBody = $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                        .header {{ background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
                        .payment-details {{ background: white; padding: 20px; border-radius: 8px; margin: 20px 0; }}
                        .detail-row {{ display: flex; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #eee; }}
                        .detail-label {{ font-weight: bold; color: #10b981; }}
                        .amount {{ font-size: 36px; font-weight: bold; color: #10b981; text-align: center; padding: 20px; background: white; border-radius: 8px; margin: 20px 0; }}
                        .success-icon {{ font-size: 64px; text-align: center; }}
                        .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 12px; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <div class='success-icon'>✓</div>
                            <h1>Payment Successful!</h1>
                        </div>
                        <div class='content'>
                            <h2>Hello {passengerName}!</h2>
                            <p>Your payment has been successfully processed. Thank you for your payment!</p>
                            
                            <div class='amount'>
                                ${amount:F2}
                            </div>

                            <div class='payment-details'>
                                <h3>Payment Details</h3>
                                <div class='detail-row'>
                                    <span class='detail-label'>Booking Reference:</span>
                                    <span>{referenceNumber}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>Flight Number:</span>
                                    <span>{flightNumber}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>Amount Paid:</span>
                                    <span>${amount:F2}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>Payment Date:</span>
                                    <span>{paymentDate:MMMM dd, yyyy HH:mm}</span>
                                </div>
                                <div class='detail-row'>
                                    <span class='detail-label'>Status:</span>
                                    <span style='color: #10b981; font-weight: bold;'>PAID</span>
                                </div>
                            </div>

                            <p><strong>What's Next?</strong></p>
                            <ul>
                                <li>Check in online 24 hours before your flight</li>
                                <li>Download your boarding pass</li>
                                <li>Arrive at the airport on time</li>
                            </ul>

                            <p>If you have any questions, please don't hesitate to contact us.</p>
                        </div>
                        <div class='footer'>
                            <p>© 2025 Flight Booking System. All rights reserved.</p>
                            <p>For support, please contact us at support@flightbooking.com</p>
                        </div>
                    </div>
                </body>
                </html>
            ";

            await SendEmailAsync(toEmail, subject, htmlBody);
        }

        public async Task SendProfileUpdateAsync(string toEmail, string userName)
        {
            var subject = "Profile Updated Successfully";
            var htmlBody = $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
                        .info-box {{ background: #e0e7ff; border-left: 4px solid #667eea; padding: 15px; margin: 20px 0; }}
                        .warning {{ background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; }}
                        .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 12px; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h1>Profile Updated</h1>
                        </div>
                        <div class='content'>
                            <h2>Hello {userName}!</h2>
                            <p>Your profile information has been successfully updated.</p>
                            
                            <div class='info-box'>
                                <strong>📝 Update Confirmed</strong><br>
                                Your account details have been changed. You can continue using your account with the updated information.
                            </div>

                            <div class='warning'>
                                <strong>Security Notice:</strong> If you didn't make these changes, please contact our support team immediately at support@flightbooking.com
                            </div>

                            <p>Thank you for keeping your information up to date!</p>
                        </div>
                        <div class='footer'>
                            <p>© 2025 Flight Booking System. All rights reserved.</p>
                            <p>This is an automated email, please do not reply.</p>
                        </div>
                    </div>
                </body>
                </html>
            ";

            await SendEmailAsync(toEmail, subject, htmlBody);
        }
    }
}

