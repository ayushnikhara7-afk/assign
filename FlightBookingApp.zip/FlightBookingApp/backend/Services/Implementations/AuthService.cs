using FlightBookingApp.Models.Domain;
using FlightBookingApp.Repository.Interfaces;
using FlightBookingApp.Services.Interfaces;
using FlightBookingApp.Utils;

namespace FlightBookingApp.Services.Implementations
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _userRepo;
        private readonly IEmailService _emailService;
        
        public AuthService(IUserRepository userRepo, IEmailService emailService) 
        {
            _userRepo = userRepo;
            _emailService = emailService;
        }

        public bool ValidateUser(string username, string password)
        {
            var user = _userRepo.GetByUsername(username);
            return user != null && PasswordHasher.VerifyPassword(password, user.Password);
        }

        public bool UserExists(string username)
        {
            return _userRepo.GetByUsername(username) != null;
        }

        public bool EmailExists(string email)
        {
            return _userRepo.GetByEmail(email) != null;
        }

        public void RegisterUser(User user)
        {
            _userRepo.Add(user);
            
            // Send welcome email asynchronously
            _ = _emailService.SendWelcomeEmailAsync(user.Email, user.FirstName + " " + user.LastName);
        }

        public bool ResetPassword(string email, string newPassword)
        {
            var user = _userRepo.GetByEmail(email);
            if (user == null)
                return false;

            user.Password = PasswordHasher.HashPassword(newPassword);
            _userRepo.Update(user);
            
            // Send password reset confirmation email asynchronously
            _ = _emailService.SendPasswordResetEmailAsync(user.Email, user.FirstName + " " + user.LastName);
            
            return true;
        }

        public User? GetUserByEmail(string email)
        {
            return _userRepo.GetByEmail(email);
        }

        public User? GetUserByUsername(string username)
        {
            return _userRepo.GetByUsername(username);
        }

        public User? GetUserById(int id)
        {
            return _userRepo.GetById(id);
        }

        public async Task<User> UpdateUserProfileAsync(int userId, string email, string username, string firstName, string lastName)
        {
            var user = _userRepo.GetById(userId);
            if (user == null)
            {
                throw new ArgumentException("User not found");
            }

            // Check if email is being changed to an existing email
            if (user.Email != email)
            {
                var existingUserWithEmail = _userRepo.GetByEmail(email);
                if (existingUserWithEmail != null && existingUserWithEmail.Id != userId)
                {
                    throw new ArgumentException("Email already exists");
                }
            }

            // Check if username is being changed to an existing username
            if (user.Username != username)
            {
                var existingUserWithUsername = _userRepo.GetByUsername(username);
                if (existingUserWithUsername != null && existingUserWithUsername.Id != userId)
                {
                    throw new ArgumentException("Username already exists");
                }
            }

            // Update user details
            user.Email = email;
            user.Username = username;
            user.FirstName = firstName;
            user.LastName = lastName;

            var updatedUser = _userRepo.Update(user);

            // Send profile update notification email
            _ = _emailService.SendProfileUpdateAsync(updatedUser.Email, $"{updatedUser.FirstName} {updatedUser.LastName}");

            return updatedUser;
        }

        public async Task SendPasswordResetInstructionsAsync(string email, string userName, string resetToken)
        {
            // For now, we'll send instructions with the reset password page link
            // In production, you'd include the token and validate it
            var resetLink = $"http://localhost:4200/reset-password?email={email}";
            
            var subject = "Password Reset Instructions";
            var htmlBody = $@"
                <!DOCTYPE html>
                <html>
                <head>
                    <style>
                        body {{ font-family: Arial, sans-serif; line-height: 1.6; color: #333; }}
                        .container {{ max-width: 600px; margin: 0 auto; padding: 20px; }}
                        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }}
                        .content {{ background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }}
                        .button {{ display: inline-block; padding: 12px 30px; background: #667eea; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }}
                        .warning {{ background: #fff3cd; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0; }}
                        .footer {{ text-align: center; margin-top: 30px; color: #666; font-size: 12px; }}
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <div class='header'>
                            <h1>🔐 Password Reset Request</h1>
                        </div>
                        <div class='content'>
                            <h2>Hello {userName}!</h2>
                            <p>We received a request to reset your password for your Flight Booking System account.</p>
                            
                            <p>Click the button below to reset your password:</p>

                            <a href='{resetLink}' class='button'>Reset Your Password</a>

                            <p style='margin-top: 20px;'>Or copy and paste this link into your browser:</p>
                            <p style='background: #f0f0f0; padding: 10px; border-radius: 5px; word-break: break-all;'>{resetLink}</p>

                            <div class='warning'>
                                <strong>Security Note:</strong> If you didn't request this password reset, please ignore this email or contact our support team immediately.
                            </div>

                            <p style='margin-top: 20px; color: #666;'>This link will expire in 24 hours for security reasons.</p>
                        </div>
                        <div class='footer'>
                            <p>© 2025 Flight Booking System. All rights reserved.</p>
                            <p>This is an automated email, please do not reply.</p>
                        </div>
                    </div>
                </body>
                </html>
            ";

            await _emailService.SendEmailAsync(email, subject, htmlBody);
        }
    }
}

