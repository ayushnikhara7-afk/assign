using FlightBookingApp.Services.Interfaces;
using Stripe;

namespace FlightBookingApp.Services.Implementations
{
    public class StripeService : IStripeService
    {
        private readonly IConfiguration _configuration;
        private readonly ILogger<StripeService> _logger;

        public StripeService(IConfiguration configuration, ILogger<StripeService> logger)
        {
            _configuration = configuration;
            _logger = logger;
            
            StripeConfiguration.ApiKey = _configuration["Stripe:SecretKey"];
        }

        public async Task<string> CreatePaymentIntentAsync(
            decimal amount, 
            string currency, 
            string description, 
            Dictionary<string, string>? metadata = null)
        {
            try
            {
                var options = new PaymentIntentCreateOptions
                {
                    Amount = (long)(amount * 100), 
                    Currency = currency.ToLower(),
                    Description = description,
                    Metadata = metadata,
                    AutomaticPaymentMethods = new PaymentIntentAutomaticPaymentMethodsOptions
                    {
                        Enabled = true,
                    },
                };

                var service = new PaymentIntentService();
                var paymentIntent = await service.CreateAsync(options);

                _logger.LogInformation($"Payment Intent created: {paymentIntent.Id}");
                return paymentIntent.ClientSecret ?? string.Empty;
            }
            catch (StripeException ex)
            {
                _logger.LogError($"Stripe error creating payment intent: {ex.Message}");
                throw new ApplicationException($"Payment processing failed: {ex.Message}", ex);
            }
        }

        public async Task<bool> ConfirmPaymentAsync(string paymentIntentId)
        {
            try
            {
                var service = new PaymentIntentService();
                var paymentIntent = await service.GetAsync(paymentIntentId);

                return paymentIntent.Status == "succeeded";
            }
            catch (StripeException ex)
            {
                _logger.LogError($"Stripe error confirming payment: {ex.Message}");
                return false;
            }
        }

        public async Task<string> GetPaymentStatusAsync(string paymentIntentId)
        {
            try
            {
                var service = new PaymentIntentService();
                var paymentIntent = await service.GetAsync(paymentIntentId);

                return paymentIntent.Status;
            }
            catch (StripeException ex)
            {
                _logger.LogError($"Stripe error getting payment status: {ex.Message}");
                throw new ApplicationException($"Failed to get payment status: {ex.Message}", ex);
            }
        }
    }
}

