using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models.Validation
{
    public class FutureDateAttribute : ValidationAttribute
    {
        public bool AllowToday { get; set; } = true;

        public override bool IsValid(object? value)
        {
            if (value == null)
                return true;

            if (value is DateTime date)
            {
                var currentDate = DateTime.UtcNow.Date;
                var inputDate = date.Date;

                if (AllowToday)
                {
                    return inputDate >= currentDate;
                }
                else
                {
                    return inputDate > currentDate;
                }
            }

            return false;
        }

        public override string FormatErrorMessage(string name)
        {
            if (AllowToday)
            {
                return $"{name} must be today or in the future.";
            }
            else
            {
                return $"{name} must be in the future.";
            }
        }
    }
}
