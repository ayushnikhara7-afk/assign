using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FlightBookingApp.Migrations
{
    /// <inheritdoc />
    public partial class AddPaymentColumns : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            // All columns, indexes already exist in the database
            // Only add the foreign key constraint if it doesn't exist
            migrationBuilder.Sql(@"
                IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Bookings_Users_UserId')
                BEGIN
                    ALTER TABLE [Bookings] 
                    ADD CONSTRAINT [FK_Bookings_Users_UserId] 
                    FOREIGN KEY ([UserId]) 
                    REFERENCES [Users] ([Id]);
                END
            ");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            // Only drop what we added
            migrationBuilder.Sql(@"
                IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'FK_Bookings_Users_UserId')
                BEGIN
                    ALTER TABLE [Bookings] DROP CONSTRAINT [FK_Bookings_Users_UserId];
                END
            ");

            // Drop payment columns if they exist
            migrationBuilder.Sql(@"
                IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Bookings') AND name = 'IsPaid')
                    ALTER TABLE [Bookings] DROP COLUMN [IsPaid];
                IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Bookings') AND name = 'PaymentDate')
                    ALTER TABLE [Bookings] DROP COLUMN [PaymentDate];
                IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID('Bookings') AND name = 'PaymentIntentId')
                    ALTER TABLE [Bookings] DROP COLUMN [PaymentIntentId];
            ");
        }
    }
}

