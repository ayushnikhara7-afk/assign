# Booking and Check-in Functionality

## Overview
Successfully added booking and check-in functionality to the Flight Booking application.

## Features Added

### 1. Booking Service (`booking.service.ts`)
- **Create Booking**: Book flights with passenger details (name, gender)
- **Search Bookings**: Search for bookings using reference number
- **Check-in**: Perform check-in for bookings
- **Cancel Booking**: Cancel existing bookings (optional feature)

### 2. Home Page Updates
- Added "Book Now" button to each flight card
- Implemented booking modal with:
  - Flight details summary
  - Passenger information form (First Name, Last Name, Gender)
  - Real-time form validation
  - Success/error messages
  - Loading states with spinner animation
- Users receive a booking reference number upon successful booking

### 3. My Bookings Page (`my-bookings` component)
- **Search Functionality**: Search for bookings using reference number
- **Booking Details Display**:
  - Booking status (Checked In / Not Checked In)
  - Passenger information
  - Flight details (flight number, route, date, fare)
  - Check-in details (seat number, check-in date) if checked in
- **Check-in Feature**:
  - Check-in modal for easy check-in process
  - Automatic seat assignment
  - Real-time status updates
  - Success confirmation with seat number

### 4. Updated Navigation
- Added "My Bookings" link to navbar
- Protected route using auth guard
- Easy navigation between Home and My Bookings pages

## API Endpoints Used

### Booking Endpoints
- `POST /api/BookingApi/create` - Create new booking (requires authentication)
- `DELETE /api/BookingApi/cancel/{referenceNumber}` - Cancel booking (requires authentication)

### Check-in Endpoints
- `GET /api/Checkin/search/{referenceNumber}` - Search booking by reference
- `POST /api/Checkin/checkin` - Perform check-in

### Flight Search
- `GET /api/BookingApi/search` - Search flights by route and date

## User Flow

### Booking a Flight
1. User searches for flights on the Home page
2. User clicks "Book Now" on desired flight
3. Modal opens with flight details and booking form
4. User enters passenger details (first name, last name, gender)
5. User submits the form
6. System creates booking and displays reference number
7. User can use this reference number to check in later

### Checking In
1. User navigates to "My Bookings" page
2. User enters booking reference number and searches
3. Booking details are displayed
4. If not checked in, user clicks "Check-in Now"
5. Check-in modal opens
6. User confirms check-in with reference number
7. System assigns seat and displays success message
8. Booking details refresh to show check-in status and seat number

## Design Features
- Modern gradient backgrounds (purple theme)
- Smooth animations (fadeIn, slideIn, modal transitions)
- Responsive design for mobile and desktop
- Beautiful card-based UI
- Status badges (color-coded for checked-in vs not checked-in)
- Icon integration throughout
- Loading spinners for async operations
- Error and success alerts with appropriate styling

## Security
- Authentication required for creating bookings
- Auth guard protects My Bookings route
- JWT token stored in localStorage
- Bearer token sent with authenticated requests

## How to Test

### Start the Backend
```bash
cd backend
dotnet run
```
Backend will run on `http://localhost:5001`

### Start the Frontend
```bash
cd frontend
npm start
```
Frontend will run on `http://localhost:4200`

### Test Flow
1. **Sign up** or **Login** to the application
2. On **Home page**:
   - Enter origin, destination, and date
   - Click "Search Flights"
   - View available flights
   - Click "Book Now" on any flight
   - Fill in passenger details
   - Complete booking and note the reference number
3. Go to **My Bookings**:
   - Enter the reference number
   - Click "Search Booking"
   - View booking details
   - Click "Check-in Now" (if not already checked in)
   - Complete check-in and view seat assignment

## Files Modified/Created

### Created
- `frontend/src/app/services/booking.service.ts`
- `frontend/src/app/pages/my-bookings/my-bookings.component.ts`
- `frontend/src/app/pages/my-bookings/my-bookings.component.html`
- `frontend/src/app/pages/my-bookings/my-bookings.component.scss`

### Modified
- `frontend/src/app/pages/home/home.component.ts` - Added booking modal logic
- `frontend/src/app/pages/home/home.component.html` - Added booking modal UI
- `frontend/src/app/pages/home/home.component.scss` - Added modal and button styles
- `frontend/src/app/app.routes.ts` - Added My Bookings route

### Existing (Already Had)
- `frontend/src/app/components/navbar/navbar.component.html` - Already had My Bookings link

## Notes
- The application uses reactive forms for validation
- All API calls are proxied through `/api` to avoid CORS issues
- Reference numbers are generated by the backend
- Check-in assigns seats automatically
- Once checked in, bookings cannot be checked in again




