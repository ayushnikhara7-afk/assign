import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { BookingService } from '../../services/booking.service';

@Component({
  selector: 'app-checkin',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, NavbarComponent],
  templateUrl: './checkin.component.html',
  styleUrl: './checkin.component.scss'
})
export class CheckinComponent {
  private fb = inject(FormBuilder);
  private bookingService = inject(BookingService);

  searchForm = this.fb.nonNullable.group({
    bookingReference: ['', [Validators.required]]
  });

  booking: any = null;
  searching = false;
  searchError = '';
  
  checkingIn = false;
  checkinError = '';
  checkinSuccess = '';

  searchBooking(): void {
    if (this.searchForm.invalid) {
      this.searchForm.markAllAsTouched();
      return;
    }

    this.searching = true;
    this.searchError = '';
    this.booking = null;

    const { bookingReference } = this.searchForm.getRawValue();

    this.bookingService.searchBooking({ bookingReference }).subscribe({
      next: (response: any) => {
        this.booking = response.booking;
        this.searching = false;
      },
      error: (err: any) => {
        this.searching = false;
        this.searchError = err?.error?.message || 'Booking not found. Please check your reference number.';
      }
    });
  }

  performCheckin(): void {
    if (!this.booking) return;

    this.checkingIn = true;
    this.checkinError = '';
    this.checkinSuccess = '';

    const bookingReference = this.searchForm.getRawValue().bookingReference;

    this.bookingService.performCheckin({ bookingReference }).subscribe({
      next: (response: any) => {
        this.checkingIn = false;
        this.checkinSuccess = response.message;
        
        // Refresh the booking to show updated status
        setTimeout(() => {
          this.searchBooking();
        }, 2000);
      },
      error: (err: any) => {
        this.checkingIn = false;
        this.checkinError = err?.error?.message || 'Check-in failed. Please try again.';
      }
    });
  }

  cancelBooking(): void {
    if (!this.booking || !confirm('Are you sure you want to cancel this booking?')) {
      return;
    }

    const bookingReference = this.searchForm.getRawValue().bookingReference;

    this.bookingService.cancelBooking(bookingReference).subscribe({
      next: () => {
        alert('Booking cancelled successfully');
        this.booking = null;
        this.searchForm.reset();
      },
      error: (err: any) => {
        alert(err?.error?.message || 'Failed to cancel booking');
      }
    });
  }
}

