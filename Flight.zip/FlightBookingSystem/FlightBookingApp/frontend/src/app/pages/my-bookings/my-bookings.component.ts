import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { NavbarComponent } from '../../components/navbar/navbar.component';
import { BookingService, Booking } from '../../services/booking.service';

@Component({
  selector: 'app-my-bookings',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, NavbarComponent],
  templateUrl: './my-bookings.component.html',
  styleUrl: './my-bookings.component.scss'
})
export class MyBookingsComponent {
  private fb = inject(FormBuilder);
  private bookingService = inject(BookingService);

  searchForm = this.fb.nonNullable.group({
    bookingReference: ['', [Validators.required]]
  });

  paymentForm = this.fb.nonNullable.group({
    cardNumber: ['', [Validators.required, Validators.pattern(/^\d{16}$/)]],
    cardHolderName: ['', [Validators.required]],
    expiryDate: ['', [Validators.required, Validators.pattern(/^(0[1-9]|1[0-2])\/\d{2}$/)]],
    cvv: ['', [Validators.required, Validators.pattern(/^\d{3,4}$/)]]
  });

  booking: Booking | null = null;
  searching = false;
  searchError = '';
  
  showPaymentModal = false;
  processingPayment = false;
  paymentError = '';
  paymentSuccess = '';

  searchBooking(): void {
    if (this.searchForm.invalid) {
      this.searchForm.markAllAsTouched();
      return;
    }

    this.searching = true;
    this.searchError = '';
    this.booking = null;

    const { bookingReference } = this.searchForm.getRawValue();

    this.bookingService.searchBooking({ bookingReference }).subscribe({
      next: (response: any) => {
        this.booking = response.booking;
        this.searching = false;
      },
      error: (err: any) => {
        this.searching = false;
        this.searchError = err?.error?.message || 'Booking not found. Please check your reference number.';
      }
    });
  }

  openPaymentModal(): void {
    this.showPaymentModal = true;
    this.paymentForm.reset();
    this.paymentError = '';
    this.paymentSuccess = '';
  }

  closePaymentModal(): void {
    this.showPaymentModal = false;
    this.paymentError = '';
    this.paymentSuccess = '';
  }

  processPayment(): void {
    if (this.paymentForm.invalid || !this.booking) {
      this.paymentForm.markAllAsTouched();
      return;
    }

    this.processingPayment = true;
    this.paymentError = '';
    this.paymentSuccess = '';

    const paymentData = this.paymentForm.getRawValue();

    this.bookingService.processPayment(this.booking.referenceNumber, paymentData).subscribe({
      next: (response: any) => {
        this.processingPayment = false;
        this.paymentSuccess = response.message;
        
        setTimeout(() => {
          this.closePaymentModal();
          alert('Payment successful!');
        }, 1500);
      },
      error: (err: any) => {
        this.processingPayment = false;
        this.paymentError = err?.error?.message || 'Payment processing failed. Please try again.';
      }
    });
  }

  cancelBooking(): void {
    if (!this.booking || !confirm('Are you sure you want to cancel this booking?')) {
      return;
    }

    this.bookingService.cancelBooking(this.booking.referenceNumber).subscribe({
      next: () => {
        alert('Booking cancelled successfully');
        this.booking = null;
        this.searchForm.reset();
      },
      error: (err: any) => {
        alert(err?.error?.message || 'Failed to cancel booking');
      }
    });
  }
}
