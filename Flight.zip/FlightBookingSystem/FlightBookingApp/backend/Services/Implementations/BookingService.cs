using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Repository.Interfaces;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Services.Implementations
{
    public class BookingService : IBookingService
    {
        private readonly IBookingRepository _bookingRepo;
        private readonly IFlightRepository _flightRepo;
        private readonly IEmailService _emailService;
        private readonly ILogger<BookingService> _logger;
        
        public BookingService(
            IBookingRepository bookingRepo, 
            IFlightRepository flightRepo,
            IEmailService emailService,
            ILogger<BookingService> logger)
        {
            _bookingRepo = bookingRepo;
            _flightRepo = flightRepo;
            _emailService = emailService;
            _logger = logger;
        }

        public Booking CreateBooking(BookingRequest request)
        {
            var flight = _flightRepo.GetById(request.FlightId);
            if (flight == null)
            {
                throw new ArgumentException("Flight not found");
            }

            // Validate flight date - check if flight date has already passed
            var currentDate = DateTime.UtcNow.Date;
            if (flight.Date.Date < currentDate)
            {
                throw new ArgumentException($"Cannot book flight {flight.FlightNumber} as the flight date ({flight.Date:yyyy-MM-dd}) has already passed. Flight date must be today or in the future.");
            }

            var referenceNumber = Guid.NewGuid().ToString().Substring(0, 8).ToUpper();

            var booking = new Booking
            {
                ReferenceNumber = referenceNumber,
                FlightId = request.FlightId,
                FirstName = request.FirstName,
                LastName = request.LastName,
                Gender = request.Gender,
                BookingDate = DateTime.UtcNow
            };

            var createdBooking = _bookingRepo.Add(booking);
            
            // Send booking confirmation email asynchronously
            // Note: In production, you would get the email from the authenticated user
            // For now, we'll use a placeholder or skip if no email available
            try
            {
                var passengerName = $"{request.FirstName} {request.LastName}";
                // Uncomment the line below and provide actual email when available
                // _ = _emailService.SendBookingConfirmationAsync("passenger@email.com", passengerName, referenceNumber, flight.FlightNumber, flight.From, flight.To, flight.Date);
                _logger.LogInformation($"Booking confirmation email would be sent for booking {referenceNumber}");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to send booking confirmation email: {ex.Message}");
            }

            return createdBooking;
        }

        public Booking? GetBookingByReference(string referenceNumber)
        {
            return _bookingRepo.GetByReferenceNumber(referenceNumber);
        }

        public bool CancelBooking(string referenceNumber)
        {
            return _bookingRepo.CancelBooking(referenceNumber);
        }

        public bool ProcessPayment(string referenceNumber, PaymentRequest paymentRequest)
        {
            var booking = _bookingRepo.GetBookingWithFlight(referenceNumber);
            if (booking == null)
                return false;

            // Simulate payment processing
            // In a real application, you would integrate with a payment gateway
            // For now, we'll just validate the payment details and return success
            
            if (string.IsNullOrEmpty(paymentRequest.CardNumber) || 
                string.IsNullOrEmpty(paymentRequest.CardHolderName) ||
                string.IsNullOrEmpty(paymentRequest.ExpiryDate) ||
                string.IsNullOrEmpty(paymentRequest.CVV))
            {
                return false;
            }

            // Simulate payment success
            return true;
        }
    }
}

