using System.ComponentModel.DataAnnotations;
using FlightBookingApp.Models.Validation;

namespace FlightBookingApp.Models.DTOs
{
    public class ResetPasswordRequest
    {
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address")]
        public string Email { get; set; } = string.Empty;
        
        [Required(ErrorMessage = "New password is required")]
        [PasswordValidation(MinLength = 8, ErrorMessage = "Password must be at least 8 characters long and contain uppercase, lowercase, digit, and special character")]
        public string NewPassword { get; set; } = string.Empty;
    }
}
