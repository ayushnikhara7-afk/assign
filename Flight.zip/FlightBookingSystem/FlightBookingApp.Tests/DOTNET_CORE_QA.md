**Here's a simplified 2-line explanation for each concept to help you confidently answer interview questions.**

---

### ASP.NET Core & Web Concepts
- **Dependency Injection before .NET Core**: Manual setup using constructor injection or third-party libraries.  
  **In .NET Core**: Built-in DI container via `Startup.cs` makes it easier and cleaner.

- **Startup Class in .NET Core**: It configures services and middleware for the app.  
  Acts like the entry point for application setup.

- **Create .NET Core Project without Visual Studio**: Use `dotnet new mvc` in terminal.  
  Requires .NET SDK installed on your machine.

- **Attribute Routing in WebAPI**: Define routes directly on controller methods using `[Route]`.  
  Gives more control than conventional routing.

- **MVC WebAPI**: Combines MVC structure with API endpoints.  
  Used to build RESTful services using controllers.

- **State Management in MVC**:  
  - *Server-side*: Session, TempData, ViewData.  
  - *Client-side*: Cookies, Query Strings, Local Storage.

- **Normalization**: Organizing database to reduce redundancy.  
  Ensures data integrity and efficient storage.

- **Inline vs Stored Procedure**:  
  - *Inline*: SQL written directly in code.  
  - *Stored Procedure*: Predefined SQL stored in DB for reuse and security.

- **Stored Procedure Test Cases**: Validate input/output, logic, and performance.  
  Ensures stored procedures behave as expected.

- **Test Cases Available**: Unit, Integration, Functional, Regression.  
  Each checks different aspects of application behavior.

- **Automated Testing & MSTest**: Runs tests automatically using tools like MSTest.  
  Helps catch bugs early and improve code quality.

- **Action Filters**: Run code before/after controller actions.  
  Types: Authorization, Result, Exception, Resource filters.

- **Error Handling in MVC**: Use `try-catch`, `HandleError` attribute, or custom middleware.  
  Ensures graceful failure and logging.

- **Authentication vs Authorization**:  
  - *Authentication*: Verifies identity.  
  - *Authorization*: Checks access rights.

- **Virtual vs New Keyword**:  
  - *Virtual*: Allows method override in derived class.  
  - *New*: Hides base class method.

- **Dispose DbContext**: Dispose in `using` block or override `Dispose()` method.  
  Frees up database connections.

- **Unmanaged Resources Example**: File handles, database connections, network sockets.  
  Need manual cleanup using `Dispose()`.

- **AppDomain**: Isolated environment for running .NET applications.  
  Helps manage memory and security.

- **HTTP Protocol**: Stateless, meaning it doesn’t remember previous requests.  
  Each request is independent.

- **ASP.NET MVC Core**: Modern, cross-platform framework for web apps and APIs.  
  Faster, modular, and cloud-ready.

- **ASP.NET MVC vs MVC Core**:  
  - *MVC*: Windows-only, older.  
  - *MVC Core*: Cross-platform, lightweight, better performance.

- **wwwroot Folder**: Stores static files like CSS, JS, images.  
  Publicly accessible by the browser.

- **Web API**: Interface for apps to communicate over HTTP.  
  Used to expose data and services.

- **REST Service**: Follows HTTP methods like GET, POST, PUT, DELETE.  
  Stateless and resource-based.

- **Startup Class Role**: Configures services and middleware.  
  Controls app behavior during startup.

- **Why Dependency Injection**: Reduces tight coupling and improves testability.  
  Makes code cleaner and maintainable.

- **Implement DI**: Register services in `ConfigureServices`, inject via constructor.  
  Uses built-in container.

- **Request Pipeline**: Series of middleware handling HTTP requests.  
  Each can process or pass the request further.

- **app.Run vs app.Use**:  
  - *Run*: Terminal middleware, ends pipeline.  
  - *Use*: Can call next middleware.

- **DI Problems Solved**: Avoids hard-coded dependencies.  
  Supports testing and flexibility.

- **Service Lifetimes**:  
  - *Transient*: New instance every time.  
  - *Scoped*: One per request.  
  - *Singleton*: One for entire app.

- **appsettings.json Importance**: Stores configuration like connection strings.  
  Easy to manage and change settings.

- **Read Configurations**: Use `IConfiguration` or bind to classes.  
  Access via constructor injection.

- **Middleware Use**: Handles requests/responses like logging, auth.  
  Forms the request pipeline.

- **Create Middleware**: Create a class with `Invoke` method.  
  Register using `app.UseMiddleware`.

- **Startup.cs File**: Configures services and middleware.  
  Central setup for the app.

- **ConfigureServices vs Configure**:  
  - *ConfigureServices*: Register services.  
  - *Configure*: Set up middleware.

- **Ways of DI**: Constructor, Property, Method Injection.  
  Constructor is most common.

- **Request Delegate**: Represents a method to handle HTTP request.  
  Used in middleware.

- **Host in ASP.NET Core**: Manages app lifecycle and services.  
  Created using `CreateHostBuilder`.

- **Servers in ASP.NET Core**: Kestrel, IIS, HTTP.sys.  
  Handle HTTP requests.

- **Kestrel Web Server**: Lightweight, cross-platform server.  
  Default in ASP.NET Core.

- **Why Kestrel with IIS**: IIS acts as reverse proxy.  
  Adds security and features.

- **Reverse Proxy Concept**: Forwards client requests to backend server.  
  Used for load balancing and security.

- **Configuration in ASP.NET Core**: Uses providers like JSON, Env Vars.  
  Access via `IConfiguration`.

- **Options Pattern**: Binds config to classes.  
  Helps manage grouped settings.

- **Routing in ASP.NET Core**: Maps URLs to actions.  
  Uses conventional or attribute routing.

- **Error Handling in ASP.NET Core**: Use `UseExceptionHandler`, logging.  
  Shows friendly error pages.

- **Serve Static Files**: Use `UseStaticFiles()` middleware.  
  Files from `wwwroot` folder.

- **Need for Session Management**: Store user data across requests.  
  Helps maintain user state.

- **Session Management Ways**: Cookies, Session, TempData, Query Strings.  
  Each has different scope and storage.

- **What is a Session**: Temporary storage for user data.  
  Lives across multiple requests.

- **HTTP is Stateless**: Doesn’t remember previous interactions.  
  Needs session/cookies to track users.

- **Enable Sessions in MVC Core**: Add `services.AddSession()` and `app.UseSession()`.  
  Configure in `Startup.cs`.

- **Session Variables Shared?**: No, each user has separate session.  
  Not global.

- **Session Uses Cookies?**: Yes, to track session ID.  
  Stored on client browser.

- **What is a Cookie**: Small data stored in browser.  
  Used for tracking and personalization.

- **Idle Timeout in Sessions**: Time after which inactive session ends.  
  Can be configured.

- **HTTP Context**: Holds info about request, response, user.  
  Available during request lifecycle.

- **Model Binding**: Maps form data to model properties.  
  Happens automatically.

- **Custom Model Binding**: Create your own logic to bind data.  
  Useful for complex types.

- **Model Validation**: Checks if model data is correct.  
  Uses attributes like `[Required]`.

- **Custom Middleware**: Create class with `Invoke` method.  
  Register in pipeline.

- **Access HttpContext**: Use `IHttpContextAccessor`.  
  Inject and use in services.

- **Change Token**: Detects config changes at runtime.  
  Used for reloadable settings.

- **Use ASP.NET Core APIs in Class Library**: Reference ASP.NET Core packages.  
  Inject services via DI.

- **OWIN**: Interface between web server and app.  
  Allows decoupling.

- **URL Rewriting Middleware**: Changes incoming URLs.  
  Useful for SEO and redirects.

- **Application Model**: Metadata about controllers/actions.  
  Used for routing and filters.

- **Caching in ASP.NET Core**: Stores data to improve performance.  
  Types: In-memory, distributed, response caching.

- **In-memory Cache**: Stores data in server memory.  
  Fast but not shared across servers.

- **Middleware Sequence**: Order matters, runs top to bottom.  
  First registered = first executed.

- **Buffering vs Streaming File Upload**:  
  - *Buffering*: Loads entire file in memory.  
  - *Streaming*: Reads file in chunks.

- **Bundling & Minification**: Combines and compresses files.  
  Improves load time.

- **Attribute Routing**: Use `[Route]` on actions.  
  Customizes URL paths.

- **Cache Tag Helper**: Caches part of Razor view.  
  Improves performance.

- **Validation in MVC & DRY**: Uses attributes to avoid repeating logic.  
  Keeps code clean and reusable.

- **.NET Core vs .NET Framework**:  
  - *Core*: Cross-platform, modern.  
  - *Framework*: Windows-only, legacy.

- **AddTransient vs AddScoped**:  
  - *Transient*: New every time.  
  - *Scoped*: One per request.

- **WebHost.CreateDefaultBuilder()**: Sets up default host config.
