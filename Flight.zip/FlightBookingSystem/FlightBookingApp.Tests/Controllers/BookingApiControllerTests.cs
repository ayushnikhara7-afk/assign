using NUnit.Framework;
using Moq;
using Microsoft.AspNetCore.Mvc;
using FlightBookingApp.Controllers;
using FlightBookingApp.Services.Interfaces;
using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;

namespace FlightBookingApp.Tests.Controllers
{
    /// <summary>
    /// Unit tests for BookingApiController - 3 Essential Tests
    /// </summary>
    [TestFixture]
    public class BookingApiControllerTests
    {
        private Mock<IFlightService> _mockFlightService;
        private Mock<IBookingService> _mockBookingService;
        private BookingApiController _controller;

        [SetUp]
        public void Setup()
        {
            _mockFlightService = new Mock<IFlightService>();
            _mockBookingService = new Mock<IBookingService>();
            _controller = new BookingApiController(_mockFlightService.Object, _mockBookingService.Object);
        }

        [Test]
        public void SearchFlights_WithValidRequest_ReturnsOkWithFlightList()
        {
            // Arrange
            var request = new SearchRequest
            {
                From = "NYC",
                To = "LAX",
                Date = DateTime.Now.AddDays(7)
            };

            var expectedFlights = new List<Flight>
            {
                new Flight { Id = 1, FlightNumber = "FL001", From = "NYC", To = "LAX", Date = request.Date, Fare = 299.99m },
                new Flight { Id = 2, FlightNumber = "FL002", From = "NYC", To = "LAX", Date = request.Date, Fare = 349.99m }
            };

            _mockFlightService.Setup(s => s.SearchFlights(request.From, request.To, request.Date)).Returns(expectedFlights);

            // Act
            var result = _controller.SearchFlights(request);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var okResult = result as OkObjectResult;
            var flights = okResult!.Value as List<Flight>;
            Assert.That(flights, Is.Not.Null);
            Assert.That(flights!.Count, Is.EqualTo(2));
        }

        [Test]
        public void SearchFlights_WithNoResults_ReturnsOkWithEmptyList()
        {
            // Arrange
            var request = new SearchRequest { From = "NYC", To = "MARS", Date = DateTime.Now.AddDays(7) };
            _mockFlightService.Setup(s => s.SearchFlights(request.From, request.To, request.Date)).Returns(new List<Flight>());

            // Act
            var result = _controller.SearchFlights(request);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var okResult = result as OkObjectResult;
            var flights = okResult!.Value as List<Flight>;
            Assert.That(flights!.Count, Is.EqualTo(0));
        }

        [Test]
        public void CreateBooking_WithValidRequest_ReturnsOkWithBooking()
        {
            // Arrange
            var request = new BookingRequest
            {
                FlightId = 1,
                FirstName = "John",
                LastName = "Doe",
                Gender = "M"
            };

            var expectedBooking = new Booking
            {
                Id = 1,
                ReferenceNumber = "ABC123",
                FlightId = 1,
                FirstName = "John",
                LastName = "Doe",
                Gender = "M",
                BookingDate = DateTime.UtcNow
            };

            _mockBookingService.Setup(s => s.CreateBooking(It.IsAny<BookingRequest>())).Returns(expectedBooking);

            // Act
            var result = _controller.CreateBooking(request);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            var okResult = result as OkObjectResult;
            var booking = okResult!.Value as Booking;
            Assert.That(booking, Is.Not.Null);
            Assert.That(booking!.ReferenceNumber, Is.EqualTo("ABC123"));
            Assert.That(booking.FirstName, Is.EqualTo("John"));
        }

        [TearDown]
        public void TearDown()
        {
            _controller = null!;
            _mockFlightService = null!;
            _mockBookingService = null!;
        }
    }
}

