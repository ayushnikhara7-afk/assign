using NUnit.Framework;
using Moq;
using Microsoft.AspNetCore.Mvc;
using FlightBookingApp.Controllers;
using FlightBookingApp.Services.Interfaces;
using FlightBookingApp.Models.DTOs;

namespace FlightBookingApp.Tests.Controllers
{
    /// <summary>
    /// Unit tests for CheckinController - 3 Essential Tests
    /// </summary>
    [TestFixture]
    public class CheckinControllerTests
    {
        private Mock<ICheckinService> _mockCheckinService;
        private CheckinController _controller;

        [SetUp]
        public void Setup()
        {
            _mockCheckinService = new Mock<ICheckinService>();
            _controller = new CheckinController(_mockCheckinService.Object);
        }

        [Test]
        public void SearchBooking_WithValidReference_ReturnsOkWithBooking()
        {
            // Arrange
            var request = new BookingSearchRequest { BookingReference = "ABC123" };
            var expectedResponse = new BookingSearchResponse
            {
                BookingId = 1,
                BookingReference = "ABC123",
                PassengerName = "John Doe",
                FlightNumber = "FL001",
                From = "NYC",
                To = "LAX",
                FlightDate = DateTime.Now.AddDays(7),
                Gender = "M",
                IsCheckedIn = false
            };

            _mockCheckinService.Setup(s => s.SearchBooking("ABC123")).Returns(expectedResponse);

            // Act
            var result = _controller.SearchBooking(request);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            _mockCheckinService.Verify(s => s.SearchBooking("ABC123"), Times.Once);
        }

        [Test]
        public void SearchBooking_WithInvalidReference_ReturnsNotFound()
        {
            // Arrange
            var request = new BookingSearchRequest { BookingReference = "INVALID" };
            _mockCheckinService.Setup(s => s.SearchBooking("INVALID")).Returns((BookingSearchResponse?)null);

            // Act
            var result = _controller.SearchBooking(request);

            // Assert
            Assert.That(result, Is.InstanceOf<NotFoundObjectResult>());
            var notFoundResult = result as NotFoundObjectResult;
            Assert.That(notFoundResult, Is.Not.Null);
        }

        [Test]
        public void PerformCheckin_WithValidReference_ReturnsOkWithCheckinDetails()
        {
            // Arrange
            var request = new CheckinRequest { BookingReference = "ABC123" };
            var expectedResponse = new CheckinResponse
            {
                CheckinId = 1,
                BookingReference = "ABC123",
                PassengerName = "John Doe",
                FlightNumber = "FL001",
                SeatNumber = "12A",
                CheckinDate = DateTime.UtcNow,
                Message = "Check-in successful"
            };

            _mockCheckinService.Setup(s => s.PerformCheckin("ABC123")).Returns(expectedResponse);

            // Act
            var result = _controller.PerformCheckin(request);

            // Assert
            Assert.That(result, Is.InstanceOf<OkObjectResult>());
            _mockCheckinService.Verify(s => s.PerformCheckin("ABC123"), Times.Once);
        }

        [TearDown]
        public void TearDown()
        {
            _controller = null!;
            _mockCheckinService = null!;
        }
    }
}

