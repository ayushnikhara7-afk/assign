using Microsoft.EntityFrameworkCore;
using RetailManagementAPI.Data;
using RetailManagementAPI.Interfaces;
using RetailManagementAPI.Models;

namespace RetailManagementAPI.Repositories
{
    public class ProductRepository : IProduct
    {
        private readonly RetailContext _context;

        public ProductRepository(RetailContext context)
        {
            _context = context;
        }

        public async Task<bool> AddProduct(Product product)
        {
            var existingProduct = await _context.Products.FindAsync(product.Id);
            if (existingProduct != null)
            {
                return false;
            }

            await _context.Products.AddAsync(product);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> UpdateProductPrice(int id, decimal price)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return false;
            }

            product.Price = price;
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteProduct(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product == null)
            {
                return false;
            }

            _context.Products.Remove(product);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<Product> GetProductWithHighestOrderQuantity()
        {
            var productId = await _context.Products
                .Select(p => new
                {
                    ProductId = p.Id,
                    TotalQuantity = p.OrderItems.Sum(oi => oi.Quantity)
                })
                .OrderByDescending(x => x.TotalQuantity)
                .Select(x => x.ProductId)
                .FirstOrDefaultAsync();

            if (productId == 0)
            {
                return null;
            }

            var product = await _context.Products
                .Include(p => p.OrderItems)
                .FirstOrDefaultAsync(p => p.Id == productId);

            return product;
        }
    }
}

