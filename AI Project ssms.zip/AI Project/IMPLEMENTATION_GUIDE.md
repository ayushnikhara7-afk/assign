# Implementation Guide

This guide provides detailed instructions for completing the OCR integration with PaddleOCR ONNX models.

## Overview

The system is structured with placeholder implementations for the OCR processing pipeline. To make it fully functional, you need to:

1. Obtain PaddleOCR ONNX models
2. Implement proper detection output parsing
3. Implement proper recognition output decoding
4. Optionally improve PDF rendering

## Step 1: Obtain PaddleOCR ONNX Models

### Option A: Download Pre-converted Models

1. Check PaddleOCR releases for ONNX models
2. Or use community-converted models from GitHub
3. Place `det.onnx` and `rec.onnx` in `Backend/Models/`

### Option B: Convert from PaddleOCR Python Models

If you have Python available (for one-time conversion):

```python
# Install paddle2onnx
pip install paddle2onnx

# Convert detection model
paddle2onnx --model_dir ./inference/det \
            --model_filename inference.pdmodel \
            --params_filename inference.pdiparams \
            --save_file ./det.onnx \
            --opset_version 11

# Convert recognition model
paddle2onnx --model_dir ./inference/rec \
            --model_filename inference.pdmodel \
            --params_filename inference.pdiparams \
            --save_file ./rec.onnx \
            --opset_version 11
```

## Step 2: Implement Detection Output Parsing

The current `ExtractBoundingBoxes` method in `OcrService.cs` is a placeholder. You need to:

1. **Understand PaddleOCR Detection Output:**
   - PaddleOCR detection models output a probability map
   - Post-processing involves:
     - Thresholding the probability map
     - Finding connected components
     - Extracting bounding boxes from contours
     - Applying non-maximum suppression

2. **Implement Post-Processing:**

```csharp
private List<BoundingBox> ExtractBoundingBoxes(Tensor<float> detectionOutput, int imageWidth, int imageHeight)
{
    // Get the output tensor dimensions
    // Typically: [1, 1, H, W] for probability map
    
    var boxes = new List<BoundingBox>();
    
    // 1. Threshold the probability map (e.g., threshold = 0.3)
    // 2. Find contours using connected components
    // 3. Get bounding rectangles for each contour
    // 4. Filter by size and aspect ratio
    // 5. Apply NMS if needed
    
    // Example structure:
    var threshold = 0.3f;
    var probabilityMap = detectionOutput; // Shape: [1, 1, H, W]
    
    // Use OpenCV.NET or implement contour finding
    // For each detected text region:
    //   boxes.Add(new BoundingBox { X = x, Y = y, Width = w, Height = h });
    
    return boxes;
}
```

**Recommended Library:** Use `OpenCvSharp` for contour detection and image processing:

```xml
<PackageReference Include="OpenCvSharp4" Version="4.8.0" />
<PackageReference Include="OpenCvSharp4.runtime.win" Version="4.8.0" />
```

## Step 3: Implement Recognition Output Decoding

The current `DecodeRecognitionOutput` method is a placeholder. You need to:

1. **Get PaddleOCR Character Dictionary:**
   - Download `ppocr_keys_v1.txt` from PaddleOCR repository
   - This contains the character mapping (index -> character)

2. **Implement Decoding:**

```csharp
private string DecodeRecognitionOutput(Tensor<float> recognitionOutput)
{
    // Recognition output shape: [1, num_classes, sequence_length]
    // Or: [sequence_length, num_classes]
    
    // Load character dictionary
    var charDict = LoadCharDictionary("ppocr_keys_v1.txt");
    
    // Get sequence length
    var seqLen = recognitionOutput.Dimensions[2]; // Adjust based on actual shape
    
    var text = new StringBuilder();
    
    for (int i = 0; i < seqLen; i++)
    {
        // Find character with max probability
        var maxIdx = 0;
        var maxProb = float.MinValue;
        
        for (int j = 0; j < charDict.Count; j++)
        {
            var prob = recognitionOutput[0, j, i]; // Adjust indices
            if (prob > maxProb)
            {
                maxProb = prob;
                maxIdx = j;
            }
        }
        
        // Skip blank/space characters (usually index 0)
        if (maxIdx > 0 && maxIdx < charDict.Count)
        {
            text.Append(charDict[maxIdx]);
        }
    }
    
    return text.ToString();
}

private List<string> LoadCharDictionary(string path)
{
    // Load from ppocr_keys_v1.txt
    // Format: one character per line
    return File.ReadAllLines(path).ToList();
}
```

## Step 4: Improve PDF Rendering (Optional)

The current PDF rendering is basic. For production:

### Option A: Use SkiaSharp with PdfSharpCore

```xml
<PackageReference Include="PdfSharpCore" Version="1.3.0" />
<PackageReference Include="SkiaSharp" Version="2.88.6" />
```

```csharp
using PdfSharpCore.Pdf;
using PdfSharpCore.Pdf.IO;
using SkiaSharp;

public async Task<List<byte[]>> ConvertPdfToImagesAsync(Stream pdfStream)
{
    var images = new List<byte[]>();
    
    using var document = PdfReader.Open(pdfStream, PdfDocumentOpenMode.ReadOnly);
    
    foreach (var page in document.Pages)
    {
        // Render page using SkiaSharp
        // Convert to image bytes
    }
    
    return images;
}
```

### Option B: Use Ghostscript (External Process)

Call Ghostscript as an external process to convert PDF to images.

## Step 5: Testing

1. **Test with Sample PDF:**
   - Create a simple PDF with text
   - Upload via Angular UI
   - Verify OCR results

2. **Verify Model Loading:**
   - Check console logs for model loading messages
   - Ensure models are in correct format

3. **Debug OCR Pipeline:**
   - Add logging to each step
   - Save intermediate images (detection results, cropped regions)
   - Verify tensor shapes match expected formats

## Additional Resources

- **PaddleOCR Documentation:** https://github.com/PaddlePaddle/PaddleOCR
- **ONNX Runtime C# API:** https://onnxruntime.ai/docs/api/csharp-api
- **PaddleOCR Model Zoo:** Check for pre-trained models and conversion scripts

## Troubleshooting

### Models Not Loading
- Verify model paths in `appsettings.json`
- Check model file permissions
- Ensure models are valid ONNX format

### Incorrect OCR Results
- Verify input image preprocessing matches training
- Check tensor shapes and normalization
- Ensure character dictionary matches model training

### Performance Issues
- Consider model quantization
- Use GPU acceleration if available
- Batch process multiple images

## Notes

- The current implementation provides a complete structure
- Core OCR logic needs to be completed based on PaddleOCR specifications
- All infrastructure (API, frontend, services) is ready
- Focus on completing the detection and recognition parsing logic

