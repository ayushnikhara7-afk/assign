# Frontend Setup Instructions

## Prerequisites

1. Install Node.js 18+ from https://nodejs.org/
2. Install Angular CLI globally:
   ```bash
   npm install -g @angular/cli
   ```

## Setup Steps

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure API URL:**
   
   Update `src/environments/environment.ts` if your backend is running on a different URL:
   ```typescript
   export const environment = {
     production: false,
     apiUrl: 'https://localhost:5001'
   };
   ```

3. **Run the development server:**
   ```bash
   ng serve
   ```
   
   The application will be available at http://localhost:4200

4. **Build for production:**
   ```bash
   ng build --configuration production
   ```

## Features

- Drag and drop PDF upload
- Real-time OCR processing
- Structured data display
- Table visualization
- JSON download

## Troubleshooting

- If you see CORS errors, ensure the backend CORS policy allows `http://localhost:4200`
- If the API is not reachable, check the `apiUrl` in `environment.ts`

