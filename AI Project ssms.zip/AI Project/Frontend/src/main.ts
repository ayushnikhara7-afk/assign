import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter, Routes, CanActivateFn, Router } from '@angular/router';
import { inject } from '@angular/core';
import { AuthService } from './app/services/auth.service';

const authGuard: CanActivateFn = (route, state) => {
  const authService = inject(AuthService);
  const router = inject(Router);
  
  if (authService.isAuthenticated()) {
    return true;
  }
  
  router.navigate(['/login']);
  return false;
};

const routes: Routes = [
  { 
    path: '', 
    component: AppComponent,
    canActivate: [authGuard]
  },
  { 
    path: 'login', 
    loadComponent: () => import('./app/components/login/login.component').then(m => m.LoginComponent)
  },
  {
    path: 'history',
    loadComponent: () => import('./app/components/history/history.component').then(m => m.HistoryComponent),
    canActivate: [authGuard]
  },
  { 
    path: '**', 
    redirectTo: '' 
  }
];

bootstrapApplication(AppComponent, {
  providers: [
    provideHttpClient(),
    provideRouter(routes)
  ]
}).catch(err => console.error(err));
