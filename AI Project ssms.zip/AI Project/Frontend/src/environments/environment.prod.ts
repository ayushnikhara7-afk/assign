export const environment = {
  production: true,
  apiUrl: 'https://localhost:5001'
};

