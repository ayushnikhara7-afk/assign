import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { ExtractedData } from '../models/extracted-data.model';
import { AuthService } from './auth.service';

export interface HistoryItem {
  id: number;
  fileName: string;
  fileSize: number;
  documentType: string;
  extractedAt: string;
  extractedData: ExtractedData;
  rawText?: string;
}

export interface HistoryResponse {
  data: HistoryItem[];
  page: number;
  pageSize: number;
}

@Injectable({
  providedIn: 'root'
})
export class HistoryService {
  private apiUrl = environment.apiUrl;

  constructor(
    private http: HttpClient,
    private authService: AuthService
  ) {}

  private getHeaders(): HttpHeaders {
    const token = this.authService.getToken();
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  getHistory(page: number = 1, pageSize: number = 20): Observable<HistoryResponse> {
    return this.http.get<HistoryResponse>(
      `${this.apiUrl}/api/history?page=${page}&pageSize=${pageSize}`,
      { headers: this.getHeaders() }
    );
  }

  getHistoryById(id: number): Observable<HistoryItem> {
    return this.http.get<HistoryItem>(
      `${this.apiUrl}/api/history/${id}`,
      { headers: this.getHeaders() }
    );
  }

  deleteHistory(id: number): Observable<any> {
    return this.http.delete(
      `${this.apiUrl}/api/history/${id}`,
      { headers: this.getHeaders() }
    );
  }
}

