import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  isLoginMode = true;
  username = '';
  email = '';
  password = '';
  error: string | null = null;
  isLoading = false;

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  toggleMode(): void {
    this.isLoginMode = !this.isLoginMode;
    this.error = null;
    this.username = '';
    this.email = '';
    this.password = '';
  }

  onSubmit(): void {
    this.error = null;
    this.isLoading = true;

    if (this.isLoginMode) {
      this.authService.login({
        username: this.username,
        password: this.password
      }).subscribe({
        next: () => {
          this.router.navigate(['/']);
        },
        error: (err) => {
          this.error = err.error?.error || 'Login failed';
          this.isLoading = false;
        }
      });
    } else {
      this.authService.register({
        username: this.username,
        email: this.email,
        password: this.password
      }).subscribe({
        next: () => {
          this.router.navigate(['/']);
        },
        error: (err) => {
          this.error = err.error?.error || 'Registration failed';
          this.isLoading = false;
        }
      });
    }
  }
}

