import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HistoryService, HistoryItem } from '../../services/history.service';

@Component({
  selector: 'app-history',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './history.component.html',
  styleUrl: './history.component.css'
})
export class HistoryComponent implements OnInit {
  history: HistoryItem[] = [];
  isLoading = false;
  error: string | null = null;
  currentPage = 1;
  pageSize = 20;
  hasMore = false;

  constructor(private historyService: HistoryService) {}

  ngOnInit(): void {
    this.loadHistory();
  }

  loadHistory(): void {
    this.isLoading = true;
    this.error = null;

    this.historyService.getHistory(this.currentPage, this.pageSize).subscribe({
      next: (response) => {
        this.history = response.data;
        this.hasMore = response.data.length === this.pageSize;
        this.isLoading = false;
      },
      error: (err) => {
        this.error = err.error?.error || 'Failed to load history';
        this.isLoading = false;
      }
    });
  }

  loadMore(): void {
    this.currentPage++;
    this.loadHistory();
  }

  deleteItem(id: number): void {
    if (!confirm('Are you sure you want to delete this history item?')) {
      return;
    }

    this.historyService.deleteHistory(id).subscribe({
      next: () => {
        this.history = this.history.filter(h => h.id !== id);
      },
      error: (err) => {
        alert(err.error?.error || 'Failed to delete history item');
      }
    });
  }

  formatDate(dateString: string): string {
    return new Date(dateString).toLocaleString();
  }

  formatFileSize(bytes: number): string {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(2) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  }

  getFieldKeys(data: any): string[] {
    return data?.fields ? Object.keys(data.fields).slice(0, 5) : [];
  }

  getFieldValue(data: any, key: string): string {
    const value = data?.fields?.[key];
    if (Array.isArray(value)) {
      return value.join(', ');
    }
    if (typeof value === 'object' && value !== null) {
      return JSON.stringify(value);
    }
    return String(value || 'N/A');
  }

  formatLabel(key: string): string {
    return key
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, str => str.toUpperCase())
      .trim();
  }
}

