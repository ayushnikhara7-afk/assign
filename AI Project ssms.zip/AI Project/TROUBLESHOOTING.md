# Troubleshooting Guide

## Connection Refused Error

If you're getting `ERR_CONNECTION_REFUSED` or connection errors:

### 1. Verify Backend is Running

Make sure the backend API is running:
```bash
cd Backend
dotnet run
```

You should see output like:
```
info: Microsoft.Hosting.Lifetime[14]
      Now listening on: http://localhost:5000
      Now listening on: https://localhost:5001
```

### 2. Check API URL Configuration

The frontend is configured to use `http://localhost:5000` in development.

If your backend is running on a different port, update:
- `Frontend/src/environments/environment.ts` - Change `apiUrl` to match your backend

### 3. CORS Issues

If you see CORS errors in the browser console:

1. Verify the backend CORS policy in `Backend/Program.cs` allows `http://localhost:4200`
2. Make sure `app.UseCors("AllowAngularApp")` is called before `app.UseAuthorization()`

### 4. HTTPS Certificate Issues

If using HTTPS and getting certificate errors:

**Option A: Use HTTP for Development (Recommended)**
- Frontend: `http://localhost:4200`
- Backend: `http://localhost:5000`
- Update `Frontend/src/environments/environment.ts` to use `http://localhost:5000`

**Option B: Trust Development Certificate**
```bash
# Windows
dotnet dev-certs https --trust

# macOS/Linux
dotnet dev-certs https --trust
```

### 5. Port Conflicts

If ports 5000 or 5001 are already in use:

1. Update `Backend/Properties/launchSettings.json` to use different ports
2. Update `Frontend/src/environments/environment.ts` to match

### 6. Firewall/Antivirus

Some firewalls or antivirus software may block localhost connections. Temporarily disable to test.

## Common Issues

### Backend Not Starting

- Check for build errors: `dotnet build`
- Verify all NuGet packages are restored: `dotnet restore`
- Check if port is already in use

### Frontend Not Connecting

- Open browser DevTools (F12) → Network tab
- Check if requests are being sent
- Look for CORS errors in Console tab
- Verify API URL in environment.ts

### PDF Upload Fails

- Check file size (max 100MB configured)
- Verify file is actually a PDF
- Check backend logs for errors
- Verify PDF to image conversion is working

## Testing the Connection

1. **Test Backend Health Endpoint:**
   ```
   http://localhost:5000/api/ocr/health
   ```
   Should return: `{"status":"healthy","timestamp":"..."}`

2. **Test with Swagger:**
   ```
   http://localhost:5000/swagger
   ```
   Try the `/api/ocr/extract` endpoint directly

3. **Check Browser Console:**
   - Open DevTools (F12)
   - Check Console for errors
   - Check Network tab for failed requests

## Still Having Issues?

1. Check backend console output for error messages
2. Check browser console for detailed error messages
3. Verify both frontend and backend are running
4. Try accessing the backend directly in browser: `http://localhost:5000/swagger`

