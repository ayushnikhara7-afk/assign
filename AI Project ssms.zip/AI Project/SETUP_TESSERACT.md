# Tesseract OCR Setup Guide

## Quick Setup

### Windows

1. **Download and Install Tesseract:**
   - Visit: https://github.com/UB-Mannheim/tesseract/wiki
   - Download the Windows installer
   - Install Tesseract (default: `C:\Program Files\Tesseract-OCR`)

2. **Copy tessdata folder:**
   ```powershell
   # Copy tessdata from installation to project
   Copy-Item "C:\Program Files\Tesseract-OCR\tessdata" -Destination "Backend\tessdata" -Recurse
   ```

3. **Or configure path in appsettings.json:**
   ```json
   {
     "Ocr": {
       "TessdataPath": "C:\\Program Files\\Tesseract-OCR\\tessdata"
     }
   }
   ```

### macOS

```bash
# Install Tesseract
brew install tesseract

# Copy tessdata (usually in /opt/homebrew/share/tessdata or /usr/local/share/tessdata)
cp -r /opt/homebrew/share/tessdata Backend/tessdata
# OR
cp -r /usr/local/share/tessdata Backend/tessdata
```

### Linux (Ubuntu/Debian)

```bash
# Install Tesseract
sudo apt-get update
sudo apt-get install tesseract-ocr

# Copy tessdata
sudo cp -r /usr/share/tesseract-ocr/*/tessdata Backend/tessdata
```

## Alternative: Download tessdata Only

If you don't want to install full Tesseract:

1. Download `eng.traineddata` from: https://github.com/tesseract-ocr/tessdata
2. Create `Backend/tessdata/` directory
3. Place `eng.traineddata` in that directory

## Verify Installation

After setup, restart the backend. You should see:
```
Tesseract OCR engine initialized successfully.
```

If you see warnings, check:
- Tessdata path in `appsettings.json`
- File permissions
- `eng.traineddata` file exists

## Troubleshooting

### "Tesseract data directory not found"
- Verify the path in `appsettings.json`
- Check that `eng.traineddata` exists in the tessdata folder
- Use absolute path if relative path doesn't work

### "Could not initialize Tesseract OCR"
- Ensure Tesseract is properly installed
- Check native DLL dependencies (Tesseract.NET should handle this)
- Try reinstalling Tesseract

### Low OCR Accuracy
- Use higher resolution images (300+ DPI)
- Ensure good image quality (contrast, brightness)
- Preprocess images if needed (deskew, denoise)

