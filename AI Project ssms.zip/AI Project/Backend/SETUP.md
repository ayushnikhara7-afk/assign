# Backend Setup Instructions

## Prerequisites

1. Install .NET 9 SDK from https://dotnet.microsoft.com/download/dotnet/9.0

## Setup Steps

1. **Restore NuGet packages:**
   ```bash
   dotnet restore
   ```

2. **Download PaddleOCR ONNX Models:**
   
   You need to download the PaddleOCR ONNX models:
   - `det.onnx` - Text detection model
   - `rec.onnx` - Text recognition model
   - `cls.onnx` - Text direction classifier (optional)
   
   Download from:
   - Official PaddleOCR releases: https://github.com/PaddlePaddle/PaddleOCR/releases
   - Or convert from PaddleOCR Python models using the conversion scripts
   
   Place the models in the `Backend/Models/` directory.

3. **Configure Model Path (if needed):**
   
   Update `appsettings.json` if your models are in a different location:
   ```json
   {
     "Ocr": {
       "ModelsPath": "Models"
     }
   }
   ```

4. **Run the API:**
   ```bash
   dotnet run
   ```
   
   The API will be available at:
   - HTTPS: https://localhost:5001
   - HTTP: http://localhost:5000

## API Endpoints

- `POST /api/ocr/extract` - Upload PDF and extract data
- `GET /api/ocr/health` - Health check

## Notes

- The OCR service includes fallback behavior if models are not loaded
- For production, ensure proper PDF rendering library is configured
- Adjust CORS settings in `Program.cs` for production deployment

