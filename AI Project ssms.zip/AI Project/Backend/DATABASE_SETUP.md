# Database Setup Instructions

## Prerequisites

1. **SQL Server** - Install SQL Server Express or use LocalDB
   - Download from: https://www.microsoft.com/en-us/sql-server/sql-server-downloads
   - Or use SQL Server LocalDB (included with Visual Studio)

## Setup Steps

### 1. Update Connection String

Edit `appsettings.json` and update the connection string:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=OcrExtractionDb;Trusted_Connection=True;MultipleActiveResultSets=true"
  }
}
```

**For SQL Server Express:**
```
Server=localhost\\SQLEXPRESS;Database=OcrExtractionDb;Trusted_Connection=True;MultipleActiveResultSets=true
```

**For Remote SQL Server:**
```
Server=your-server-name;Database=OcrExtractionDb;User Id=your-username;Password=your-password;Trusted_Connection=False;
```

### 2. Create Database Migration

Run these commands in the `Backend` directory:

```bash
# Install EF Core tools (if not already installed)
dotnet tool install --global dotnet-ef

# Create initial migration
dotnet ef migrations add InitialCreate

# Apply migration to database
dotnet ef database update
```

### 3. Verify Database

The database `OcrExtractionDb` should be created with:
- **Users** table - Stores user accounts
- **ExtractionHistories** table - Stores extraction history

### 4. Test Connection

Run the backend:
```bash
dotnet run
```

Check the console for any database connection errors.

## Database Schema

### Users Table
- `Id` (int, PK)
- `Username` (nvarchar(100), unique)
- `Email` (nvarchar(255), unique)
- `PasswordHash` (nvarchar)
- `CreatedAt` (datetime)
- `LastLoginAt` (datetime, nullable)
- `IsActive` (bit)

### ExtractionHistories Table
- `Id` (int, PK)
- `UserId` (int, FK to Users)
- `FileName` (nvarchar(255))
- `FileSize` (bigint)
- `DocumentType` (nvarchar(50))
- `ExtractedDataJson` (nvarchar(max))
- `RawText` (nvarchar(max), nullable)
- `ExtractedAt` (datetime)

## Troubleshooting

### Connection String Issues
- Verify SQL Server is running
- Check server name/instance name
- Verify database name doesn't already exist (or use different name)
- Check Windows Authentication or SQL Authentication credentials

### Migration Issues
- Ensure Entity Framework Core tools are installed
- Check that connection string is correct
- Verify SQL Server version compatibility

### Authentication Issues
- Update JWT key in `appsettings.json` for production
- Ensure JWT key is at least 32 characters long

