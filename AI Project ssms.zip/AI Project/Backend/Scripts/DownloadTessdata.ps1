# PowerShell script to download Tesseract tessdata files
# Run this script from the Backend directory

Write-Host "Downloading Tesseract tessdata files..." -ForegroundColor Green

$tessdataDir = Join-Path $PSScriptRoot "..\tessdata"
$tessdataUrl = "https://github.com/tesseract-ocr/tessdata/raw/main/eng.traineddata"

# Create tessdata directory if it doesn't exist
if (-not (Test-Path $tessdataDir)) {
    New-Item -ItemType Directory -Path $tessdataDir -Force | Out-Null
    Write-Host "Created directory: $tessdataDir" -ForegroundColor Yellow
}

$engFile = Join-Path $tessdataDir "eng.traineddata"

# Download eng.traineddata
Write-Host "Downloading eng.traineddata..." -ForegroundColor Yellow
try {
    Invoke-WebRequest -Uri $tessdataUrl -OutFile $engFile -UseBasicParsing
    Write-Host "Successfully downloaded eng.traineddata to: $engFile" -ForegroundColor Green
    Write-Host "File size: $((Get-Item $engFile).Length / 1MB) MB" -ForegroundColor Green
}
catch {
    Write-Host "Error downloading file: $_" -ForegroundColor Red
    Write-Host "Please download manually from: https://github.com/tesseract-ocr/tessdata" -ForegroundColor Yellow
    Write-Host "Save eng.traineddata to: $tessdataDir" -ForegroundColor Yellow
    exit 1
}

Write-Host "`nSetup complete! Restart the backend to use Tesseract OCR." -ForegroundColor Green

