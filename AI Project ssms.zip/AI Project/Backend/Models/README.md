# PaddleOCR ONNX Models

This directory should contain the PaddleOCR ONNX models required for OCR processing.

## Required Models

1. **det.onnx** - Text detection model
   - Detects text regions in images
   - Input: Image tensor [1, 3, H, W]
   - Output: Detection map

2. **rec.onnx** - Text recognition model
   - Recognizes text from detected regions
   - Input: Cropped text region [1, 3, 32, W]
   - Output: Character probabilities

3. **cls.onnx** - Text direction classifier (optional)
   - Classifies text direction (0° or 180°)
   - Can improve accuracy for rotated text

## Download Instructions

### Option 1: Download Pre-converted Models

1. Visit the PaddleOCR repository: https://github.com/PaddlePaddle/PaddleOCR
2. Check for ONNX model releases or conversion scripts
3. Download the models and place them in this directory

### Option 2: Convert from PaddleOCR Python Models

If you have access to Python (for conversion only), you can convert PaddleOCR models:

```python
# Example conversion script (run once to convert models)
from paddle2onnx import convert
# Convert detection model
convert.dygraph2onnx(
    model_dir='./inference/det',
    model_filename='inference.pdmodel',
    params_filename='inference.pdiparams',
    save_file='./det.onnx'
)
# Similar for rec.onnx and cls.onnx
```

### Option 3: Use PaddleOCR Inference Models

1. Download PaddleOCR inference models from the official repository
2. Use PaddleOCR's conversion tools to convert to ONNX format
3. Place converted `.onnx` files in this directory

## Model Path Configuration

The model path is configured in `appsettings.json`:

```json
{
  "Ocr": {
    "ModelsPath": "Models"
  }
}
```

## Notes

- Models are typically 10-50 MB each
- Ensure models match the PaddleOCR version you're targeting
- The OCR service will work in fallback mode if models are not found
- For production, consider hosting models in a shared location or cloud storage

