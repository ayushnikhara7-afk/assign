namespace Backend.Models;

public class HistoryResponse
{
    public int Id { get; set; }
    public string FileName { get; set; } = string.Empty;
    public long FileSize { get; set; }
    public string DocumentType { get; set; } = string.Empty;
    public DateTime ExtractedAt { get; set; }
    public ExtractedData? ExtractedData { get; set; }
    public string? RawText { get; set; }
}

