using Backend.Models;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.PixelFormats;
using Tesseract;

namespace Backend.Services;

public class OcrService : IOcrService, IDisposable
{
    private readonly TesseractEngine? _tesseractEngine;
    private readonly string _tessdataPath;
    private bool _disposed = false;

    public OcrService(IConfiguration configuration)
    {
        var configuredPath = configuration["Ocr:TessdataPath"];
        _tessdataPath = FindTessdataPath(configuredPath);
        
        // Initialize Tesseract OCR engine
        try
        {
            if (!string.IsNullOrEmpty(_tessdataPath) && Directory.Exists(_tessdataPath))
            {
                var engFile = Path.Combine(_tessdataPath, "eng.traineddata");
                if (File.Exists(engFile))
                {
                    _tesseractEngine = new TesseractEngine(_tessdataPath, "eng", EngineMode.Default);
                    _tesseractEngine.SetVariable("tessedit_char_whitelist", 
                        "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz.,;:!?@#$%^&*()_+-=[]{}|\\/<>\"' ");
                    Console.WriteLine($"Tesseract OCR engine initialized successfully from: {_tessdataPath}");
                }
                else
                {
                    Console.WriteLine($"Warning: eng.traineddata not found in {_tessdataPath}");
                    Console.WriteLine("Please download eng.traineddata from: https://github.com/tesseract-ocr/tessdata");
                }
            }
            else
            {
                Console.WriteLine($"Warning: Tesseract data directory not found.");
                Console.WriteLine($"Searched paths:");
                Console.WriteLine($"  - Configured: {configuredPath ?? "tessdata"}");
                Console.WriteLine($"  - Common Windows: C:\\Program Files\\Tesseract-OCR\\tessdata");
                Console.WriteLine($"  - Project: {Path.Combine(Directory.GetCurrentDirectory(), "tessdata")}");
                Console.WriteLine("Please download Tesseract data files. See SETUP_TESSERACT.md for instructions.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Warning: Could not initialize Tesseract OCR: {ex.Message}");
            Console.WriteLine("OCR will work in fallback mode.");
        }
    }

    private string? FindTessdataPath(string? configuredPath)
    {
        var pathsToCheck = new List<string>();

        // Add configured path first
        if (!string.IsNullOrEmpty(configuredPath))
        {
            pathsToCheck.Add(configuredPath);
            // If relative, also check from current directory
            if (!Path.IsPathRooted(configuredPath))
            {
                pathsToCheck.Add(Path.Combine(Directory.GetCurrentDirectory(), configuredPath));
            }
        }

        // Add default relative path
        pathsToCheck.Add(Path.Combine(Directory.GetCurrentDirectory(), "tessdata"));

        // Add common Windows installation paths
        if (OperatingSystem.IsWindows())
        {
            pathsToCheck.Add(@"C:\Program Files\Tesseract-OCR\tessdata");
            pathsToCheck.Add(@"C:\Program Files (x86)\Tesseract-OCR\tessdata");
        }
        // Add common macOS paths
        else if (OperatingSystem.IsMacOS())
        {
            pathsToCheck.Add("/opt/homebrew/share/tessdata");
            pathsToCheck.Add("/usr/local/share/tessdata");
        }
        // Add common Linux paths
        else if (OperatingSystem.IsLinux())
        {
            pathsToCheck.Add("/usr/share/tesseract-ocr/5/tessdata");
            pathsToCheck.Add("/usr/share/tesseract-ocr/4.00/tessdata");
            pathsToCheck.Add("/usr/share/tesseract-ocr/tessdata");
        }

        // Check each path
        foreach (var path in pathsToCheck)
        {
            if (Directory.Exists(path))
            {
                var engFile = Path.Combine(path, "eng.traineddata");
                if (File.Exists(engFile))
                {
                    return path;
                }
            }
        }

        return null;
    }

    public async Task<OcrResult> ProcessImageAsync(byte[] imageBytes)
    {
        return await ProcessImagesAsync(new List<byte[]> { imageBytes });
    }

    public async Task<OcrResult> ProcessImagesAsync(List<byte[]> images)
    {
        var result = new OcrResult();
        var allTextBlocks = new List<TextBlock>();

        if (_tesseractEngine == null)
        {
            // Fallback mode
            var mockText = "Tesseract OCR not initialized. Please ensure Tesseract data files are available.";
            allTextBlocks.Add(new TextBlock
            {
                Text = mockText,
                Confidence = 0.0,
                BoundingBox = new BoundingBox { X = 0, Y = 0, Width = 100, Height = 20 }
            });
            result.FullText = mockText;
            result.TextBlocks = allTextBlocks;
            return await Task.FromResult(result);
        }

        foreach (var imageBytes in images)
        {
            try
            {
                using var image = Image.Load<Rgb24>(imageBytes);
                var textBlocks = await ExtractTextFromImageAsync(image);
                allTextBlocks.AddRange(textBlocks);
                result.FullText += string.Join(" ", textBlocks.Select(tb => tb.Text)) + "\n";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing image: {ex.Message}");
                allTextBlocks.Add(new TextBlock
                {
                    Text = $"Error: {ex.Message}",
                    Confidence = 0.0,
                    BoundingBox = new BoundingBox { X = 0, Y = 0, Width = 100, Height = 20 }
                });
            }
        }

        result.TextBlocks = allTextBlocks;
        return await Task.FromResult(result);
    }

    private async Task<List<TextBlock>> ExtractTextFromImageAsync(Image<Rgb24> image)
    {
        var textBlocks = new List<TextBlock>();

        try
        {
            // Convert ImageSharp image to Pix (Tesseract format)
            using var pix = ConvertToPix(image);
            
            using var page = _tesseractEngine!.Process(pix, PageSegMode.Auto);
            
            // Get all words with bounding boxes
            using var iter = page.GetIterator();
            iter.Begin();

            do
            {
                if (iter.TryGetBoundingBox(PageIteratorLevel.Word, out var rect))
                {
                    var text = iter.GetText(PageIteratorLevel.Word);
                    var confidence = iter.GetConfidence(PageIteratorLevel.Word);

                    if (!string.IsNullOrWhiteSpace(text))
                    {
                        textBlocks.Add(new TextBlock
                        {
                            Text = text.Trim(),
                            Confidence = confidence / 100.0, // Convert to 0-1 scale
                            BoundingBox = new BoundingBox
                            {
                                X = rect.X1,
                                Y = rect.Y1,
                                Width = rect.X2 - rect.X1,
                                Height = rect.Y2 - rect.Y1
                            }
                        });
                    }
                }
            } while (iter.Next(PageIteratorLevel.Word));
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error during OCR extraction: {ex.Message}");
            textBlocks.Add(new TextBlock
            {
                Text = $"OCR Error: {ex.Message}",
                Confidence = 0.0,
                BoundingBox = new BoundingBox { X = 0, Y = 0, Width = 100, Height = 20 }
            });
        }

        return await Task.FromResult(textBlocks);
    }

    private Pix ConvertToPix(Image<Rgb24> image)
    {
        // Convert ImageSharp image to Tesseract Pix format
        // Save image to temporary file and load with Tesseract
        var tempFile = Path.GetTempFileName() + ".png";
        try
        {
            image.SaveAsPng(tempFile);
            return Pix.LoadFromFile(tempFile);
        }
        finally
        {
            // Clean up temp file
            if (File.Exists(tempFile))
            {
                try { File.Delete(tempFile); } catch { }
            }
        }
    }

    public void Dispose()
    {
        if (!_disposed)
        {
            _tesseractEngine?.Dispose();
            _disposed = true;
        }
    }
}
