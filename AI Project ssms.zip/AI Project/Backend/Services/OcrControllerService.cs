using Backend.Models;
using Backend.Services;
using UglyToad.PdfPig;

namespace Backend.Services;

public class OcrControllerService : IOcrControllerService
{
    private readonly IPdfToImageService _pdfToImageService;
    private readonly IOcrService _ocrService;
    private readonly IDataExtractionService _dataExtractionService;

    public OcrControllerService(
        IPdfToImageService pdfToImageService,
        IOcrService ocrService,
        IDataExtractionService dataExtractionService)
    {
        _pdfToImageService = pdfToImageService;
        _ocrService = ocrService;
        _dataExtractionService = dataExtractionService;
    }

    public async Task<ExtractedData> ProcessPdfAsync(Stream pdfStream)
    {
        // First, try to extract text directly from PDF (faster, more accurate)
        var directTextResult = await TryExtractTextDirectlyAsync(pdfStream);
        
        if (directTextResult != null && !string.IsNullOrWhiteSpace(directTextResult.FullText))
        {
            // Use direct text extraction if successful
            var extractedData = _dataExtractionService.ExtractStructuredData(directTextResult);
            return extractedData;
        }
        
        // Fallback to OCR if direct extraction fails or returns little text
        pdfStream.Position = 0;
        
        // Step 1: Convert PDF to images
        var images = await _pdfToImageService.ConvertPdfToImagesAsync(pdfStream);

        // Step 2: Run OCR on images
        var ocrResult = await _ocrService.ProcessImagesAsync(images);

        // Step 3: Extract structured data
        var extractedDataFromOcr = _dataExtractionService.ExtractStructuredData(ocrResult);

        return extractedDataFromOcr;
    }

    private async Task<OcrResult?> TryExtractTextDirectlyAsync(Stream pdfStream)
    {
        try
        {
            pdfStream.Position = 0;
            using var document = PdfDocument.Open(pdfStream);
            
            var textBlocks = new List<TextBlock>();
            var fullText = new System.Text.StringBuilder();
            
            for (int i = 0; i < document.NumberOfPages; i++)
            {
                var page = document.GetPage(i + 1);
                var words = page.GetWords();
                
                if (!words.Any())
                {
                    // No text in this page, skip direct extraction
                    return null;
                }
                
                foreach (var word in words)
                {
                    if (!string.IsNullOrWhiteSpace(word.Text))
                    {
                        var letters = word.Letters;
                        if (letters.Any())
                        {
                            var firstLetter = letters.First();
                            var lastLetter = letters.Last();
                            
                            // Calculate bounding box
                            var minX = letters.Min(l => Math.Min(l.StartBaseLine.X, l.EndBaseLine.X));
                            var maxX = letters.Max(l => Math.Max(l.StartBaseLine.X, l.EndBaseLine.X));
                            var minY = letters.Min(l => Math.Min(l.StartBaseLine.Y, l.EndBaseLine.Y));
                            var maxY = letters.Max(l => Math.Max(l.StartBaseLine.Y, l.EndBaseLine.Y));
                            
                            textBlocks.Add(new TextBlock
                            {
                                Text = word.Text,
                                Confidence = 1.0, // Direct extraction is 100% accurate
                                BoundingBox = new BoundingBox
                                {
                                    X = (int)minX,
                                    Y = (int)minY,
                                    Width = (int)(maxX - minX),
                                    Height = (int)(maxY - minY)
                                }
                            });
                            
                            fullText.Append(word.Text).Append(" ");
                        }
                    }
                }
                
                fullText.AppendLine();
            }
            
            // Only return if we got substantial text (more than just a few words)
            if (textBlocks.Count > 5)
            {
                return new OcrResult
                {
                    TextBlocks = textBlocks,
                    FullText = fullText.ToString()
                };
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Direct text extraction failed: {ex.Message}");
        }
        
        return null;
    }
}
