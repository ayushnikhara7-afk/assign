using Backend.Data;
using Backend.Models;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

namespace Backend.Services;

public class HistoryService : IHistoryService
{
    private readonly ApplicationDbContext _context;

    public HistoryService(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task SaveExtractionHistoryAsync(int userId, string fileName, long fileSize, ExtractedData extractedData, string? rawText = null)
    {
        var history = new ExtractionHistory
        {
            UserId = userId,
            FileName = fileName,
            FileSize = fileSize,
            DocumentType = extractedData.DocumentType,
            ExtractedDataJson = JsonSerializer.Serialize(extractedData),
            RawText = rawText,
            ExtractedAt = DateTime.UtcNow
        };

        _context.ExtractionHistories.Add(history);
        await _context.SaveChangesAsync();
    }

    public async Task<List<ExtractionHistory>> GetUserHistoryAsync(int userId, int page = 1, int pageSize = 20)
    {
        return await _context.ExtractionHistories
            .Where(h => h.UserId == userId)
            .OrderByDescending(h => h.ExtractedAt)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();
    }

    public async Task<ExtractionHistory?> GetHistoryByIdAsync(int historyId, int userId)
    {
        return await _context.ExtractionHistories
            .FirstOrDefaultAsync(h => h.Id == historyId && h.UserId == userId);
    }

    public async Task<bool> DeleteHistoryAsync(int historyId, int userId)
    {
        var history = await _context.ExtractionHistories
            .FirstOrDefaultAsync(h => h.Id == historyId && h.UserId == userId);

        if (history == null)
        {
            return false;
        }

        _context.ExtractionHistories.Remove(history);
        await _context.SaveChangesAsync();
        return true;
    }
}

