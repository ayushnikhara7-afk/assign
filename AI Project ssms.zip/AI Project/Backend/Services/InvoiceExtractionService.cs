using Backend.Models;
using System.Text.RegularExpressions;

namespace Backend.Services;

public static class InvoiceExtractionHelper
{
    public static void ExtractInvoiceInfo(string text, List<string> lines, List<TextBlock> textBlocks, ExtractedData extractedData)
    {
        // Enhanced invoice number extraction
        ExtractInvoiceNumber(text, extractedData);
        
        // Enhanced date extraction
        ExtractInvoiceDates(text, extractedData);
        
        // Enhanced amount extraction with better classification
        ExtractInvoiceAmounts(text, extractedData);
        
        // Extract line items
        ExtractInvoiceLineItems(text, lines, textBlocks, extractedData);
        
        // Extract payment information
        ExtractPaymentInfo(text, extractedData);
        
        // Extract PO/Reference numbers
        ExtractReferenceNumbers(text, extractedData);
    }

    private static void ExtractInvoiceNumber(string text, ExtractedData extractedData)
    {
        var invoicePatterns = new[]
        {
            @"(?:invoice|inv)[\s\-]*(?:no|number|#|num)[\s:]*([A-Z0-9\-/]+)",
            @"invoice[\s#]*([A-Z0-9\-/]+)",
            @"inv[\s#\-]*([A-Z0-9\-/]+)",
            @"#[\s]*([A-Z0-9\-/]+)",
            @"(?:invoice\s+id|invoice\s+code)[\s:]*([A-Z0-9\-/]+)"
        };
        
        foreach (var pattern in invoicePatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                var invoiceNum = match.Groups[1].Value.Trim();
                if (invoiceNum.Length >= 3 && invoiceNum.Length <= 50)
                {
                    extractedData.Fields["invoiceNumber"] = invoiceNum;
                    break;
                }
            }
        }
    }

    private static void ExtractInvoiceDates(string text, ExtractedData extractedData)
    {
        // Invoice date
        var invoiceDatePatterns = new[]
        {
            @"(?:invoice\s+date|date\s+of\s+invoice|issued\s+date|issue\s+date)[\s:]*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})",
            @"(?:invoice\s+date|date\s+of\s+invoice|issued\s+date|issue\s+date)[\s:]*(\d{4}[-/]\d{1,2}[-/]\d{1,2})",
            @"date[\s:]*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})"
        };
        
        foreach (var pattern in invoiceDatePatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                extractedData.Fields["invoiceDate"] = match.Groups[1].Value;
                break;
            }
        }
        
        // Due date
        var dueDatePatterns = new[]
        {
            @"(?:due\s+date|payment\s+due|due\s+on)[\s:]*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})",
            @"(?:due\s+date|payment\s+due|due\s+on)[\s:]*(\d{4}[-/]\d{1,2}[-/]\d{1,2})"
        };
        
        foreach (var pattern in dueDatePatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                extractedData.Fields["dueDate"] = match.Groups[1].Value;
                break;
            }
        }
    }

    private static void ExtractInvoiceAmounts(string text, ExtractedData extractedData)
    {
        // Extract subtotal
        var subtotalPatterns = new[]
        {
            @"(?:sub\s*[-]?\s*total|subtotal|total\s+before\s+tax)[\s:]*[₹$€£]?\s*(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})?)",
            @"subtotal[\s:]*[₹$€£]?\s*(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})?)"
        };
        
        foreach (var pattern in subtotalPatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                var amountStr = match.Groups[1].Value.Replace(",", "").Replace(" ", "");
                if (decimal.TryParse(amountStr, out var subtotal))
                {
                    extractedData.Fields["subtotal"] = subtotal;
                    break;
                }
            }
        }
        
        // Extract tax/GST amount
        var taxPatterns = new[]
        {
            @"(?:tax|gst|vat|cgst|sgst|igst)[\s:]*[₹$€£]?\s*(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})?)",
            @"(?:tax\s+amount|gst\s+amount)[\s:]*[₹$€£]?\s*(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})?)"
        };
        
        foreach (var pattern in taxPatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                var amountStr = match.Groups[1].Value.Replace(",", "").Replace(" ", "");
                if (decimal.TryParse(amountStr, out var tax))
                {
                    extractedData.Fields["taxAmount"] = tax;
                    break;
                }
            }
        }
        
        // Extract total amount
        var totalPatterns = new[]
        {
            @"(?:total|grand\s+total|net\s+amount|amount\s+due|total\s+amount)[\s:]*[₹$€£]?\s*(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})?)",
            @"(?:payable|pay\s+amount)[\s:]*[₹$€£]?\s*(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})?)"
        };
        
        foreach (var pattern in totalPatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                var amountStr = match.Groups[1].Value.Replace(",", "").Replace(" ", "");
                if (decimal.TryParse(amountStr, out var total))
                {
                    extractedData.Fields["totalAmount"] = total;
                    break;
                }
            }
        }
        
        // Calculate tax percentage if we have subtotal and tax
        if (extractedData.Fields.ContainsKey("subtotal") && extractedData.Fields.ContainsKey("taxAmount"))
        {
            var subtotal = Convert.ToDecimal(extractedData.Fields["subtotal"]);
            var tax = Convert.ToDecimal(extractedData.Fields["taxAmount"]);
            if (subtotal > 0)
            {
                var taxPercent = (tax / subtotal) * 100;
                extractedData.Fields["taxPercentage"] = Math.Round(taxPercent, 2);
            }
        }
    }

    private static void ExtractInvoiceLineItems(string text, List<string> lines, List<TextBlock> textBlocks, ExtractedData extractedData)
    {
        var items = new List<Dictionary<string, object>>();
        
        // Method 1: Extract from structured patterns
        var itemPatterns = new[]
        {
            @"(\d+(?:\.\d+)?)\s+([A-Za-z0-9\s\-.,()]+?)\s+[₹$€£]?\s*(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})?)",
            @"([A-Za-z0-9\s\-.,()]+?)\s+(\d+(?:\.\d+)?)\s+[₹$€£]?\s*(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})?)"
        };
        
        foreach (var pattern in itemPatterns)
        {
            var matches = Regex.Matches(text, pattern, RegexOptions.IgnoreCase);
            foreach (Match match in matches)
            {
                if (match.Groups.Count >= 3)
                {
                    var item = new Dictionary<string, object>();
                    
                    if (decimal.TryParse(match.Groups[1].Value.Replace(",", "").Replace(" ", ""), out var val1))
                    {
                        if (val1 < 1000) // Likely quantity
                        {
                            item["quantity"] = val1;
                            item["description"] = match.Groups[2].Value.Trim();
                            if (match.Groups.Count > 3 && decimal.TryParse(match.Groups[3].Value.Replace(",", "").Replace(" ", ""), out var price))
                            {
                                item["unitPrice"] = price;
                                item["total"] = val1 * price;
                            }
                        }
                    }
                    
                    if (item.Count > 0 && !items.Any(i => i["description"]?.ToString() == item["description"]?.ToString()))
                    {
                        items.Add(item);
                    }
                }
            }
        }
        
        if (items.Any())
        {
            extractedData.Fields["lineItems"] = items;
        }
    }

    private static void ExtractPaymentInfo(string text, ExtractedData extractedData)
    {
        var termsPattern = @"(?:payment\s+terms|terms)[\s:]+([A-Za-z0-9\s]+)";
        var termsMatch = Regex.Match(text, termsPattern, RegexOptions.IgnoreCase);
        if (termsMatch.Success)
        {
            extractedData.Fields["paymentTerms"] = termsMatch.Groups[1].Value.Trim();
        }
        
        var paymentMethodPattern = @"(?:payment\s+method|paid\s+by|payment\s+via)[\s:]+([A-Za-z\s]+)";
        var paymentMatch = Regex.Match(text, paymentMethodPattern, RegexOptions.IgnoreCase);
        if (paymentMatch.Success)
        {
            extractedData.Fields["paymentMethod"] = paymentMatch.Groups[1].Value.Trim();
        }
    }

    private static void ExtractReferenceNumbers(string text, ExtractedData extractedData)
    {
        var poPatterns = new[]
        {
            @"(?:p\.?o\.?\s*number|po\s*no|purchase\s+order)[\s:]+([A-Z0-9\-/]+)",
            @"po[\s#:]*([A-Z0-9\-/]+)"
        };
        
        foreach (var pattern in poPatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                extractedData.Fields["poNumber"] = match.Groups[1].Value.Trim();
                break;
            }
        }
    }
}

