namespace Backend.Services;

public interface IPdfToImageService
{
    Task<List<byte[]>> ConvertPdfToImagesAsync(Stream pdfStream);
}

