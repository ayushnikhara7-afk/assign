using UglyToad.PdfPig;
using UglyToad.PdfPig.Content;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.Versioning;
using DrawingColor = System.Drawing.Color;
using DrawingPointF = System.Drawing.PointF;

namespace Backend.Services;

[SupportedOSPlatform("windows")]
public class PdfToImageService : IPdfToImageService
{
    public async Task<List<byte[]>> ConvertPdfToImagesAsync(Stream pdfStream)
    {
        var images = new List<byte[]>();
        
        // Reset stream position
        pdfStream.Position = 0;
        
        using var document = PdfDocument.Open(pdfStream);
        
        for (int i = 0; i < document.NumberOfPages; i++)
        {
            var page = document.GetPage(i + 1);
            
            // Get page dimensions
            var width = (int)page.Width;
            var height = (int)page.Height;
            
            // Scale for better quality (300 DPI equivalent)
            var scale = 300.0 / 72.0; // 72 DPI is default
            var scaledWidth = (int)(width * scale);
            var scaledHeight = (int)(height * scale);
            
            // Create a bitmap image
            using var bitmap = new Bitmap(scaledWidth, scaledHeight);
            using var graphics = Graphics.FromImage(bitmap);
            
            // Set high quality rendering
            graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            graphics.PixelOffsetMode = System.Drawing.Drawing2D.PixelOffsetMode.HighQuality;
            graphics.Clear(DrawingColor.White);
            
            // Extract and render text from PDF
            try
            {
                var words = page.GetWords();
                
                if (words.Any())
                {
                    // Render actual text from PDF
                    foreach (var word in words)
                    {
                        var letters = word.Letters;
                        if (letters.Any())
                        {
                            var firstLetter = letters.First();
                            var lastLetter = letters.Last();
                            
                            // Calculate position (PDF coordinates are bottom-left, Graphics uses top-left)
                            var x = (float)(firstLetter.StartBaseLine.X * scale);
                            var y = (float)(scaledHeight - (firstLetter.StartBaseLine.Y * scale));
                            
                            // Get font size
                            var fontSize = (float)(firstLetter.FontSize * scale * 0.75); // Adjust scale
                            if (fontSize < 8) fontSize = 8;
                            if (fontSize > 72) fontSize = 72;
                            
                            try
                            {
                                using var font = new Font("Arial", fontSize, FontStyle.Regular);
                                graphics.DrawString(word.Text, font, Brushes.Black, new DrawingPointF(x, y));
                            }
                            catch
                            {
                                // Fallback to default font if custom font fails
                                using var font = new Font("Arial", 12);
                                graphics.DrawString(word.Text, font, Brushes.Black, new DrawingPointF(x, y));
                            }
                        }
                    }
                }
                else
                {
                    // No text found - might be image-based PDF, create placeholder
                    graphics.DrawString($"Page {i + 1} (Image-based PDF - OCR will extract text)", 
                        new Font("Arial", 16), 
                        Brushes.Gray, 
                        new DrawingPointF(50, 50));
                }
            }
            catch (Exception ex)
            {
                // If text extraction fails, create placeholder
                Console.WriteLine($"Warning: Could not extract text from page {i + 1}: {ex.Message}");
                graphics.DrawString($"Page {i + 1}", 
                    new Font("Arial", 24), 
                    Brushes.Black, 
                    new DrawingPointF(50, 50));
            }
            
            // Convert bitmap to byte array
            using var ms = new MemoryStream();
            bitmap.Save(ms, ImageFormat.Png);
            images.Add(ms.ToArray());
        }
        
        return await Task.FromResult(images);
    }
}
