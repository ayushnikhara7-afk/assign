using Backend.Models;

namespace Backend.Services;

public interface IHistoryService
{
    Task SaveExtractionHistoryAsync(int userId, string fileName, long fileSize, ExtractedData extractedData, string? rawText = null);
    Task<List<ExtractionHistory>> GetUserHistoryAsync(int userId, int page = 1, int pageSize = 20);
    Task<ExtractionHistory?> GetHistoryByIdAsync(int historyId, int userId);
    Task<bool> DeleteHistoryAsync(int historyId, int userId);
}

