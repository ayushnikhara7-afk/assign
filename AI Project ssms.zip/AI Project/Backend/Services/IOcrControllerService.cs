using Backend.Models;

namespace Backend.Services;

public interface IOcrControllerService
{
    Task<ExtractedData> ProcessPdfAsync(Stream pdfStream);
}

