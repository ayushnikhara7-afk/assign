using Backend.Models;
using Backend.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using System.Text.Json;

namespace Backend.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class HistoryController : ControllerBase
{
    private readonly IHistoryService _historyService;
    private readonly ILogger<HistoryController> _logger;

    public HistoryController(IHistoryService historyService, ILogger<HistoryController> logger)
    {
        _historyService = historyService;
        _logger = logger;
    }

    [HttpGet]
    public async Task<IActionResult> GetHistory([FromQuery] int page = 1, [FromQuery] int pageSize = 20)
    {
        try
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim == null || !int.TryParse(userIdClaim.Value, out var userId))
            {
                return Unauthorized(new { error = "Invalid user token" });
            }

            var history = await _historyService.GetUserHistoryAsync(userId, page, pageSize);
            
            var result = history.Select(h => new
            {
                h.Id,
                h.FileName,
                h.FileSize,
                h.DocumentType,
                h.ExtractedAt,
                ExtractedData = JsonSerializer.Deserialize<ExtractedData>(h.ExtractedDataJson)
            }).ToList();

            return Ok(new { data = result, page, pageSize });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving history");
            return StatusCode(500, new { error = "Error retrieving history", message = ex.Message });
        }
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetHistoryById(int id)
    {
        try
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim == null || !int.TryParse(userIdClaim.Value, out var userId))
            {
                return Unauthorized(new { error = "Invalid user token" });
            }

            var history = await _historyService.GetHistoryByIdAsync(id, userId);
            
            if (history == null)
            {
                return NotFound(new { error = "History not found" });
            }

            var result = new
            {
                history.Id,
                history.FileName,
                history.FileSize,
                history.DocumentType,
                history.ExtractedAt,
                history.RawText,
                ExtractedData = JsonSerializer.Deserialize<ExtractedData>(history.ExtractedDataJson)
            };

            return Ok(result);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving history item");
            return StatusCode(500, new { error = "Error retrieving history item", message = ex.Message });
        }
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteHistory(int id)
    {
        try
        {
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim == null || !int.TryParse(userIdClaim.Value, out var userId))
            {
                return Unauthorized(new { error = "Invalid user token" });
            }

            var deleted = await _historyService.DeleteHistoryAsync(id, userId);
            
            if (!deleted)
            {
                return NotFound(new { error = "History not found" });
            }

            return Ok(new { message = "History deleted successfully" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error deleting history");
            return StatusCode(500, new { error = "Error deleting history", message = ex.Message });
        }
    }
}

