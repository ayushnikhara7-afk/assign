using Backend.Models;
using Backend.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace Backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OcrController : ControllerBase
{
    private readonly IOcrControllerService _ocrControllerService;
    private readonly IHistoryService _historyService;
    private readonly ILogger<OcrController> _logger;

    public OcrController(
        IOcrControllerService ocrControllerService,
        IHistoryService historyService,
        ILogger<OcrController> logger)
    {
        _ocrControllerService = ocrControllerService;
        _historyService = historyService;
        _logger = logger;
    }

    [HttpPost("extract")]
    [Authorize]
    public async Task<IActionResult> ExtractData(IFormFile file)
    {
        if (file == null || file.Length == 0)
        {
            return BadRequest(new { error = "No file uploaded" });
        }

        if (!file.ContentType.Equals("application/pdf", StringComparison.OrdinalIgnoreCase))
        {
            return BadRequest(new { error = "Only PDF files are supported" });
        }

        try
        {
            // Get user ID from JWT token
            var userIdClaim = User.FindFirst(ClaimTypes.NameIdentifier);
            if (userIdClaim == null || !int.TryParse(userIdClaim.Value, out var userId))
            {
                return Unauthorized(new { error = "Invalid user token" });
            }

            using var stream = file.OpenReadStream();
            var extractedData = await _ocrControllerService.ProcessPdfAsync(stream);

            // Save to history
            await _historyService.SaveExtractionHistoryAsync(
                userId,
                file.FileName,
                file.Length,
                extractedData,
                extractedData.RawText
            );

            return Ok(extractedData);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing PDF");
            return StatusCode(500, new { error = "Error processing PDF", message = ex.Message });
        }
    }

    [HttpGet("health")]
    public IActionResult Health()
    {
        return Ok(new { status = "healthy", timestamp = DateTime.UtcNow });
    }
}

