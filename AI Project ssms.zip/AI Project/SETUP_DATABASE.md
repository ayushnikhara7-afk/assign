# Database Setup Guide

## Quick Setup

### 1. Install SQL Server

**Option A: SQL Server LocalDB (Recommended for Development)**
- Already included with Visual Studio
- Or download: https://www.microsoft.com/en-us/sql-server/sql-server-downloads

**Option B: SQL Server Express**
- Download from Microsoft website
- Install and configure

### 2. Update Connection String

Edit `Backend/appsettings.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=(localdb)\\mssqllocaldb;Database=OcrExtractionDb;Trusted_Connection=True;MultipleActiveResultSets=true"
  }
}
```

**For SQL Server Express:**
```
Server=localhost\\SQLEXPRESS;Database=OcrExtractionDb;Trusted_Connection=True;MultipleActiveResultSets=true
```

### 3. Create Database

Run these commands in the `Backend` directory:

```bash
# Install EF Core tools (if not installed)
dotnet tool install --global dotnet-ef

# Create migration
dotnet ef migrations add InitialCreate

# Apply to database
dotnet ef database update
```

### 4. Verify

The database `OcrExtractionDb` will be created with:
- **Users** table
- **ExtractionHistories** table

## Database Schema

### Users Table
- Stores user accounts for authentication
- Fields: Id, Username, Email, PasswordHash, CreatedAt, LastLoginAt, IsActive

### ExtractionHistories Table
- Stores all PDF extraction history
- Fields: Id, UserId, FileName, FileSize, DocumentType, ExtractedDataJson, RawText, ExtractedAt
- Linked to Users via foreign key

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user

### OCR (Requires Authentication)
- `POST /api/ocr/extract` - Extract data from PDF (saves to history)

### History (Requires Authentication)
- `GET /api/history` - Get user's extraction history
- `GET /api/history/{id}` - Get specific history item
- `DELETE /api/history/{id}` - Delete history item

## Frontend Features

- Login/Register page
- Protected routes (requires authentication)
- History page to view past extractions
- Automatic history saving on PDF extraction

