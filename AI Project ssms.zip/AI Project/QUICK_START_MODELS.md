# Quick Start: Adding PaddleOCR Models

The system is working, but you need to add PaddleOCR ONNX models to enable actual OCR functionality.

## Current Status

✅ Backend API is running  
✅ Frontend is connected  
✅ PDF upload is working  
⚠️ OCR models are missing (using fallback mode)

## Option 1: Download Pre-converted ONNX Models (Easiest)

### Step 1: Find ONNX Models

Search for "PaddleOCR ONNX models" or check these sources:

1. **PaddleOCR GitHub Releases:**
   - Visit: https://github.com/PaddlePaddle/PaddleOCR/releases
   - Look for ONNX model releases or conversion scripts

2. **Community Converted Models:**
   - Search GitHub for "PaddleOCR ONNX" repositories
   - Some users share converted models

3. **Model Conversion Tools:**
   - PaddleOCR provides tools to convert models to ONNX
   - Check their documentation for conversion scripts

### Step 2: Download Required Models

You need these two files:
- `det.onnx` - Text detection model (detects where text is in images)
- `rec.onnx` - Text recognition model (reads the text)

Optional:
- `cls.onnx` - Text direction classifier (improves accuracy for rotated text)

### Step 3: Place Models in Backend

1. Create the Models directory if it doesn't exist:
   ```
   Backend/Models/
   ```

2. Copy the downloaded `.onnx` files to:
   ```
   Backend/Models/det.onnx
   Backend/Models/rec.onnx
   ```

3. Restart the backend:
   ```bash
   cd Backend
   dotnet run
   ```

## Option 2: Convert from PaddleOCR Python Models

If you have Python installed (for one-time conversion only):

### Step 1: Install PaddleOCR and Conversion Tools

```bash
pip install paddlepaddle paddleocr paddle2onnx
```

### Step 2: Download PaddleOCR Inference Models

```python
from paddleocr import PaddleOCR

# This will download the models
ocr = PaddleOCR(use_angle_cls=True, lang='en')
```

Models will be downloaded to: `~/.paddleocr/whl/`

### Step 3: Convert to ONNX

```python
from paddle2onnx import convert

# Convert detection model
convert.dygraph2onnx(
    model_dir='~/.paddleocr/whl/det/en/en_PP-OCRv4_det_infer',
    model_filename='inference.pdmodel',
    params_filename='inference.pdiparams',
    save_file='./det.onnx',
    opset_version=11
)

# Convert recognition model
convert.dygraph2onnx(
    model_dir='~/.paddleocr/whl/rec/en/en_PP-OCRv4_rec_infer',
    model_filename='inference.pdmodel',
    params_filename='inference.pdiparams',
    save_file='./rec.onnx',
    opset_version=11
)
```

### Step 4: Copy to Backend

Move the converted `.onnx` files to `Backend/Models/`

## Option 3: Use Alternative OCR (For Testing)

If you just want to test the system without PaddleOCR models, you can:

1. Modify `OcrService.cs` to use a different OCR library
2. Or implement a mock OCR that extracts text from PDFs directly (if PDFs have text layers)

## Verification

After adding models, restart the backend and check the console output. You should see:

```
✓ ONNX models loaded successfully
```

Instead of:
```
⚠ Warning: ONNX models not found
```

## Testing

1. Upload a PDF file through the Angular UI
2. The system should now extract actual text
3. Check the "Raw Text" field in the results

## Model Sizes

- `det.onnx`: ~2-5 MB
- `rec.onnx`: ~10-15 MB
- `cls.onnx`: ~2-3 MB (optional)

## Troubleshooting

### Models Not Loading

- Check file paths in `appsettings.json`
- Verify files are actually `.onnx` format
- Check file permissions
- Look for errors in backend console

### Wrong Model Format

- Ensure models are ONNX format (not Paddle format)
- Check ONNX version compatibility (opset 11 recommended)
- Verify model input/output shapes match expected format

### Low Accuracy

- Use latest PaddleOCR models (v4 or newer)
- Ensure proper image preprocessing
- Check if models match the language of your documents

## Next Steps After Adding Models

Once models are loaded, you'll still need to:

1. **Complete Detection Parsing** - Implement proper bounding box extraction (see `IMPLEMENTATION_GUIDE.md`)
2. **Complete Recognition Decoding** - Implement text decoding with character dictionary
3. **Improve PDF Rendering** - Use proper PDF rendering library for better image quality

See `IMPLEMENTATION_GUIDE.md` for detailed implementation steps.

