using Microsoft.AspNetCore.Mvc;
using RetailManagementAPI.Interfaces;

namespace RetailManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly ICustomer _customerRepository;

        public CustomerController(ICustomer customerRepository)
        {
            _customerRepository = customerRepository;
        }

        [HttpGet("recent-orders")]
        public async Task<IActionResult> GetCustomersWithRecentOrders([FromQuery] DateTime sinceDate)
        {
            var customers = await _customerRepository.GetCustomersWithRecentOrders(sinceDate);
            if (customers == null || !customers.Any())
            {
                return NotFound("No records found");
            }
            return Ok(customers);
        }

        [HttpGet("highest-order-count")]
        public async Task<IActionResult> GetCustomerWithHighestOrderCount()
        {
            var customer = await _customerRepository.GetCustomerWithHighestOrderCount();
            if (customer == null)
            {
                return NotFound("No records found");
            }
            return Ok(customer);
        }

        [HttpGet("most-spent")]
        public async Task<IActionResult> GetCustomerWithMostSpentAmount()
        {
            var customer = await _customerRepository.GetCustomerWithMostSpentAmount();
            if (customer == null)
            {
                return NotFound("No records found");
            }
            return Ok(customer);
        }
    }
}