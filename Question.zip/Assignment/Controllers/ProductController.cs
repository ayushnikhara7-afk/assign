using Microsoft.AspNetCore.Mvc;
using RetailManagementAPI.Interfaces;
using RetailManagementAPI.Models;

namespace RetailManagementAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductController : ControllerBase
    {
        private readonly IProduct _productRepository;

        public ProductController(IProduct productRepository)
        {
            _productRepository = productRepository;
        }

        [HttpPost]
        public async Task<IActionResult> AddProduct([FromBody] Product product)
        {
            var result = await _productRepository.AddProduct(product);
            if (result)
            {
                return Ok();
            }
            return BadRequest();
        }

        [HttpPut("UpdateProductPrice/{id}/{price}")]
        public async Task<IActionResult> UpdateProductPrice([FromRoute] int id, [FromRoute] decimal price)
        {
            var result = await _productRepository.UpdateProductPrice(id, price);
            if (result)
            {
                return Ok();
            }
            return BadRequest();
        }

        [HttpDelete("DeleteProduct/{id}")]
        public async Task<IActionResult> DeleteProduct([FromRoute] int id)
        {
            var result = await _productRepository.DeleteProduct(id);
            if (result)
            {
                return Ok();
            }
            return BadRequest();
        }

        [HttpGet("highest-order-quantity")]
        public async Task<IActionResult> GetProductWithHighestOrderQuantity()
        {
            var product = await _productRepository.GetProductWithHighestOrderQuantity();
            if (product == null)
            {
                return NotFound("No records found");
            }
            return Ok(product);
        }
    }
}

