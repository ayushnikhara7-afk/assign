using Microsoft.EntityFrameworkCore;
using RetailManagementAPI.Data;
using RetailManagementAPI.Interfaces;
using RetailManagementAPI.Models;

namespace RetailManagementAPI.Repositories
{
    public class OrderRepository : IOrder
    {
        private readonly RetailContext _context;

        public OrderRepository(RetailContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Order>> GetOrdersByCustomer(int customerId)
        {
            var orders = await _context.Orders
                .Include(o => o.Customer)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Product)
                .Where(o => o.CustomerId == customerId)
                .ToListAsync();

            return orders;
        }

        public async Task<IEnumerable<Order>> GetOrdersInDateRange(DateTime startDate, DateTime endDate)
        {
            var orders = await _context.Orders
                .Include(o => o.Customer)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Product)
                .Where(o => o.OrderDate >= startDate && o.OrderDate <= endDate)
                .ToListAsync();

            return orders;
        }

        public async Task<Order> GetOrderWithHighestTotalAmount()
        {
            var orderId = await _context.Orders
                .Select(o => new
                {
                    OrderId = o.Id,
                    TotalAmount = o.OrderItems.Sum(oi => oi.Quantity * oi.Product.Price)
                })
                .OrderByDescending(x => x.TotalAmount)
                .Select(x => x.OrderId)
                .FirstOrDefaultAsync();

            if (orderId == 0)
            {
                return null;
            }

            var order = await _context.Orders
                .Include(o => o.Customer)
                .Include(o => o.OrderItems)
                    .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(o => o.Id == orderId);

            return order;
        }
    }
}

