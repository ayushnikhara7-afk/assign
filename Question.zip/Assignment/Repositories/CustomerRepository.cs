using Microsoft.EntityFrameworkCore;
using RetailManagementAPI.Data;
using RetailManagementAPI.Interfaces;
using RetailManagementAPI.Models;

namespace RetailManagementAPI.Repositories
{
    public class CustomerRepository : ICustomer
    {
        private readonly RetailContext _context;

        public CustomerRepository(RetailContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Customer>> GetCustomersWithRecentOrders(DateTime sinceDate)
        {
            var customers = await _context.Customers
                .Include(c => c.Orders)
                    .ThenInclude(o => o.OrderItems)
                        .ThenInclude(oi => oi.Product)
                .Where(c => c.Orders.Any(o => o.OrderDate >= sinceDate))
                .ToListAsync();

            return customers;
        }

        public async Task<Customer> GetCustomerWithHighestOrderCount()
        {
            var customerId = await _context.Customers
                .Select(c => new
                {
                    CustomerId = c.Id,
                    OrderCount = c.Orders.Count()
                })
                .OrderByDescending(x => x.OrderCount)
                .Select(x => x.CustomerId)
                .FirstOrDefaultAsync();

            if (customerId == 0)
            {
                return null;
            }

            var customer = await _context.Customers
                .Include(c => c.Orders)
                    .ThenInclude(o => o.OrderItems)
                        .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(c => c.Id == customerId);

            return customer;
        }

        public async Task<Customer> GetCustomerWithMostSpentAmount()
        {
            var customerId = await _context.Customers
                .Select(c => new
                {
                    CustomerId = c.Id,
                    TotalSpent = c.Orders.Sum(o => o.OrderItems.Sum(oi => oi.Quantity * oi.Product.Price))
                })
                .OrderByDescending(x => x.TotalSpent)
                .Select(x => x.CustomerId)
                .FirstOrDefaultAsync();

            if (customerId == 0)
            {
                return null;
            }

            var customer = await _context.Customers
                .Include(c => c.Orders)
                    .ThenInclude(o => o.OrderItems)
                        .ThenInclude(oi => oi.Product)
                .FirstOrDefaultAsync(c => c.Id == customerId);

            return customer;
        }
    }
}