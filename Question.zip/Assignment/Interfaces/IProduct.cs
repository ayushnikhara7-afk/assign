using RetailManagementAPI.Models;

namespace RetailManagementAPI.Interfaces
{
    public interface IProduct
    {
        Task<bool> AddProduct(Product product);
        Task<bool> UpdateProductPrice(int id, decimal price);
        Task<bool> DeleteProduct(int id);
        Task<Product> GetProductWithHighestOrderQuantity();
    }
}

