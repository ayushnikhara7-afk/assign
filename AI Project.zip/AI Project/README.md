# OCR-Based PDF Data Extraction System

A complete OCR-based PDF data extraction system using PaddleOCR (via ONNX Runtime) with ASP.NET Core backend and Angular frontend.

## 🏗️ Architecture

- **Backend**: ASP.NET Core Web API (.NET 9)
- **Frontend**: Angular (latest)
- **OCR Engine**: Tesseract OCR (via Tesseract.NET)
- **PDF Processing**: ImageSharp for PDF to image conversion

## 📂 Project Structure

```
AI Project/
├── Backend/              # ASP.NET Core Web API
│   ├── Controllers/
│   ├── Services/
│   ├── Models/
│   └── Program.cs
├── Frontend/             # Angular Application
│   ├── src/
│   │   ├── app/
│   │   └── ...
│   └── ...
└── README.md
```

## 🚀 Setup Instructions

### Prerequisites

1. **.NET 9 SDK** - [Download](https://dotnet.microsoft.com/download/dotnet/9.0)
2. **Node.js 18+** and **npm** - [Download](https://nodejs.org/)
3. **Angular CLI** - `npm install -g @angular/cli`
4. **PaddleOCR ONNX Models** - Download from [PaddleOCR releases](https://github.com/PaddlePaddle/PaddleOCR/releases)

### Backend Setup

1. Navigate to `Backend` directory:
   ```bash
   cd Backend
   ```

2. Restore NuGet packages:
   ```bash
   dotnet restore
   ```

3. Setup Tesseract OCR data files:
   - **Windows**: Copy `tessdata` folder from Tesseract installation to `Backend/tessdata/`
   - **Alternative**: Download `eng.traineddata` from [tessdata](https://github.com/tesseract-ocr/tessdata) and place in `Backend/tessdata/`
   - Or update `appsettings.json` to point to your Tesseract installation's tessdata folder

4. Run the API:
   ```bash
   dotnet run
   ```

   API will be available at `https://localhost:5001` or `http://localhost:5000`

### Frontend Setup

1. Navigate to `Frontend` directory:
   ```bash
   cd Frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Update API URL in `src/environments/environment.ts` if needed

4. Run the Angular app:
   ```bash
   ng serve
   ```

   Frontend will be available at `http://localhost:4200`

## 📝 API Endpoints

### POST /api/ocr/extract
Upload a PDF file and extract structured data.

**Request:**
- Content-Type: `multipart/form-data`
- Body: PDF file

**Response:**
```json
{
  "documentType": "Invoice",
  "fields": {
    "invoiceNumber": "INV-1023",
    "date": "2025-09-15",
    "vendorName": "ABC Pvt Ltd",
    "gstNumber": "27ABCDE1234F1Z5",
    "totalAmount": 1000
  },
  "tables": [
    {
      "headers": ["Item", "Quantity", "Price"],
      "rows": [
        ["Product A", "2", "500"]
      ]
    }
  ],
  "rawText": "Full extracted text..."
}
```

### GET /api/ocr/health
Health check endpoint to verify API status.

## 🔧 Configuration

### Backend Configuration

Update `appsettings.json` to configure:
- Tesseract data path (`TessdataPath`)
- Image processing settings
- CORS origins

### Frontend Configuration

Update `src/environments/environment.ts` to set the API base URL.

## ⚠️ Important Notes

### PDF Rendering

The current PDF to image conversion uses a basic implementation. For production use, consider:

1. **Using a proper PDF rendering library:**
   - **PdfiumViewer** (Windows-specific, requires native libraries)
   - **SkiaSharp** with **PdfSharpCore** (cross-platform)
   - **MuPDF** bindings (requires native libraries)

2. **Alternative approaches:**
   - Use a PDF rendering service
   - Convert PDFs to images server-side using Ghostscript
   - Use cloud-based PDF rendering services

### OCR Model Integration

The OCR service includes placeholder implementations for:
- Bounding box extraction from detection model
- Text decoding from recognition model

For production, you'll need to:
1. Implement proper parsing of PaddleOCR detection output
2. Use the correct character dictionary for text recognition
3. Handle text direction classification if using cls.onnx

See `Backend/Services/OcrService.cs` for implementation details.

## 📦 Dependencies

### Backend
- Microsoft.AspNetCore.App
- SixLabors.ImageSharp
- Microsoft.ML.OnnxRuntime
- System.Drawing.Common

### Frontend
- @angular/core
- @angular/common
- @angular/forms
- @angular/http-client

## 🎯 Features

- ✅ PDF file upload
- ✅ PDF to image conversion
- ✅ OCR text extraction with bounding boxes
- ✅ Structured data extraction
- ✅ Table detection
- ✅ JSON output
- ✅ Download extracted data

## 📄 License

MIT License

