# Tesseract OCR Data Files

This directory should contain Tesseract OCR language data files.

## Quick Setup

### Windows

1. Download Tesseract installer from: https://github.com/UB-Mannheim/tesseract/wiki
2. Install Tesseract (default location: `C:\Program Files\Tesseract-OCR`)
3. Copy the `tessdata` folder from installation directory to `Backend/tessdata`
4. Or set the path in `appsettings.json`:
   ```json
   {
     "Ocr": {
       "TessdataPath": "C:\\Program Files\\Tesseract-OCR\\tessdata"
     }
   }
   ```

### Alternative: Download tessdata directly

1. Download English language data from: https://github.com/tesseract-ocr/tessdata
2. Download `eng.traineddata` file
3. Place it in `Backend/tessdata/eng.traineddata`

## Required Files

- `eng.traineddata` - English language model (required)

## Optional Files

- `osd.traineddata` - Orientation and script detection
- Other language models as needed

## Configuration

Update `appsettings.json` if tessdata is in a different location:

```json
{
  "Ocr": {
    "TessdataPath": "path/to/tessdata"
  }
}
```

## Notes

- Tesseract.NET requires the native Tesseract library
- On Windows, the Tesseract installer includes the native DLLs
- The Tesseract.NET NuGet package should handle native dependencies automatically

