#!/bin/bash
# Bash script to download Tesseract tessdata files
# Run this script from the Backend directory

echo "Downloading Tesseract tessdata files..."

TESSDATA_DIR="$(dirname "$0")/../tessdata"
TESSDATA_URL="https://github.com/tesseract-ocr/tessdata/raw/main/eng.traineddata"

# Create tessdata directory if it doesn't exist
mkdir -p "$TESSDATA_DIR"

ENG_FILE="$TESSDATA_DIR/eng.traineddata"

# Download eng.traineddata
echo "Downloading eng.traineddata..."
if command -v curl &> /dev/null; then
    curl -L -o "$ENG_FILE" "$TESSDATA_URL"
elif command -v wget &> /dev/null; then
    wget -O "$ENG_FILE" "$TESSDATA_URL"
else
    echo "Error: Neither curl nor wget found. Please install one of them."
    echo "Or download manually from: https://github.com/tesseract-ocr/tessdata"
    echo "Save eng.traineddata to: $TESSDATA_DIR"
    exit 1
fi

if [ -f "$ENG_FILE" ]; then
    FILE_SIZE=$(du -h "$ENG_FILE" | cut -f1)
    echo "Successfully downloaded eng.traineddata to: $ENG_FILE"
    echo "File size: $FILE_SIZE"
    echo ""
    echo "Setup complete! Restart the backend to use Tesseract OCR."
else
    echo "Error: Failed to download eng.traineddata"
    echo "Please download manually from: https://github.com/tesseract-ocr/tessdata"
    echo "Save eng.traineddata to: $TESSDATA_DIR"
    exit 1
fi

