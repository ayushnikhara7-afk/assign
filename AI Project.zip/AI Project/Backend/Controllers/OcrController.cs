using Backend.Models;
using Backend.Services;
using Microsoft.AspNetCore.Mvc;

namespace Backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class OcrController : ControllerBase
{
    private readonly IOcrControllerService _ocrControllerService;
    private readonly ILogger<OcrController> _logger;

    public OcrController(
        IOcrControllerService ocrControllerService,
        ILogger<OcrController> logger)
    {
        _ocrControllerService = ocrControllerService;
        _logger = logger;
    }

    [HttpPost("extract")]
    public async Task<IActionResult> ExtractData(IFormFile file)
    {
        if (file == null || file.Length == 0)
        {
            return BadRequest(new { error = "No file uploaded" });
        }

        if (!file.ContentType.Equals("application/pdf", StringComparison.OrdinalIgnoreCase))
        {
            return BadRequest(new { error = "Only PDF files are supported" });
        }

        try
        {
            using var stream = file.OpenReadStream();
            var extractedData = await _ocrControllerService.ProcessPdfAsync(stream);

            return Ok(extractedData);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error processing PDF");
            return StatusCode(500, new { error = "Error processing PDF", message = ex.Message });
        }
    }

    [HttpGet("health")]
    public IActionResult Health()
    {
        return Ok(new { status = "healthy", timestamp = DateTime.UtcNow });
    }
}

