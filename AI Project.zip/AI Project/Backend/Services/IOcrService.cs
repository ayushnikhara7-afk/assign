using Backend.Models;

namespace Backend.Services;

public interface IOcrService
{
    Task<OcrResult> ProcessImageAsync(byte[] imageBytes);
    Task<OcrResult> ProcessImagesAsync(List<byte[]> images);
}

