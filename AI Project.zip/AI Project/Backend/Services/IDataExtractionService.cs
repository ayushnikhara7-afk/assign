using Backend.Models;

namespace Backend.Services;

public interface IDataExtractionService
{
    ExtractedData ExtractStructuredData(OcrResult ocrResult);
}

