using Backend.Models;
using System.Text.RegularExpressions;

namespace Backend.Services;

public class DataExtractionService : IDataExtractionService
{
    public ExtractedData ExtractStructuredData(OcrResult ocrResult)
    {
        var extractedData = new ExtractedData
        {
            RawText = ocrResult.FullText
        };

        var text = ocrResult.FullText;
        var lines = text.Split('\n', StringSplitOptions.RemoveEmptyEntries)
            .Select(l => l.Trim())
            .Where(l => !string.IsNullOrWhiteSpace(l))
            .ToList();

        // Detect document type
        extractedData.DocumentType = DetectDocumentType(text);

        // Extract structured fields based on document type
        ExtractCommonFields(text, lines, extractedData);

        // Extract document-specific information
        if (extractedData.DocumentType == "Resume" || extractedData.DocumentType == "CV")
        {
            ExtractResumeInfo(text, lines, extractedData);
        }
        else if (extractedData.DocumentType == "Receipt")
        {
            // Only extract vendor info for receipts
            ExtractVendorInfo(text, lines, extractedData);
        }
        else
        {
            // For invoices, bills, etc. - extract both vendor and customer
            ExtractVendorInfo(text, lines, extractedData);
            ExtractCustomerInfo(text, lines, extractedData);
            
            // Extract line items for invoices
            if (extractedData.DocumentType == "Invoice" || extractedData.DocumentType == "Bill")
            {
                ExtractLineItems(text, lines, ocrResult.TextBlocks, extractedData);
            }
        }

        // Extract tables
        extractedData.Tables = ExtractTables(ocrResult.TextBlocks);

        // Extract additional metadata
        ExtractMetadata(text, extractedData);

        return extractedData;
    }

    private string DetectDocumentType(string text)
    {
        text = text.ToLower();
        
        // Resume/CV detection (check first as it's more specific)
        if (text.Contains("resume") || text.Contains("curriculum vitae") || text.Contains("cv") ||
            text.Contains("objective") || text.Contains("professional summary") ||
            text.Contains("work experience") || text.Contains("employment history") ||
            text.Contains("education") || text.Contains("skills") || text.Contains("qualifications") ||
            text.Contains("references") || text.Contains("contact information"))
        {
            return "Resume";
        }
        
        if (text.Contains("invoice") || text.Contains("inv-") || text.Contains("invoice no") || text.Contains("invoice#"))
            return "Invoice";
        if (text.Contains("receipt") || text.Contains("payment receipt"))
            return "Receipt";
        if (text.Contains("bill") && !text.Contains("invoice"))
            return "Bill";
        if (text.Contains("purchase order") || text.Contains("po") || text.Contains("p.o."))
            return "PurchaseOrder";
        if (text.Contains("quotation") || text.Contains("quote") || text.Contains("estimate"))
            return "Quotation";
        if (text.Contains("credit note") || text.Contains("credit memo"))
            return "CreditNote";
        
        return "Document";
    }

    private void ExtractCommonFields(string text, List<string> lines, ExtractedData extractedData)
    {
        // Extract invoice/document number
        var invoicePatterns = new[]
        {
            @"(?:invoice|inv|doc|document)[\s\-]*(?:no|number|#|num)?[\s:]*([A-Z0-9\-]+)",
            @"#\s*([A-Z0-9\-]+)",
            @"(?:number|no)[\s:]+([A-Z0-9\-]+)"
        };
        
        foreach (var pattern in invoicePatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                extractedData.Fields["documentNumber"] = match.Groups[1].Value.Trim();
                break;
            }
        }

        // Extract date
        var datePatterns = new[]
        {
            @"(?:date|dated|issue date|invoice date)[\s:]*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})",
            @"(?:date|dated|issue date|invoice date)[\s:]*(\d{4}[-/]\d{1,2}[-/]\d{1,2})",
            @"(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})",
            @"(\d{4}[-/]\d{1,2}[-/]\d{1,2})"
        };
        
        foreach (var pattern in datePatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                extractedData.Fields["date"] = match.Groups[1].Value;
                break;
            }
        }

        // Extract due date
        var dueDatePattern = @"(?:due date|due|payment due)[\s:]*(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})";
        var dueDateMatch = Regex.Match(text, dueDatePattern, RegexOptions.IgnoreCase);
        if (dueDateMatch.Success)
        {
            extractedData.Fields["dueDate"] = dueDateMatch.Groups[1].Value;
        }

        // Extract GST/Tax numbers
        var gstPatterns = new[]
        {
            @"(?:gst|g\.s\.t\.|tax id)[\s:]*(\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1})",
            @"(\d{2}[A-Z]{5}\d{4}[A-Z]{1}[A-Z\d]{1}[Z]{1}[A-Z\d]{1})"
        };
        
        foreach (var pattern in gstPatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                extractedData.Fields["gstNumber"] = match.Groups.Count > 1 ? match.Groups[1].Value : match.Value;
                break;
            }
        }

        // Extract amounts - find all currency values
        var amountPatterns = new[]
        {
            @"(?:total|amount|sum|grand total|net amount)[\s:]*[₹$€£]?\s*(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})?)",
            @"[₹$€£]\s*(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})?)",
            @"(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})?)\s*[₹$€£]"
        };
        
        var amounts = new List<decimal>();
        foreach (var pattern in amountPatterns)
        {
            var matches = Regex.Matches(text, pattern, RegexOptions.IgnoreCase);
            foreach (Match match in matches)
            {
                var amountStr = match.Groups[1].Value.Replace(",", "").Replace(" ", "");
                if (decimal.TryParse(amountStr, out var amount) && amount > 0)
                {
                    amounts.Add(amount);
                }
            }
        }
        
        if (amounts.Any())
        {
            extractedData.Fields["totalAmount"] = amounts.Max();
            extractedData.Fields["subtotal"] = amounts.Count > 1 ? amounts.OrderByDescending(a => a).Skip(1).FirstOrDefault() : amounts.Max();
        }

        // Extract tax amount
        var taxPattern = @"(?:tax|gst|vat)[\s:]*[₹$€£]?\s*(\d{1,3}(?:[,\s]\d{3})*(?:\.\d{2})?)";
        var taxMatch = Regex.Match(text, taxPattern, RegexOptions.IgnoreCase);
        if (taxMatch.Success)
        {
            var taxStr = taxMatch.Groups[1].Value.Replace(",", "").Replace(" ", "");
            if (decimal.TryParse(taxStr, out var tax))
            {
                extractedData.Fields["taxAmount"] = tax;
            }
        }
    }

    private void ExtractVendorInfo(string text, List<string> lines, ExtractedData extractedData)
    {
        // Extract vendor name (usually in first few lines)
        var vendorPatterns = new[]
        {
            @"(?:from|vendor|supplier|seller|company|business name)[\s:]+([A-Z][A-Za-z0-9\s&.,\-]+)",
            @"^([A-Z][A-Za-z0-9\s&.,\-]{3,})" // First capitalized line
        };

        foreach (var pattern in vendorPatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase | RegexOptions.Multiline);
            if (match.Success)
            {
                var vendorName = match.Groups[1].Value.Trim();
                if (vendorName.Length > 3 && vendorName.Length < 100)
                {
                    extractedData.Fields["vendorName"] = vendorName;
                    break;
                }
            }
        }

        // Extract vendor address
        var addressPattern = @"(?:address|location)[\s:]+([A-Za-z0-9\s,.\-]+)";
        var addressMatch = Regex.Match(text, addressPattern, RegexOptions.IgnoreCase);
        if (addressMatch.Success)
        {
            extractedData.Fields["vendorAddress"] = addressMatch.Groups[1].Value.Trim();
        }

        // Extract vendor contact
        var phonePattern = @"(?:phone|tel|mobile|contact)[\s:]*([+]?[\d\s\-()]+)";
        var phoneMatch = Regex.Match(text, phonePattern, RegexOptions.IgnoreCase);
        if (phoneMatch.Success)
        {
            extractedData.Fields["vendorPhone"] = phoneMatch.Groups[1].Value.Trim();
        }

        var emailPattern = @"([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})";
        var emailMatch = Regex.Match(text, emailPattern);
        if (emailMatch.Success)
        {
            extractedData.Fields["vendorEmail"] = emailMatch.Value;
        }
    }

    private void ExtractCustomerInfo(string text, List<string> lines, ExtractedData extractedData)
    {
        var customerPatterns = new[]
        {
            @"(?:to|bill to|customer|client|buyer)[\s:]+([A-Z][A-Za-z0-9\s&.,\-]+)",
            @"(?:ship to|shipping address)[\s:]+([A-Z][A-Za-z0-9\s&.,\-]+)"
        };

        foreach (var pattern in customerPatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase | RegexOptions.Multiline);
            if (match.Success)
            {
                var customerName = match.Groups[1].Value.Trim();
                if (customerName.Length > 3 && customerName.Length < 100)
                {
                    extractedData.Fields["customerName"] = customerName;
                    break;
                }
            }
        }
    }

    private void ExtractLineItems(string text, List<string> lines, List<TextBlock> textBlocks, ExtractedData extractedData)
    {
        var items = new List<Dictionary<string, object>>();
        
        // Look for table-like structures with quantity, description, price
        var itemPattern = @"(\d+)\s+([A-Za-z0-9\s\-]+?)\s+[₹$€£]?\s*(\d+(?:\.\d{2})?)";
        var matches = Regex.Matches(text, itemPattern, RegexOptions.IgnoreCase);
        
        foreach (Match match in matches)
        {
            if (decimal.TryParse(match.Groups[1].Value, out var qty) &&
                decimal.TryParse(match.Groups[3].Value, out var price))
            {
                var item = new Dictionary<string, object>
                {
                    ["quantity"] = qty,
                    ["description"] = match.Groups[2].Value.Trim(),
                    ["price"] = price,
                    ["total"] = qty * price
                };
                items.Add(item);
            }
        }

        if (items.Any())
        {
            extractedData.Fields["items"] = items;
        }
    }

    private List<TableData> ExtractTables(List<TextBlock> textBlocks)
    {
        var tables = new List<TableData>();
        
        if (textBlocks.Count < 3) return tables;

        // Group text blocks by Y position to detect rows (with tolerance)
        var tolerance = 10; // pixels
        var rows = new List<List<TextBlock>>();
        var currentRow = new List<TextBlock> { textBlocks[0] };

        for (int i = 1; i < textBlocks.Count; i++)
        {
            var prevY = textBlocks[i - 1].BoundingBox.Y;
            var currY = textBlocks[i].BoundingBox.Y;

            if (Math.Abs(currY - prevY) <= tolerance)
            {
                // Same row
                currentRow.Add(textBlocks[i]);
            }
            else
            {
                // New row
                if (currentRow.Count > 0)
                {
                    rows.Add(currentRow);
                }
                currentRow = new List<TextBlock> { textBlocks[i] };
            }
        }
        if (currentRow.Count > 0)
        {
            rows.Add(currentRow);
        }

        // Detect tables (multiple rows with similar structure)
        if (rows.Count >= 2)
        {
            var table = new TableData();
            
            // First row as potential headers
            if (rows.Count > 0)
            {
                table.Headers = rows[0]
                    .OrderBy(tb => tb.BoundingBox.X)
                    .Select(tb => tb.Text.Trim())
                    .Where(t => !string.IsNullOrWhiteSpace(t))
                    .ToList();
            }

            // Remaining rows as data
            foreach (var row in rows.Skip(1))
            {
                var rowData = row
                    .OrderBy(tb => tb.BoundingBox.X)
                    .Select(tb => tb.Text.Trim())
                    .Where(t => !string.IsNullOrWhiteSpace(t))
                    .ToList();
                
                if (rowData.Any() && rowData.Count >= table.Headers.Count / 2) // At least half the columns
                {
                    table.Rows.Add(rowData);
                }
            }

            if (table.Headers.Any() || table.Rows.Any())
            {
                tables.Add(table);
            }
        }

        return tables;
    }

    private void ExtractResumeInfo(string text, List<string> lines, ExtractedData extractedData)
    {
        // Extract name (usually first line or after "name:")
        var namePatterns = new[]
        {
            @"(?:name|full name)[\s:]+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)",
            @"^([A-Z][a-z]+\s+[A-Z][a-z]+)" // First line with capitalized words
        };

        foreach (var pattern in namePatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase | RegexOptions.Multiline);
            if (match.Success)
            {
                var name = match.Groups[1].Value.Trim();
                if (name.Length > 3 && name.Length < 50 && !name.Contains("Resume") && !name.Contains("CV"))
                {
                    extractedData.Fields["name"] = name;
                    break;
                }
            }
        }

        // Extract email
        var emailPattern = @"([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})";
        var emailMatch = Regex.Match(text, emailPattern);
        if (emailMatch.Success)
        {
            extractedData.Fields["email"] = emailMatch.Value;
        }

        // Extract phone
        var phonePatterns = new[]
        {
            @"(?:phone|mobile|tel|contact)[\s:]*([+]?[\d\s\-()]+)",
            @"(\+?\d{1,3}[-.\s]?\(?\d{1,4}\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9})"
        };

        foreach (var pattern in phonePatterns)
        {
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase);
            if (match.Success)
            {
                var phone = match.Groups[1].Value.Trim();
                if (phone.Length >= 10)
                {
                    extractedData.Fields["phone"] = phone;
                    break;
                }
            }
        }

        // Extract address
        var addressPattern = @"(?:address|location)[\s:]+([A-Za-z0-9\s,.\-]+)";
        var addressMatch = Regex.Match(text, addressPattern, RegexOptions.IgnoreCase);
        if (addressMatch.Success)
        {
            extractedData.Fields["address"] = addressMatch.Groups[1].Value.Trim();
        }

        // Extract skills
        var skillsSection = ExtractSection(text, new[] { "skills", "technical skills", "core competencies", "expertise" });
        if (!string.IsNullOrEmpty(skillsSection))
        {
            var skills = skillsSection.Split(new[] { ',', ';', '\n', '•', '-' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(s => s.Trim())
                .Where(s => s.Length > 2 && s.Length < 50)
                .ToList();
            if (skills.Any())
            {
                extractedData.Fields["skills"] = skills;
            }
        }

        // Extract experience/employment
        var experienceSection = ExtractSection(text, new[] { "experience", "work experience", "employment", "employment history", "professional experience" });
        if (!string.IsNullOrEmpty(experienceSection))
        {
            extractedData.Fields["experience"] = experienceSection;
        }

        // Extract education
        var educationSection = ExtractSection(text, new[] { "education", "academic", "qualifications", "educational background" });
        if (!string.IsNullOrEmpty(educationSection))
        {
            extractedData.Fields["education"] = educationSection;
        }

        // Extract objective/summary
        var objectiveSection = ExtractSection(text, new[] { "objective", "summary", "professional summary", "profile", "about" });
        if (!string.IsNullOrEmpty(objectiveSection))
        {
            extractedData.Fields["summary"] = objectiveSection;
        }

        // Extract linkedin
        var linkedinPattern = @"(?:linkedin|linkedin\.com)[\s:]*([a-zA-Z0-9\-/]+)";
        var linkedinMatch = Regex.Match(text, linkedinPattern, RegexOptions.IgnoreCase);
        if (linkedinMatch.Success)
        {
            extractedData.Fields["linkedin"] = linkedinMatch.Groups[1].Value.Trim();
        }

        // Extract years of experience
        var yearsPattern = @"(\d+)\s*(?:years?|yrs?)\s*(?:of\s*)?(?:experience|exp)";
        var yearsMatch = Regex.Match(text, yearsPattern, RegexOptions.IgnoreCase);
        if (yearsMatch.Success && int.TryParse(yearsMatch.Groups[1].Value, out var years))
        {
            extractedData.Fields["yearsOfExperience"] = years;
        }
    }

    private string ExtractSection(string text, string[] sectionKeywords)
    {
        foreach (var keyword in sectionKeywords)
        {
            var pattern = $@"{keyword}[\s:]*\n?([^\n]*(?:\n(?!\s*(?:{string.Join("|", sectionKeywords)}|$))[^\n]*)*)";
            var match = Regex.Match(text, pattern, RegexOptions.IgnoreCase | RegexOptions.Multiline);
            if (match.Success)
            {
                var section = match.Groups[1].Value.Trim();
                if (section.Length > 10)
                {
                    return section;
                }
            }
        }
        return string.Empty;
    }

    private void ExtractMetadata(string text, ExtractedData extractedData)
    {
        // Only extract metadata for non-resume documents
        if (extractedData.DocumentType == "Resume" || extractedData.DocumentType == "CV")
        {
            return;
        }

        // Extract payment terms
        var termsPattern = @"(?:terms|payment terms)[\s:]+([A-Za-z0-9\s]+)";
        var termsMatch = Regex.Match(text, termsPattern, RegexOptions.IgnoreCase);
        if (termsMatch.Success)
        {
            extractedData.Fields["paymentTerms"] = termsMatch.Groups[1].Value.Trim();
        }

        // Extract payment method
        var paymentMethodPattern = @"(?:payment method|paid by|payment via)[\s:]+([A-Za-z\s]+)";
        var paymentMatch = Regex.Match(text, paymentMethodPattern, RegexOptions.IgnoreCase);
        if (paymentMatch.Success)
        {
            extractedData.Fields["paymentMethod"] = paymentMatch.Groups[1].Value.Trim();
        }

        // Extract reference numbers
        var refPattern = @"(?:ref|reference|po number)[\s:]+([A-Z0-9\-]+)";
        var refMatch = Regex.Match(text, refPattern, RegexOptions.IgnoreCase);
        if (refMatch.Success)
        {
            extractedData.Fields["referenceNumber"] = refMatch.Groups[1].Value.Trim();
        }
    }
}
