namespace Backend.Models;

public class OcrResult
{
    public List<TextBlock> TextBlocks { get; set; } = new();
    public string FullText { get; set; } = string.Empty;
}

public class TextBlock
{
    public string Text { get; set; } = string.Empty;
    public BoundingBox BoundingBox { get; set; } = new();
    public double Confidence { get; set; }
}

public class BoundingBox
{
    public int X { get; set; }
    public int Y { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }
}

