namespace Backend.Models;

public class ExtractedData
{
    public string DocumentType { get; set; } = "Unknown";
    public Dictionary<string, object> Fields { get; set; } = new();
    public List<TableData> Tables { get; set; } = new();
    public string RawText { get; set; } = string.Empty;
}

public class TableData
{
    public List<string> Headers { get; set; } = new();
    public List<List<string>> Rows { get; set; } = new();
}

