import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { OcrService } from './services/ocr.service';
import { ExtractedData } from './models/extracted-data.model';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'OCR PDF Data Extraction';
  selectedFile: File | null = null;
  extractedData: ExtractedData | null = null;
  isLoading = false;
  error: string | null = null;
  progress = 0;
  showJson = false;

  constructor(private ocrService: OcrService) {}

  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
      this.error = null;
      this.extractedData = null;
    }
  }

  onDragOver(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    const uploadArea = event.currentTarget as HTMLElement;
    uploadArea.classList.add('dragover');
  }

  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    const uploadArea = event.currentTarget as HTMLElement;
    uploadArea.classList.remove('dragover');
  }

  onDrop(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    const uploadArea = event.currentTarget as HTMLElement;
    uploadArea.classList.remove('dragover');

    if (event.dataTransfer?.files && event.dataTransfer.files.length > 0) {
      const file = event.dataTransfer.files[0];
      if (file.type === 'application/pdf') {
        this.selectedFile = file;
        this.error = null;
        this.extractedData = null;
      } else {
        this.error = 'Please upload a PDF file';
      }
    }
  }

  uploadFile(): void {
    if (!this.selectedFile) {
      this.error = 'Please select a PDF file';
      return;
    }

    this.isLoading = true;
    this.error = null;
    this.extractedData = null;
    this.progress = 0;

    // Simulate progress
    const progressInterval = setInterval(() => {
      if (this.progress < 90) {
        this.progress += 10;
      }
    }, 200);

    this.ocrService.extractData(this.selectedFile).subscribe({
      next: (data) => {
        clearInterval(progressInterval);
        this.progress = 100;
        this.extractedData = data;
        this.isLoading = false;
      },
      error: (err) => {
        clearInterval(progressInterval);
        this.isLoading = false;
        this.error = err.error?.error || err.message || 'An error occurred while processing the PDF';
        this.progress = 0;
      }
    });
  }

  downloadJson(): void {
    if (!this.extractedData) return;

    const jsonStr = JSON.stringify(this.extractedData, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `extracted-data-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }

  getFieldValue(key: string): any {
    return this.extractedData?.fields?.[key] || 'N/A';
  }

  getFieldKeys(): string[] {
    if (!this.extractedData?.fields) return [];
    
    const allKeys = Object.keys(this.extractedData.fields);
    const docType = this.extractedData.documentType;
    
    // Filter based on document type
    if (docType === 'Receipt') {
      // For receipts, show all fields including vendor
      return allKeys;
    } else if (docType === 'Resume' || docType === 'CV') {
      // For resumes, show all fields (no vendor)
      return allKeys;
    } else {
      // For other documents, exclude vendor fields unless it's an invoice/bill
      return allKeys.filter(key => 
        !key.toLowerCase().includes('vendor') || 
        docType === 'Invoice' || 
        docType === 'Bill'
      );
    }
  }

  formatFieldValue(key: string, value: any): string {
    if (Array.isArray(value)) {
      return value.join(', ');
    }
    if (typeof value === 'object' && value !== null) {
      return JSON.stringify(value, null, 2);
    }
    return String(value);
  }

  formatFieldLabel(key: string): string {
    // Convert camelCase to Title Case
    return key
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, str => str.toUpperCase())
      .trim();
  }

  getFieldIcon(key: string): string {
    const keyLower = key.toLowerCase();
    if (keyLower.includes('name')) return '👤';
    if (keyLower.includes('email')) return '📧';
    if (keyLower.includes('phone')) return '📞';
    if (keyLower.includes('address')) return '📍';
    if (keyLower.includes('date')) return '📅';
    if (keyLower.includes('amount') || keyLower.includes('total') || keyLower.includes('price')) return '💰';
    if (keyLower.includes('invoice') || keyLower.includes('document')) return '📄';
    if (keyLower.includes('vendor') || keyLower.includes('supplier')) return '🏢';
    if (keyLower.includes('customer') || keyLower.includes('client')) return '👥';
    if (keyLower.includes('skills')) return '⚡';
    if (keyLower.includes('experience')) return '💼';
    if (keyLower.includes('education')) return '🎓';
    if (keyLower.includes('summary') || keyLower.includes('objective')) return '📝';
    if (keyLower.includes('linkedin')) return '💼';
    if (keyLower.includes('gst') || keyLower.includes('tax')) return '🧾';
    return '📋';
  }

  toggleJsonViewer(): void {
    this.showJson = !this.showJson;
  }
}

