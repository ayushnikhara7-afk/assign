import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ExtractedData } from '../models/extracted-data.model';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class OcrService {
  private apiUrl = environment.apiUrl;

  constructor(private http: HttpClient) {}

  extractData(file: File): Observable<ExtractedData> {
    const formData = new FormData();
    formData.append('file', file);

    return this.http.post<ExtractedData>(`${this.apiUrl}/api/ocr/extract`, formData);
  }
}

