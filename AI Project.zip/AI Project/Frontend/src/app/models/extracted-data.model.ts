export interface ExtractedData {
  documentType: string;
  fields: { [key: string]: any };
  tables: TableData[];
  rawText: string;
}

export interface TableData {
  headers: string[];
  rows: string[][];
}

