# Flight Booking Unit Tests

This project contains comprehensive unit tests for the Flight Booking Application.

## 🧪 Test Structure

### Test Files

1. **BookingServiceTests.cs** - Tests the business logic layer
   - CreateBooking with valid/invalid data
   - GetBookingByReference
   - Reference number generation
   
2. **BookingApiControllerTests.cs** - Tests the API controller layer
   - SearchFlights endpoint
   - CreateBooking endpoint
   - Response validation
   
3. **BookingRepositoryTests.cs** - Tests the data access layer
   - Add booking
   - Get booking by reference
   - Get booking with flight details
   - Update booking

## 📦 Dependencies

- **NUnit 4.0.1** - Testing framework
- **Moq 4.20.70** - Mocking library
- **Microsoft.NET.Test.Sdk** - Test runner
- **Microsoft.EntityFrameworkCore.InMemory** - In-memory database for repository tests

## 🚀 Running the Tests

### Using Visual Studio
1. Open the solution in Visual Studio
2. Open Test Explorer (Test → Test Explorer)
3. Click "Run All Tests"

### Using Visual Studio Code
1. Install the .NET Core Test Explorer extension
2. Open the test explorer
3. Click the play button to run tests

### Using Command Line
```bash
# Navigate to test project directory
cd Flightbooking.test

# Restore packages
dotnet restore

# Build the test project
dotnet build

# Run all tests
dotnet test

# Run tests with detailed output
dotnet test --logger "console;verbosity=detailed"

# Run tests with code coverage
dotnet test /p:CollectCoverage=true
```

### Using Test Explorer in Visual Studio
```bash
# Run specific test
dotnet test --filter "FullyQualifiedName~BookingServiceTests.CreateBooking_WithValidRequest_ReturnsBooking"

# Run all tests in a class
dotnet test --filter "FullyQualifiedName~BookingServiceTests"
```

## 📊 Test Coverage

### BookingServiceTests (7 tests)
✅ CreateBooking_WithValidRequest_ReturnsBooking
✅ CreateBooking_WithInvalidFlightId_ThrowsArgumentException
✅ CreateBooking_GeneratesUniqueReferenceNumber
✅ GetBookingByReference_WithValidReference_ReturnsBooking
✅ GetBookingByReference_WithInvalidReference_ReturnsNull

### BookingApiControllerTests (5 tests)
✅ SearchFlights_WithValidRequest_ReturnsOkWithFlightList
✅ SearchFlights_WithNoResults_ReturnsOkWithEmptyList
✅ CreateBooking_WithValidRequest_ReturnsOkWithBooking
✅ CreateBooking_WithCompleteDetails_ReturnsBookingWithAllFields
✅ CreateBooking_ServiceThrowsException_ExceptionPropagates

### BookingRepositoryTests (11 tests)
✅ Add_ValidBooking_SavesAndReturnsBooking
✅ Add_MultipleBookings_SavesAll
✅ GetByReferenceNumber_ExistingReference_ReturnsBooking
✅ GetByReferenceNumber_NonExistingReference_ReturnsNull
✅ GetByReferenceNumber_CaseSensitive_ReturnsCorrectBooking
✅ GetBookingWithFlight_ExistingReference_ReturnsBookingWithFlight
✅ GetBookingWithFlight_NonExistingReference_ReturnsNull
✅ GetBookingWithFlight_CheckedInBooking_ReturnsWithAllDetails
✅ Update_ExistingBooking_UpdatesSuccessfully
✅ Update_MultipleFields_UpdatesAll

**Total: 23 Unit Tests**

## 🔍 Understanding the Tests

### Test Anatomy

Each test follows the **AAA pattern**:
- **Arrange**: Set up test data and mocks
- **Act**: Execute the method being tested
- **Assert**: Verify the results

Example:
```csharp
[Test]
public void CreateBooking_WithValidRequest_ReturnsBooking()
{
    // Arrange - Set up test data
    var request = new BookingRequest { ... };
    _mockFlightRepo.Setup(r => r.GetById(1)).Returns(flight);
    
    // Act - Call the method
    var result = _bookingService.CreateBooking(request);
    
    // Assert - Verify results
    Assert.IsNotNull(result);
    Assert.AreEqual("John", result.FirstName);
}
```

### Mocking with Moq

Tests use Moq to create mock objects:
```csharp
// Create mock
var mockService = new Mock<IBookingService>();

// Setup behavior
mockService
    .Setup(s => s.CreateBooking(It.IsAny<BookingRequest>()))
    .Returns(expectedBooking);

// Verify method was called
mockService.Verify(s => s.CreateBooking(It.IsAny<BookingRequest>()), Times.Once);
```

### In-Memory Database

Repository tests use EF Core In-Memory database:
```csharp
var options = new DbContextOptionsBuilder<FlightDbContext>()
    .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
    .Options;

var context = new FlightDbContext(options);
```

## 🎯 Best Practices Demonstrated

1. **Isolation**: Each test is independent
2. **Setup/Teardown**: `[SetUp]` and `[TearDown]` for initialization and cleanup
3. **Descriptive Names**: Method names describe what is being tested
4. **Single Responsibility**: Each test checks one thing
5. **Mocking**: External dependencies are mocked
6. **Verification**: Both results and method calls are verified

## 📝 Adding New Tests

To add a new test:

1. Create a test method with `[Test]` attribute
2. Follow the AAA pattern
3. Use descriptive naming: `MethodName_Scenario_ExpectedResult`
4. Add to appropriate test class or create new test file

Example:
```csharp
[Test]
public void CancelBooking_WithValidReference_SetsStatusToCancelled()
{
    // Arrange
    var referenceNumber = "ABC123";
    var booking = new Booking { ReferenceNumber = referenceNumber };
    _mockBookingRepo.Setup(r => r.GetByReferenceNumber(referenceNumber))
        .Returns(booking);
    
    // Act
    var result = _bookingService.CancelBooking(referenceNumber);
    
    // Assert
    Assert.IsTrue(result.IsCancelled);
}
```

## 🐛 Troubleshooting

### Common Issues

**Issue**: Tests not discovered
- **Solution**: Rebuild the solution

**Issue**: NuGet packages not restored
- **Solution**: Run `dotnet restore`

**Issue**: Tests failing unexpectedly
- **Solution**: Check that mocks are properly configured

**Issue**: In-memory database conflicts
- **Solution**: Each test uses unique database name (Guid.NewGuid())

## 📚 Further Reading

- [NUnit Documentation](https://docs.nunit.org/)
- [Moq Quickstart](https://github.com/moq/moq4/wiki/Quickstart)
- [Unit Testing Best Practices](https://docs.microsoft.com/en-us/dotnet/core/testing/unit-testing-best-practices)
- [EF Core In-Memory Testing](https://docs.microsoft.com/en-us/ef/core/testing/)

## ✅ Test Status

All tests should pass. If any test fails, check:
1. All dependencies are properly mocked
2. Test data is correctly set up
3. The implementation hasn't changed

---
**Last Updated**: October 2025

