# Unit Testing Examples & Best Practices

This document provides examples and explanations for unit testing in the Flight Booking project.

## 📖 Table of Contents

1. [What is Unit Testing?](#what-is-unit-testing)
2. [Why Unit Testing?](#why-unit-testing)
3. [Testing Layers](#testing-layers)
4. [Mocking Explained](#mocking-explained)
5. [Test Examples](#test-examples)
6. [Common Patterns](#common-patterns)

## What is Unit Testing?

Unit testing is a method of testing individual units of code (like methods or classes) in isolation to ensure they work correctly.

### Key Characteristics:
- **Fast**: Run in milliseconds
- **Isolated**: Don't depend on external resources (databases, APIs, files)
- **Repeatable**: Same result every time
- **Self-checking**: Pass or fail automatically

## Why Unit Testing?

✅ **Catch Bugs Early**: Find issues before production  
✅ **Documentation**: Tests show how code should work  
✅ **Refactoring Safety**: Change code confidently  
✅ **Better Design**: Forces you to write testable code  
✅ **Regression Prevention**: Ensure old features still work  

## Testing Layers

Our application has 3 layers, each tested differently:

```
┌─────────────────────────────────────┐
│     Controller Layer (API)          │ ← BookingApiControllerTests
│  Tests HTTP responses & routing     │
├─────────────────────────────────────┤
│     Service Layer (Business Logic)  │ ← BookingServiceTests
│  Tests business rules & validation  │
├─────────────────────────────────────┤
│  Repository Layer (Data Access)     │ ← BookingRepositoryTests
│  Tests database operations          │
└─────────────────────────────────────┘
```

## Mocking Explained

**Mocking** = Creating fake objects that simulate real dependencies

### Why Mock?

Real dependencies are problematic in tests:
- **Databases**: Slow, need setup, can have side effects
- **APIs**: Unreliable, cost money, need network
- **File System**: Slow, can fail

### How Moq Works

```csharp
// 1. Create a mock object
var mockService = new Mock<IBookingService>();

// 2. Define behavior (what it should return)
mockService
    .Setup(s => s.CreateBooking(It.IsAny<BookingRequest>()))
    .Returns(new Booking { ReferenceNumber = "ABC123" });

// 3. Use the mock in your test
var controller = new BookingApiController(mockService.Object);

// 4. Verify it was called correctly
mockService.Verify(s => s.CreateBooking(It.IsAny<BookingRequest>()), Times.Once);
```

### Moq Setup Options

```csharp
// Return a value
.Setup(s => s.GetBooking(123))
.Returns(booking);

// Return different values on successive calls
.SetupSequence(s => s.GetBooking(123))
.Returns(booking1)
.Returns(booking2);

// Throw exception
.Setup(s => s.CreateBooking(It.IsAny<BookingRequest>()))
.Throws(new ArgumentException("Invalid flight"));

// Match specific parameter
.Setup(s => s.GetBooking(It.Is<int>(id => id > 0)))
.Returns(booking);

// Capture parameter for inspection
BookingRequest captured = null;
.Setup(s => s.CreateBooking(It.IsAny<BookingRequest>()))
.Callback<BookingRequest>(req => captured = req)
.Returns(booking);
```

## Test Examples

### Example 1: Testing Service Layer

**What we're testing**: Business logic in `BookingService.CreateBooking()`

**Challenge**: Service depends on repositories (database access)

**Solution**: Mock the repositories!

```csharp
[Test]
public void CreateBooking_WithValidRequest_ReturnsBooking()
{
    // ARRANGE: Set up test data and mocks
    var request = new BookingRequest
    {
        FlightId = 1,
        FirstName = "John",
        LastName = "Doe",
        Gender = "M"
    };

    // Create a fake flight (as if it came from database)
    var flight = new Flight { Id = 1, FlightNumber = "FL001" };
    
    // Create expected booking result
    var expectedBooking = new Booking
    {
        ReferenceNumber = "ABC123",
        FirstName = "John",
        LastName = "Doe"
    };

    // Mock: When GetById(1) is called, return our fake flight
    _mockFlightRepo
        .Setup(r => r.GetById(1))
        .Returns(flight);

    // Mock: When Add is called, return our expected booking
    _mockBookingRepo
        .Setup(r => r.Add(It.IsAny<Booking>()))
        .Returns(expectedBooking);

    // ACT: Call the method we're testing
    var result = _bookingService.CreateBooking(request);

    // ASSERT: Verify the results
    Assert.IsNotNull(result);
    Assert.AreEqual("John", result.FirstName);
    Assert.AreEqual("Doe", result.LastName);
    
    // Verify the mocks were called correctly
    _mockFlightRepo.Verify(r => r.GetById(1), Times.Once);
    _mockBookingRepo.Verify(r => r.Add(It.IsAny<Booking>()), Times.Once);
}
```

**What this test proves:**
✅ Service calls repository to check if flight exists  
✅ Service creates booking with correct data  
✅ Service returns the created booking  

### Example 2: Testing Error Handling

**What we're testing**: Service throws exception when flight doesn't exist

```csharp
[Test]
public void CreateBooking_WithInvalidFlightId_ThrowsArgumentException()
{
    // ARRANGE: Set up invalid scenario
    var request = new BookingRequest
    {
        FlightId = 999, // Non-existent flight
        FirstName = "John",
        LastName = "Doe"
    };

    // Mock: Return null (flight not found)
    _mockFlightRepo
        .Setup(r => r.GetById(999))
        .Returns((Flight?)null);

    // ACT & ASSERT: Expect exception to be thrown
    var ex = Assert.Throws<ArgumentException>(
        () => _bookingService.CreateBooking(request)
    );
    
    Assert.That(ex.Message, Is.EqualTo("Flight not found"));
    
    // Verify: Booking should NEVER be created
    _mockBookingRepo.Verify(
        r => r.Add(It.IsAny<Booking>()), 
        Times.Never
    );
}
```

**What this test proves:**
✅ Service validates flight exists  
✅ Service throws meaningful error  
✅ Service doesn't create booking for invalid flight  

### Example 3: Testing Controller

**What we're testing**: Controller returns correct HTTP response

```csharp
[Test]
public void CreateBooking_WithValidRequest_ReturnsOkWithBooking()
{
    // ARRANGE
    var request = new BookingRequest
    {
        FlightId = 1,
        FirstName = "John",
        LastName = "Doe"
    };

    var expectedBooking = new Booking
    {
        ReferenceNumber = "ABC123",
        FirstName = "John"
    };

    // Mock the service layer
    _mockBookingService
        .Setup(s => s.CreateBooking(It.IsAny<BookingRequest>()))
        .Returns(expectedBooking);

    // ACT: Call controller method
    var result = _controller.CreateBooking(request);

    // ASSERT: Check HTTP response
    Assert.IsInstanceOf<OkObjectResult>(result); // 200 OK
    
    var okResult = result as OkObjectResult;
    Assert.AreEqual(200, okResult.StatusCode);
    
    // Check response body
    var booking = okResult.Value as Booking;
    Assert.IsNotNull(booking);
    Assert.AreEqual("ABC123", booking.ReferenceNumber);
}
```

**What this test proves:**
✅ Controller returns HTTP 200  
✅ Controller returns booking in response  
✅ Controller calls service correctly  

### Example 4: Testing Repository with In-Memory Database

**What we're testing**: Database operations

**Challenge**: We need a database

**Solution**: Use EF Core In-Memory database (fake database in RAM)

```csharp
[SetUp]
public void Setup()
{
    // Create new in-memory database for each test
    var options = new DbContextOptionsBuilder<FlightDbContext>()
        .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString())
        .Options;

    _context = new FlightDbContext(options);
    _repository = new BookingRepository(_context);
    
    // Add test data
    _context.Flights.Add(new Flight 
    { 
        Id = 1, 
        FlightNumber = "FL001" 
    });
    _context.SaveChanges();
}

[Test]
public void Add_ValidBooking_SavesAndReturnsBooking()
{
    // ARRANGE
    var newBooking = new Booking
    {
        ReferenceNumber = "REF001",
        FlightId = 1,
        FirstName = "Bob",
        LastName = "Johnson"
    };

    // ACT: Save to database
    var result = _repository.Add(newBooking);

    // ASSERT: Check it was saved
    Assert.IsNotNull(result);
    Assert.Greater(result.Id, 0); // ID should be assigned
    
    // Verify it's actually in the database
    var savedBooking = _context.Bookings.Find(result.Id);
    Assert.IsNotNull(savedBooking);
    Assert.AreEqual("Bob", savedBooking.FirstName);
}
```

**What this test proves:**
✅ Repository saves to database  
✅ Database generates ID  
✅ Data persists correctly  

## Common Patterns

### 1. Test Fixture Pattern

Use `[TestFixture]` to mark test classes and `[SetUp]`/`[TearDown]` for setup/cleanup:

```csharp
[TestFixture]
public class BookingServiceTests
{
    private Mock<IBookingRepository> _mockRepo;
    private BookingService _service;

    [SetUp]
    public void Setup()
    {
        // Runs before each test
        _mockRepo = new Mock<IBookingRepository>();
        _service = new BookingService(_mockRepo.Object);
    }

    [TearDown]
    public void TearDown()
    {
        // Runs after each test
        _service = null;
        _mockRepo = null;
    }

    [Test]
    public void MyTest()
    {
        // Test code here
    }
}
```

### 2. AAA Pattern (Arrange-Act-Assert)

Every test should follow this structure:

```csharp
[Test]
public void TestMethod()
{
    // ARRANGE: Set up test data and environment
    var input = "test";
    var expected = "expected result";
    
    // ACT: Execute the code being tested
    var result = _service.DoSomething(input);
    
    // ASSERT: Verify the result
    Assert.AreEqual(expected, result);
}
```

### 3. Test Naming Convention

Use descriptive names: `MethodName_Scenario_ExpectedResult`

```csharp
CreateBooking_WithValidData_ReturnsBooking         // ✅ Good
CreateBooking_WithInvalidFlight_ThrowsException    // ✅ Good
CreateBooking_NullRequest_ThrowsArgumentNull       // ✅ Good

Test1()                                            // ❌ Bad
TestCreateBooking()                                // ❌ Bad
CreateBookingTest()                                // ❌ Bad
```

### 4. Assertion Patterns

```csharp
// Basic assertions
Assert.IsNotNull(result);
Assert.IsNull(result);
Assert.IsTrue(condition);
Assert.IsFalse(condition);

// Equality
Assert.AreEqual(expected, actual);
Assert.AreNotEqual(value1, value2);

// Type checking
Assert.IsInstanceOf<Booking>(result);

// Collections
Assert.IsEmpty(list);
Assert.IsNotEmpty(list);
Assert.Contains(item, collection);

// Strings
Assert.That(text, Is.EqualTo("expected"));
Assert.That(text, Does.Contain("substring"));
Assert.That(text, Does.StartWith("prefix"));

// Numbers
Assert.Greater(5, 3);
Assert.Less(3, 5);
Assert.GreaterOrEqual(5, 5);

// Exceptions
Assert.Throws<ArgumentException>(() => method());
var ex = Assert.Throws<Exception>(() => method());
Assert.That(ex.Message, Is.EqualTo("error message"));
```

## Tips for Writing Good Tests

### ✅ DO:
- Test one thing per test
- Use descriptive test names
- Keep tests simple and readable
- Test edge cases and error conditions
- Make tests independent of each other
- Use realistic test data

### ❌ DON'T:
- Test multiple things in one test
- Depend on test execution order
- Use real databases or external services
- Write tests that can randomly fail
- Copy-paste test code (use helper methods)
- Test framework code (like EF Core itself)

## Test Coverage Goals

Aim to test:
- ✅ Happy path (normal, expected usage)
- ✅ Edge cases (boundary conditions)
- ✅ Error cases (invalid input, exceptions)
- ✅ Business rules validation
- ✅ State changes

Don't need to test:
- ❌ Framework code (ASP.NET, EF Core)
- ❌ Simple getters/setters
- ❌ Auto-generated code

## Running Tests

```bash
# Run all tests
dotnet test

# Run specific test
dotnet test --filter "FullyQualifiedName~CreateBooking_WithValidRequest"

# Run all tests in a class
dotnet test --filter "ClassName~BookingServiceTests"

# Run with detailed output
dotnet test --logger "console;verbosity=detailed"

# Run with coverage
dotnet test /p:CollectCoverage=true
```

## Summary

| Layer | What to Test | How to Test | Example |
|-------|--------------|-------------|---------|
| **Controller** | HTTP responses, routing | Mock services | `BookingApiControllerTests` |
| **Service** | Business logic, validation | Mock repositories | `BookingServiceTests` |
| **Repository** | Data operations | In-Memory DB | `BookingRepositoryTests` |

---

**Remember**: Good tests are your safety net! They let you refactor and add features with confidence. 🚀

