# 🚀 Quick Start Guide - Unit Testing

## How to Run Your Tests

### Option 1: Visual Studio (Recommended)
1. **Open Test Explorer**
   - Go to `Test` → `Test Explorer` (or press `Ctrl+E, T`)
   
2. **Run Tests**
   - Click "Run All Tests" button (▶️)
   - Or right-click individual tests to run them

3. **View Results**
   - ✅ Green = Passed
   - ❌ Red = Failed
   - Click failed tests to see error details

### Option 2: Command Line
```bash
# Navigate to test project
cd Flightbooking.test

# Restore packages (first time only)
dotnet restore

# Build the project
dotnet build

# Run all tests
dotnet test

# Run tests with detailed output
dotnet test --logger "console;verbosity=detailed"
```

### Option 3: Visual Studio Code
1. Install **".NET Core Test Explorer"** extension
2. Tests will appear in the Test sidebar
3. Click play button (▶️) to run tests

## 📁 Project Structure

```
Flightbooking.test/
├── BookingServiceTests.cs       ← 7 tests for business logic
├── BookingApiControllerTests.cs ← 5 tests for API endpoints
├── BookingRepositoryTests.cs    ← 11 tests for data access
├── Flightbooking.test.csproj    ← Project configuration
├── README.md                     ← Full documentation
├── TestExamples.md               ← Detailed examples
└── QUICKSTART.md                 ← This file
```

## 🧪 What's Being Tested?

### ✅ BookingServiceTests (7 tests)
Tests the business logic:
- Creating bookings with valid data
- Handling invalid flight IDs
- Generating unique reference numbers
- Retrieving bookings

### ✅ BookingApiControllerTests (5 tests)
Tests the API endpoints:
- Searching for flights
- Creating bookings via HTTP
- Handling different scenarios
- Validating HTTP responses

### ✅ BookingRepositoryTests (11 tests)
Tests database operations:
- Adding bookings to database
- Retrieving bookings by reference
- Updating booking details
- Getting bookings with flight info

**Total: 23 Unit Tests**

## 🎯 Expected Output

When you run `dotnet test`, you should see:

```
Starting test execution, please wait...
A total of 1 test files matched the specified pattern.

Passed!  - Failed:     0, Passed:    23, Skipped:     0, Total:    23
```

## 🔍 Understanding Test Results

### All Tests Pass ✅
```
BookingServiceTests.CreateBooking_WithValidRequest_ReturnsBooking [PASSED]
BookingServiceTests.CreateBooking_WithInvalidFlightId_ThrowsArgumentException [PASSED]
...
```
**Meaning**: Your code works correctly!

### Some Tests Fail ❌
```
BookingServiceTests.CreateBooking_WithValidRequest_ReturnsBooking [FAILED]
  Expected: "John"
  But was:  "Jane"
```
**Meaning**: There's a bug or the test needs updating.

## 🛠️ Common Issues & Solutions

### Issue: "dotnet: command not found"
**Solution**: Install .NET SDK from https://dotnet.microsoft.com/download

### Issue: "Package restore failed"
**Solution**: Run `dotnet restore` in the test project directory

### Issue: "Cannot find FlightBookingApp reference"
**Solution**: Make sure both projects are in the same solution

### Issue: Tests not showing in Test Explorer
**Solution**: Rebuild the solution (Ctrl+Shift+B)

## 📚 Next Steps

1. **Run the tests** to ensure everything works
2. **Read README.md** for detailed documentation
3. **Check TestExamples.md** for in-depth explanations
4. **Add your own tests** as you add new features

## 💡 Pro Tips

### Run Specific Tests
```bash
# Run only BookingServiceTests
dotnet test --filter "FullyQualifiedName~BookingServiceTests"

# Run specific test
dotnet test --filter "CreateBooking_WithValidRequest_ReturnsBooking"
```

### Watch Mode (Auto-run on code change)
```bash
dotnet watch test
```

### Generate Code Coverage Report
```bash
dotnet test /p:CollectCoverage=true /p:CoverageReportFormat=html
```

## ❓ Need Help?

- **What is unit testing?** → Read `TestExamples.md`
- **How do tests work?** → Read `README.md`
- **How to write new tests?** → See examples in test files
- **Mocking confused you?** → Check mocking section in `TestExamples.md`

## 🎓 Test-Driven Development (TDD)

Try this workflow:
1. **Write test first** (it will fail - that's OK!)
2. **Write code** to make test pass
3. **Refactor** if needed
4. **Repeat**

This ensures every feature has tests!

---

**Ready to test?** Run `dotnet test` and see your 23 tests pass! 🎉

