# 🎓 How Unit Testing Works in This Project

## 🤔 What Problem Do We Solve?

**Problem**: How do you test your code without:
- Running the entire application
- Accessing a real database
- Making HTTP requests
- Depending on external services

**Solution**: Unit Testing with Mocking!

---

## 🧩 The Big Picture

### Your Application Architecture

```
User Request
    ↓
┌───────────────────────────┐
│   Controller Layer        │  ← Handles HTTP requests
│  BookingApiController     │     Returns HTTP responses
└─────────────┬─────────────┘
              ↓
┌───────────────────────────┐
│   Service Layer           │  ← Business logic
│  BookingService           │     Validation, rules
└─────────────┬─────────────┘
              ↓
┌───────────────────────────┐
│   Repository Layer        │  ← Data access
│  BookingRepository        │     Database operations
└─────────────┬─────────────┘
              ↓
        Database (SQL Server)
```

### How We Test Each Layer

```
┌─────────────────────────────────────┐
│  BookingApiControllerTests          │
│                                     │
│  Real: ✅ Controller                │
│  Mock: 🎭 IFlightService           │
│  Mock: 🎭 IBookingService          │
└─────────────────────────────────────┘
              ↓
┌─────────────────────────────────────┐
│  BookingServiceTests                │
│                                     │
│  Real: ✅ BookingService            │
│  Mock: 🎭 IFlightRepository        │
│  Mock: 🎭 IBookingRepository       │
└─────────────────────────────────────┘
              ↓
┌─────────────────────────────────────┐
│  BookingRepositoryTests             │
│                                     │
│  Real: ✅ BookingRepository         │
│  Real: ✅ In-Memory Database        │
│  Mock: ❌ Nothing (integration-ish) │
└─────────────────────────────────────┘
```

---

## 🎭 What is Mocking? (Explained Simply)

### Real World Analogy

Imagine you're testing a car's steering wheel:
- ❌ **Bad**: Build entire car, get fuel, find road → EXPENSIVE & SLOW
- ✅ **Good**: Simulate the wheels with fake ones → FAST & CHEAP

### Code Example

```csharp
// ❌ Without Mocking (BAD)
[Test]
public void CreateBooking_Test()
{
    // Need real database connection
    var dbContext = new FlightDbContext(connectionString);
    var bookingRepo = new BookingRepository(dbContext);
    var flightRepo = new FlightRepository(dbContext);
    var service = new BookingService(bookingRepo, flightRepo);
    
    // Need real data in database
    dbContext.Flights.Add(new Flight { ... });
    dbContext.SaveChanges();
    
    // Test is SLOW and depends on database
    var result = service.CreateBooking(request);
}

// ✅ With Mocking (GOOD)
[Test]
public void CreateBooking_Test()
{
    // Create fake repositories
    var mockBookingRepo = new Mock<IBookingRepository>();
    var mockFlightRepo = new Mock<IFlightRepository>();
    
    // Define what fake should return
    mockFlightRepo.Setup(r => r.GetById(1))
        .Returns(new Flight { Id = 1 });
    
    // Test is FAST and isolated
    var service = new BookingService(mockBookingRepo.Object, mockFlightRepo.Object);
    var result = service.CreateBooking(request);
}
```

---

## 📚 Real Example: Step by Step

### Scenario: Testing BookingService.CreateBooking()

**What the real method does:**
1. Check if flight exists (calls `IFlightRepository.GetById`)
2. If not found, throw exception
3. Create booking object
4. Generate unique reference number
5. Save booking (calls `IBookingRepository.Add`)
6. Return saved booking

**How we test it:**

```csharp
[Test]
public void CreateBooking_WithValidRequest_ReturnsBooking()
{
    // ========== ARRANGE ==========
    // 1. Prepare test data
    var request = new BookingRequest
    {
        FlightId = 1,
        FirstName = "John",
        LastName = "Doe",
        Gender = "M"
    };

    // 2. Create a fake flight (as if from database)
    var fakeFlight = new Flight
    {
        Id = 1,
        FlightNumber = "FL001",
        From = "NYC",
        To = "LAX"
    };

    // 3. Create expected result
    var expectedBooking = new Booking
    {
        Id = 1,
        ReferenceNumber = "ABC123",
        FirstName = "John",
        LastName = "Doe"
    };

    // 4. Setup mock repositories
    // When service calls GetById(1), return fakeFlight
    _mockFlightRepo
        .Setup(r => r.GetById(1))
        .Returns(fakeFlight);

    // When service calls Add, return expectedBooking
    _mockBookingRepo
        .Setup(r => r.Add(It.IsAny<Booking>()))
        .Returns(expectedBooking);

    // ========== ACT ==========
    // 5. Call the method we're testing
    var result = _bookingService.CreateBooking(request);

    // ========== ASSERT ==========
    // 6. Check the result
    Assert.IsNotNull(result);
    Assert.AreEqual("John", result.FirstName);
    Assert.AreEqual("Doe", result.LastName);
    
    // 7. Verify the mocks were called
    _mockFlightRepo.Verify(r => r.GetById(1), Times.Once);
    _mockBookingRepo.Verify(r => r.Add(It.IsAny<Booking>()), Times.Once);
}
```

### What Just Happened?

```
Test Execution Flow:
═══════════════════

1. Test calls:
   _bookingService.CreateBooking(request)
   
2. Service calls:
   _flightRepo.GetById(1)
   ↓
   🎭 Mock intercepts and returns fakeFlight
   
3. Service creates booking and calls:
   _bookingRepo.Add(booking)
   ↓
   🎭 Mock intercepts and returns expectedBooking
   
4. Service returns result
   
5. Test verifies:
   ✅ Result is not null
   ✅ Result has correct data
   ✅ GetById was called once
   ✅ Add was called once
```

---

## 🔍 Understanding Each Test File

### 1. BookingServiceTests.cs

**What it tests**: Business logic in `BookingService`

**Why mock?**: Don't want real database access

**What we mock**:
- `IFlightRepository` - Pretends to fetch flights
- `IBookingRepository` - Pretends to save bookings

**Real-world simulation**:
```
Test: "Can I create a booking?"
Mock says: "Yes, flight exists!" 
Service: "Great, let me create booking"
Mock says: "Booking saved successfully!"
Test: "✅ Pass - Service works correctly"
```

### 2. BookingApiControllerTests.cs

**What it tests**: HTTP responses from `BookingApiController`

**Why mock?**: Don't want to test service logic (already tested separately)

**What we mock**:
- `IFlightService` - Pretends to search flights
- `IBookingService` - Pretends to create bookings

**Real-world simulation**:
```
Test: "Does API return HTTP 200 OK?"
Mock service: "Here's a booking object"
Controller: "Returns OkObjectResult(booking)"
Test: "✅ Pass - API returns correct HTTP response"
```

### 3. BookingRepositoryTests.cs

**What it tests**: Database operations in `BookingRepository`

**Why not mock?**: Need to test actual EF Core queries

**What we use**: In-Memory Database (fake database in RAM)

**Real-world simulation**:
```
Test: "Can I save to database?"
In-Memory DB: "I'll pretend to be SQL Server"
Repository: "Saves booking to in-memory DB"
Test: "Let me check... yes, it's there!"
Test: "✅ Pass - Repository saves correctly"
```

---

## 🎯 Benefits You Get

### ⚡ Speed
```
Traditional Testing:
  - Start SQL Server: 5 seconds
  - Create database: 2 seconds
  - Insert test data: 3 seconds
  - Run test: 0.1 seconds
  Total: ~10 seconds per test

Unit Testing with Mocks:
  - Create mocks: 0.001 seconds
  - Run test: 0.001 seconds
  Total: ~0.002 seconds per test
  
Speed improvement: 5000x faster! 🚀
```

### 🎯 Isolation
```
Test 1: Create booking
Test 2: Update booking
Test 3: Delete booking

With Real Database:
  ❌ Test 2 depends on Test 1
  ❌ Test 3 depends on Test 2
  ❌ Order matters!

With Mocks:
  ✅ Each test is independent
  ✅ Can run in any order
  ✅ Can run in parallel
```

### 🛡️ Reliability
```
With Real Database:
  ❌ Database connection fails → Test fails
  ❌ Network issue → Test fails
  ❌ Data conflicts → Test fails
  ❌ Someone deleted test data → Test fails

With Mocks:
  ✅ Always works
  ✅ No external dependencies
  ✅ Consistent results
  ✅ No surprises
```

---

## 🎨 Test Patterns Explained

### Pattern 1: Setup/Teardown

```csharp
[TestFixture]
public class BookingServiceTests
{
    private BookingService _service;
    private Mock<IBookingRepository> _mockRepo;

    [SetUp]
    public void Setup()
    {
        // Runs BEFORE each test
        _mockRepo = new Mock<IBookingRepository>();
        _service = new BookingService(_mockRepo.Object);
    }

    [Test]
    public void Test1() { /* ... */ }
    
    [Test]
    public void Test2() { /* ... */ }

    [TearDown]
    public void TearDown()
    {
        // Runs AFTER each test
        _service = null;
        _mockRepo = null;
    }
}
```

**Execution order:**
```
Setup() → Test1() → TearDown()
Setup() → Test2() → TearDown()
```

### Pattern 2: AAA (Arrange-Act-Assert)

```csharp
[Test]
public void CreateBooking_Test()
{
    // ===== ARRANGE =====
    // Set up everything needed
    var request = new BookingRequest { ... };
    _mockRepo.Setup(r => r.Add(...)).Returns(...);
    
    // ===== ACT =====
    // Do the thing you're testing
    var result = _service.CreateBooking(request);
    
    // ===== ASSERT =====
    // Check if it worked correctly
    Assert.IsNotNull(result);
    Assert.AreEqual("expected", result.Value);
}
```

### Pattern 3: Test Naming

```csharp
// Format: MethodName_Scenario_ExpectedResult

✅ CreateBooking_WithValidData_ReturnsBooking
✅ CreateBooking_WithInvalidFlight_ThrowsException
✅ GetBooking_WhenNotFound_ReturnsNull

❌ Test1()
❌ TestCreateBooking()
❌ CreateBookingTest()
```

---

## 🚀 Running Your Tests

### Command Line
```bash
# Navigate to test project
cd Flightbooking.test

# Run all 23 tests
dotnet test

# Output:
# Passed!  - Failed:  0, Passed: 23, Skipped: 0
```

### Visual Studio
```
1. Test → Test Explorer
2. Click "Run All Tests" ▶️
3. Watch them turn green! ✅
```

### What Success Looks Like
```
✅ BookingServiceTests.CreateBooking_WithValidRequest_ReturnsBooking (2ms)
✅ BookingServiceTests.CreateBooking_WithInvalidFlightId_ThrowsArgumentException (1ms)
✅ BookingServiceTests.CreateBooking_GeneratesUniqueReferenceNumber (1ms)
✅ BookingServiceTests.GetBookingByReference_WithValidReference_ReturnsBooking (1ms)
✅ BookingServiceTests.GetBookingByReference_WithInvalidReference_ReturnsNull (1ms)
... (18 more tests)

Total: 23 tests passed in 0.5 seconds
```

---

## 🎓 Key Takeaways

### What is Unit Testing?
> Testing individual "units" (methods/classes) in isolation

### What is Mocking?
> Creating fake objects to replace real dependencies

### Why Use Mocks?
> Tests run faster, are more reliable, and don't need external resources

### What Are We Testing?
```
✅ Business Logic (Service layer)
✅ HTTP Responses (Controller layer)  
✅ Database Operations (Repository layer)
```

### How Many Tests?
> 23 tests covering all major scenarios

---

## 🎯 Next Steps

1. **Run the tests**: `dotnet test`
2. **Watch them pass**: All 23 should be green ✅
3. **Read the code**: Understand how tests work
4. **Add your own**: Test new features you add

---

## 📖 More Resources

- **QUICKSTART.md** - How to run tests
- **README.md** - Full documentation  
- **TestExamples.md** - Detailed examples
- **TEST_SUMMARY.md** - Overview of all tests

---

**You now understand unit testing! 🎉**

*Remember: Good tests = Confident code changes* 🛡️

