using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models.DTOs
{
    public class CheckinRequest
    {
        [Required]
        public string BookingReference { get; set; } = string.Empty;
    }
}
