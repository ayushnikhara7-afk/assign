namespace FlightBookingApp.Models.DTOs
{
    public class UpdateFlightRequest
    {
        public int Id { get; set; }
        public string FlightNumber { get; set; } = string.Empty;
        public string From { get; set; } = string.Empty;
        public string To { get; set; } = string.Empty;
        public DateTime Date { get; set; }
        public decimal Fare { get; set; }
    }
}
