using System.ComponentModel.DataAnnotations;

namespace FlightBookingApp.Models.Domain
{
    public class Booking
    {
        public int Id { get; set; }
        
        [Required]
        public string? ReferenceNumber { get; set; } 
        
        [Required]
        public int FlightId { get; set; }
        
        [Required]
        public string FirstName { get; set; } = string.Empty;
        
        [Required]
        public string LastName { get; set; } = string.Empty;
        
        [Required]
        public string Gender { get; set; } = string.Empty;
        
        public DateTime BookingDate { get; set; } = DateTime.UtcNow;
        
        public bool IsCheckedIn { get; set; } = false;
        public string? SeatNumber { get; set; }
        public DateTime? CheckinDate { get; set; }
        
        public Flight? Flight { get; set; }
    }
}

