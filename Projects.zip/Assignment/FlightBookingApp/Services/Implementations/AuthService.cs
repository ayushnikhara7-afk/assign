using FlightBookingApp.Models.Domain;
using FlightBookingApp.Repository.Interfaces;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Services.Implementations
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _userRepo;
        
        public AuthService(IUserRepository userRepo) 
        {
            _userRepo = userRepo;
        }

        public bool ValidateUser(string username, string password)
        {
            var user = _userRepo.GetByUsername(username);
            return user != null && user.Password == password;
        }

        public bool UserExists(string username)
        {
            return _userRepo.GetByUsername(username) != null;
        }

        public void RegisterUser(User user)
        {
            _userRepo.Add(user);
        }
    }
}

