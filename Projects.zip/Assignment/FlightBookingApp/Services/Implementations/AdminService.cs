using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Repository.Interfaces;
using FlightBookingApp.Services.Interfaces;

namespace FlightBookingApp.Services.Implementations
{
    public class AdminService : IAdminService
    {
        private readonly IFlightRepository _flightRepo;
        private readonly IUserRepository _userRepo;
        public AdminService(IFlightRepository flightRepo, IUserRepository userRepo)
        {
            _flightRepo = flightRepo;
            _userRepo = userRepo;
        }

        public Flight CreateFlight(CreateFlightRequest request)
        {
            var flight = new Flight
            {
                FlightNumber = request.FlightNumber,
                From = request.From,
                To = request.To,
                Date = request.Date,
                Fare = request.Fare
            };

            return _flightRepo.Add(flight);
        }

        public bool DeleteFlight(int id)
        {
            return _flightRepo.Delete(id);
        }

        public bool ValidateAdmin(string username, string password)
        {
            return username == "admin" && password == "admin123";
        }

        public Flight UpdateFlight(UpdateFlightRequest request)
        {
            var flight = _flightRepo.GetById(request.Id);
            if (flight == null) throw new ArgumentException("Flight not found");
            flight.FlightNumber = request.FlightNumber;
            flight.From = request.From;
            flight.To = request.To;
            flight.Date = request.Date;
            flight.Fare = request.Fare;
            return _flightRepo.Update(flight);
        }

        public User UpdateUser(UpdateUserRequest request)
        {
            var user = _userRepo.GetByUsername(request.Username);
            if (user == null) throw new ArgumentException("User not found");
            user.Username = request.Username;
            user.Password = request.Password;
            return _userRepo.Update(user);
        }
    }
}
