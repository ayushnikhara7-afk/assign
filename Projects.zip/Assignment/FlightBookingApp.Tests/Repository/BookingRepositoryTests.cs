using NUnit.Framework;
using FlightBookingApp.Repository.Implementations;
using FlightBookingApp.Data;
using FlightBookingApp.Models.Domain;
using Microsoft.EntityFrameworkCore;

namespace FlightBookingApp.Tests
{
    /// <summary>
    /// Unit tests for BookingRepository using In-Memory Database
    /// Tests the data access layer
    /// </summary>
    [TestFixture]
    public class BookingRepositoryTests
    {
        private FlightDbContext _context;
        private BookingRepository _repository;

        [SetUp]
        public void Setup()
        {
            // Create in-memory database for testing
            var options = new DbContextOptionsBuilder<FlightDbContext>()
                .UseInMemoryDatabase(databaseName: Guid.NewGuid().ToString()) // Unique DB for each test
                .Options;

            _context = new FlightDbContext(options);
            _repository = new BookingRepository(_context);

            // Seed test data
            SeedTestData();
        }

        private void SeedTestData()
        {
            var flights = new List<Flight>
            {
                new Flight
                {
                    Id = 1,
                    FlightNumber = "FL001",
                    From = "NYC",
                    To = "LAX",
                    Date = DateTime.Now.AddDays(7),
                    Fare = 299.99m
                },
                new Flight
                {
                    Id = 2,
                    FlightNumber = "FL002",
                    From = "LAX",
                    To = "NYC",
                    Date = DateTime.Now.AddDays(10),
                    Fare = 349.99m
                }
            };

            var bookings = new List<Booking>
            {
                new Booking
                {
                    Id = 1,
                    ReferenceNumber = "REF001",
                    FlightId = 1,
                    FirstName = "John",
                    LastName = "Doe",
                    Gender = "M",
                    BookingDate = DateTime.UtcNow,
                    IsCheckedIn = false
                },
                new Booking
                {
                    Id = 2,
                    ReferenceNumber = "REF002",
                    FlightId = 2,
                    FirstName = "Jane",
                    LastName = "Smith",
                    Gender = "F",
                    BookingDate = DateTime.UtcNow,
                    IsCheckedIn = true,
                    SeatNumber = "12A"
                }
            };

            _context.Flights.AddRange(flights);
            _context.Bookings.AddRange(bookings);
            _context.SaveChanges();
        }

        #region Add Tests

        [Test]
        public void Add_ValidBooking_SavesAndReturnsBooking()
        {
            // Arrange
            var newBooking = new Booking
            {
                ReferenceNumber = "REF003",
                FlightId = 1,
                FirstName = "Bob",
                LastName = "Johnson",
                Gender = "M",
                BookingDate = DateTime.UtcNow
            };

            // Act
            var result = _repository.Add(newBooking);

            // Assert
            Assert.IsNotNull(result);
            Assert.Greater(result.Id, 0); // ID should be generated
            Assert.AreEqual("REF003", result.ReferenceNumber);
            Assert.AreEqual("Bob", result.FirstName);
            
            // Verify it's in the database
            var savedBooking = _context.Bookings.Find(result.Id);
            Assert.IsNotNull(savedBooking);
            Assert.AreEqual("Bob", savedBooking.FirstName);
        }

        [Test]
        public void Add_MultipleBookings_SavesAll()
        {
            // Arrange
            var initialCount = _context.Bookings.Count();

            // Act
            for (int i = 0; i < 3; i++)
            {
                var booking = new Booking
                {
                    ReferenceNumber = $"REF00{i + 3}",
                    FlightId = 1,
                    FirstName = $"User{i}",
                    LastName = "Test",
                    Gender = "M",
                    BookingDate = DateTime.UtcNow
                };
                _repository.Add(booking);
            }

            // Assert
            Assert.AreEqual(initialCount + 3, _context.Bookings.Count());
        }

        #endregion

        #region GetByReferenceNumber Tests

        [Test]
        public void GetByReferenceNumber_ExistingReference_ReturnsBooking()
        {
            // Act
            var result = _repository.GetByReferenceNumber("REF001");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("REF001", result.ReferenceNumber);
            Assert.AreEqual("John", result.FirstName);
            Assert.AreEqual("Doe", result.LastName);
        }

        [Test]
        public void GetByReferenceNumber_NonExistingReference_ReturnsNull()
        {
            // Act
            var result = _repository.GetByReferenceNumber("INVALID");

            // Assert
            Assert.IsNull(result);
        }

        [Test]
        public void GetByReferenceNumber_CaseSensitive_ReturnsCorrectBooking()
        {
            // Act
            var result1 = _repository.GetByReferenceNumber("REF001");
            var result2 = _repository.GetByReferenceNumber("ref001");

            // Assert
            Assert.IsNotNull(result1);
            Assert.IsNull(result2); // Case sensitive
        }

        #endregion

        #region GetBookingWithFlight Tests

        [Test]
        public void GetBookingWithFlight_ExistingReference_ReturnsBookingWithFlight()
        {
            // Act
            var result = _repository.GetBookingWithFlight("REF001");

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("REF001", result.ReferenceNumber);
            Assert.IsNotNull(result.Flight);
            Assert.AreEqual("FL001", result.Flight.FlightNumber);
            Assert.AreEqual("NYC", result.Flight.From);
            Assert.AreEqual("LAX", result.Flight.To);
        }

        [Test]
        public void GetBookingWithFlight_NonExistingReference_ReturnsNull()
        {
            // Act
            var result = _repository.GetBookingWithFlight("INVALID");

            // Assert
            Assert.IsNull(result);
        }

        [Test]
        public void GetBookingWithFlight_CheckedInBooking_ReturnsWithAllDetails()
        {
            // Act
            var result = _repository.GetBookingWithFlight("REF002");

            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsCheckedIn);
            Assert.AreEqual("12A", result.SeatNumber);
            Assert.IsNotNull(result.Flight);
            Assert.AreEqual("FL002", result.Flight.FlightNumber);
        }

        #endregion

        #region Update Tests

        [Test]
        public void Update_ExistingBooking_UpdatesSuccessfully()
        {
            // Arrange
            var booking = _repository.GetByReferenceNumber("REF001");
            Assert.IsNotNull(booking);
            
            booking.IsCheckedIn = true;
            booking.SeatNumber = "15B";
            booking.CheckinDate = DateTime.UtcNow;

            // Act
            var result = _repository.Update(booking);

            // Assert
            Assert.IsNotNull(result);
            Assert.IsTrue(result.IsCheckedIn);
            Assert.AreEqual("15B", result.SeatNumber);
            Assert.IsNotNull(result.CheckinDate);
            
            // Verify in database
            var updatedBooking = _context.Bookings.Find(booking.Id);
            Assert.IsTrue(updatedBooking!.IsCheckedIn);
            Assert.AreEqual("15B", updatedBooking.SeatNumber);
        }

        [Test]
        public void Update_MultipleFields_UpdatesAll()
        {
            // Arrange
            var booking = _repository.GetByReferenceNumber("REF002");
            Assert.IsNotNull(booking);
            
            booking.SeatNumber = "20C";
            booking.FirstName = "Janet";
            booking.LastName = "Smithson";

            // Act
            var result = _repository.Update(booking);

            // Assert
            Assert.AreEqual("20C", result.SeatNumber);
            Assert.AreEqual("Janet", result.FirstName);
            Assert.AreEqual("Smithson", result.LastName);
        }

        #endregion

        [TearDown]
        public void TearDown()
        {
            // Cleanup after each test
            _context.Database.EnsureDeleted();
            _context.Dispose();
            _repository = null!;
        }
    }
}

