using NUnit.Framework;
using Moq;
using FlightBookingApp.Controllers;
using FlightBookingApp.Services.Interfaces;
using FlightBookingApp.Models.DTOs;
using FlightBookingApp.Models.Domain;
using Microsoft.AspNetCore.Mvc;

namespace FlightBookingApp.Tests
{
    /// <summary>
    /// Unit tests for BookingApiController
    /// Tests the API endpoints and their responses
    /// </summary>
    [TestFixture]
    public class BookingApiControllerTests
    {
        private Mock<IFlightService> _mockFlightService;
        private Mock<IBookingService> _mockBookingService;
        private BookingApiController _controller;

        [SetUp]
        public void Setup()
        {
            // Initialize mocks before each test
            _mockFlightService = new Mock<IFlightService>();
            _mockBookingService = new Mock<IBookingService>();
            _controller = new BookingApiController(_mockFlightService.Object, _mockBookingService.Object);
        }

        #region SearchFlights Tests

        [Test]
        public void SearchFlights_WithValidRequest_ReturnsOkWithFlightList()
        {
            // Arrange
            var request = new SearchRequest
            {
                From = "NYC",
                To = "LAX",
                Date = DateTime.Now.AddDays(7)
            };

            var expectedFlights = new List<Flight>
            {
                new Flight
                {
                    Id = 1,
                    FlightNumber = "FL001",
                    From = "NYC",
                    To = "LAX",
                    Date = request.Date,
                    Fare = 299.99m
                },
                new Flight
                {
                    Id = 2,
                    FlightNumber = "FL002",
                    From = "NYC",
                    To = "LAX",
                    Date = request.Date,
                    Fare = 349.99m
                }
            };

            _mockFlightService
                .Setup(s => s.SearchFlights(request.From, request.To, request.Date))
                .Returns(expectedFlights);

            // Act
            var result = _controller.SearchFlights(request);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);
            
            var flights = okResult.Value as List<Flight>;
            Assert.IsNotNull(flights);
            Assert.AreEqual(2, flights.Count);
            Assert.AreEqual("FL001", flights[0].FlightNumber);
            
            // Verify service was called with correct parameters
            _mockFlightService.Verify(s => s.SearchFlights(request.From, request.To, request.Date), Times.Once);
        }

        [Test]
        public void SearchFlights_WithNoResults_ReturnsOkWithEmptyList()
        {
            // Arrange
            var request = new SearchRequest
            {
                From = "NYC",
                To = "MARS",
                Date = DateTime.Now.AddDays(7)
            };

            _mockFlightService
                .Setup(s => s.SearchFlights(request.From, request.To, request.Date))
                .Returns(new List<Flight>());

            // Act
            var result = _controller.SearchFlights(request);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            var flights = okResult!.Value as List<Flight>;
            Assert.IsNotNull(flights);
            Assert.AreEqual(0, flights.Count);
        }

        #endregion

        #region CreateBooking Tests

        [Test]
        public void CreateBooking_WithValidRequest_ReturnsOkWithBooking()
        {
            // Arrange
            var request = new BookingRequest
            {
                FlightId = 1,
                FirstName = "John",
                LastName = "Doe",
                Gender = "M"
            };

            var expectedBooking = new Booking
            {
                Id = 1,
                ReferenceNumber = "ABC123",
                FlightId = 1,
                FirstName = "John",
                LastName = "Doe",
                Gender = "M",
                BookingDate = DateTime.UtcNow
            };

            _mockBookingService
                .Setup(s => s.CreateBooking(It.IsAny<BookingRequest>()))
                .Returns(expectedBooking);

            // Act
            var result = _controller.CreateBooking(request);

            // Assert
            Assert.IsInstanceOf<OkObjectResult>(result);
            var okResult = result as OkObjectResult;
            Assert.IsNotNull(okResult);
            Assert.AreEqual(200, okResult.StatusCode);
            
            var booking = okResult.Value as Booking;
            Assert.IsNotNull(booking);
            Assert.AreEqual("ABC123", booking.ReferenceNumber);
            Assert.AreEqual("John", booking.FirstName);
            Assert.AreEqual("Doe", booking.LastName);
            
            // Verify the service was called exactly once
            _mockBookingService.Verify(s => s.CreateBooking(It.IsAny<BookingRequest>()), Times.Once);
        }

        [Test]
        public void CreateBooking_WithCompleteDetails_ReturnsBookingWithAllFields()
        {
            // Arrange
            var request = new BookingRequest
            {
                FlightId = 5,
                FirstName = "Jane",
                LastName = "Smith",
                Gender = "F"
            };

            var expectedBooking = new Booking
            {
                Id = 10,
                ReferenceNumber = "XYZ789",
                FlightId = 5,
                FirstName = "Jane",
                LastName = "Smith",
                Gender = "F",
                BookingDate = DateTime.UtcNow,
                IsCheckedIn = false
            };

            _mockBookingService
                .Setup(s => s.CreateBooking(request))
                .Returns(expectedBooking);

            // Act
            var result = _controller.CreateBooking(request);

            // Assert
            var okResult = result as OkObjectResult;
            var booking = okResult!.Value as Booking;
            
            Assert.IsNotNull(booking);
            Assert.AreEqual(10, booking.Id);
            Assert.AreEqual("XYZ789", booking.ReferenceNumber);
            Assert.AreEqual(5, booking.FlightId);
            Assert.AreEqual("Jane", booking.FirstName);
            Assert.AreEqual("Smith", booking.LastName);
            Assert.AreEqual("F", booking.Gender);
            Assert.IsFalse(booking.IsCheckedIn);
        }

        [Test]
        public void CreateBooking_ServiceThrowsException_ExceptionPropagates()
        {
            // Arrange
            var request = new BookingRequest
            {
                FlightId = 999,
                FirstName = "John",
                LastName = "Doe",
                Gender = "M"
            };

            _mockBookingService
                .Setup(s => s.CreateBooking(It.IsAny<BookingRequest>()))
                .Throws(new ArgumentException("Flight not found"));

            // Act & Assert
            var ex = Assert.Throws<ArgumentException>(() => _controller.CreateBooking(request));
            Assert.That(ex.Message, Is.EqualTo("Flight not found"));
        }

        #endregion

        [TearDown]
        public void TearDown()
        {
            // Cleanup after each test
            _controller = null!;
            _mockFlightService = null!;
            _mockBookingService = null!;
        }
    }
}

