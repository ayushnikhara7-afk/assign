using NUnit.Framework;
using Moq;
using FlightBookingApp.Services.Implementations;
using FlightBookingApp.Repository.Interfaces;
using FlightBookingApp.Models.Domain;
using FlightBookingApp.Models.DTOs;

namespace FlightBookingApp.Tests
{
    /// <summary>
    /// Unit tests for BookingService
    /// Tests the business logic layer without database dependencies
    /// </summary>
    [TestFixture]
    public class BookingServiceTests
    {
        private Mock<IBookingRepository> _mockBookingRepo;
        private Mock<IFlightRepository> _mockFlightRepo;
        private BookingService _bookingService;

        [SetUp]
        public void Setup()
        {
            // Initialize mocks before each test
            _mockBookingRepo = new Mock<IBookingRepository>();
            _mockFlightRepo = new Mock<IFlightRepository>();
            _bookingService = new BookingService(_mockBookingRepo.Object, _mockFlightRepo.Object);
        }

        #region CreateBooking Tests

        [Test]
        public void CreateBooking_WithValidRequest_ReturnsBooking()
        {
            // Arrange
            var request = new BookingRequest
            {
                FlightId = 1,
                FirstName = "John",
                LastName = "Doe",
                Gender = "M"
            };

            var flight = new Flight
            {
                Id = 1,
                FlightNumber = "FL001",
                From = "NYC",
                To = "LAX",
                Date = DateTime.Now.AddDays(7),
                Fare = 299.99m
            };

            var expectedBooking = new Booking
            {
                Id = 1,
                ReferenceNumber = "ABC123",
                FlightId = 1,
                FirstName = "John",
                LastName = "Doe",
                Gender = "M",
                BookingDate = DateTime.UtcNow
            };

            _mockFlightRepo.Setup(r => r.GetById(request.FlightId)).Returns(flight);
            _mockBookingRepo.Setup(r => r.Add(It.IsAny<Booking>())).Returns(expectedBooking);

            // Act
            var result = _bookingService.CreateBooking(request);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("John", result.FirstName);
            Assert.AreEqual("Doe", result.LastName);
            Assert.AreEqual("M", result.Gender);
            Assert.AreEqual(1, result.FlightId);
            
            // Verify methods were called
            _mockFlightRepo.Verify(r => r.GetById(request.FlightId), Times.Once);
            _mockBookingRepo.Verify(r => r.Add(It.IsAny<Booking>()), Times.Once);
        }

        [Test]
        public void CreateBooking_WithInvalidFlightId_ThrowsArgumentException()
        {
            // Arrange
            var request = new BookingRequest
            {
                FlightId = 999,
                FirstName = "John",
                LastName = "Doe",
                Gender = "M"
            };

            _mockFlightRepo.Setup(r => r.GetById(request.FlightId)).Returns((Flight?)null);

            // Act & Assert
            var ex = Assert.Throws<ArgumentException>(() => _bookingService.CreateBooking(request));
            Assert.That(ex.Message, Is.EqualTo("Flight not found"));
            
            // Verify flight lookup was attempted but booking was never created
            _mockFlightRepo.Verify(r => r.GetById(request.FlightId), Times.Once);
            _mockBookingRepo.Verify(r => r.Add(It.IsAny<Booking>()), Times.Never);
        }

        [Test]
        public void CreateBooking_GeneratesUniqueReferenceNumber()
        {
            // Arrange
            var request = new BookingRequest
            {
                FlightId = 1,
                FirstName = "Jane",
                LastName = "Smith",
                Gender = "F"
            };

            var flight = new Flight { Id = 1, FlightNumber = "FL001" };
            
            Booking? capturedBooking = null;
            _mockFlightRepo.Setup(r => r.GetById(1)).Returns(flight);
            _mockBookingRepo.Setup(r => r.Add(It.IsAny<Booking>()))
                .Callback<Booking>(b => capturedBooking = b)
                .Returns((Booking b) => b);

            // Act
            var result = _bookingService.CreateBooking(request);

            // Assert
            Assert.IsNotNull(capturedBooking);
            Assert.IsNotNull(capturedBooking.ReferenceNumber);
            Assert.IsNotEmpty(capturedBooking.ReferenceNumber);
        }

        #endregion

        #region GetBookingByReference Tests

        [Test]
        public void GetBookingByReference_WithValidReference_ReturnsBooking()
        {
            // Arrange
            var referenceNumber = "ABC123";
            var expectedBooking = new Booking
            {
                Id = 1,
                ReferenceNumber = referenceNumber,
                FirstName = "John",
                LastName = "Doe",
                Gender = "M",
                FlightId = 1
            };

            _mockBookingRepo.Setup(r => r.GetByReferenceNumber(referenceNumber))
                .Returns(expectedBooking);

            // Act
            var result = _bookingService.GetBookingByReference(referenceNumber);

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(referenceNumber, result.ReferenceNumber);
            Assert.AreEqual("John", result.FirstName);
            
            _mockBookingRepo.Verify(r => r.GetByReferenceNumber(referenceNumber), Times.Once);
        }

        [Test]
        public void GetBookingByReference_WithInvalidReference_ReturnsNull()
        {
            // Arrange
            var referenceNumber = "INVALID123";
            _mockBookingRepo.Setup(r => r.GetByReferenceNumber(referenceNumber))
                .Returns((Booking?)null);

            // Act
            var result = _bookingService.GetBookingByReference(referenceNumber);

            // Assert
            Assert.IsNull(result);
            _mockBookingRepo.Verify(r => r.GetByReferenceNumber(referenceNumber), Times.Once);
        }

        #endregion

        [TearDown]
        public void TearDown()
        {
            // Cleanup after each test
            _bookingService = null!;
            _mockBookingRepo = null!;
            _mockFlightRepo = null!;
        }
    }
}
